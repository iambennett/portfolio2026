const e={agentsMd:'# App — Agent Guide\n\nThis starter ships as a blank Agent-Native app canvas — that describes its\ninitial state, not necessarily its current one. See `DEVELOPING.md` before\nmaking any source code change.\n\n## Skills\n\nSearch with `rg --hidden --follow`; read the exact linked guide before deeper work. `.agents/skills/build-an-app/SKILL.md` — start here for vague requests to create a domain app. `.agents/skills/adding-a-feature/SKILL.md` — cross-area feature checklist. Data/integrations: `.agents/skills/actions/SKILL.md`, `.agents/skills/storing-data/SKILL.md`, `.agents/skills/security/SKILL.md`, `.agents/skills/secrets/SKILL.md`, `.agents/skills/sharing/SKILL.md`. UI: `.agents/skills/frontend-design/SKILL.md`, `.agents/skills/shadcn-ui/SKILL.md`, `.agents/skills/client-side-routing/SKILL.md`. Agent context/workflows: `.agents/skills/context-awareness/SKILL.md`, `.agents/skills/real-time-sync/SKILL.md`, `.agents/skills/reliable-mutations/SKILL.md`, `.agents/skills/performance/SKILL.md`, `.agents/skills/delegate-to-agent/SKILL.md`. Framework: `.agents/skills/agent-native-docs/SKILL.md`, `.agents/skills/agent-native-toolkit/SKILL.md`, `.agents/skills/customizing-agent-native/SKILL.md`.\n\nUse local docs only (no web research): `pnpm action docs-search --query "<topic>"`, `pnpm action docs-search --slug "<slug>"`, `pnpm action docs-search --list`, `pnpm action source-search --query "<pattern>"`, `pnpm action source-search --path <path>`, or `pnpm action source-search --list`. For external-agent integrations, read `pnpm action docs-search --slug "external-agents"`.\n\nThis repo is a single standalone app (`agent-native.scaffold.shape:\n"standalone"`), not a workspace root. If the user asks for a workspace, a\nplatform or suite of apps, a second app, an app shell or launcher, or Dispatch,\nread the `multi-app-workspace` skill before touching the repo layout.\n\n## Core rules\n\n- UI feedback: target 100 ms, never exceed 400 ms; acknowledge before network work.\n- Normal app data must flow through actions. Keep actions deterministic and focused; use agent chat/AgentSidebar for AI work and follow-ups in the same thread. Keep structured state in SQL and large files in configured storage; persist references only.\n- For external integrations, inspect the workspace/provider connection catalog first; reuse its scoped resolver. Never hardcode credentials, webhook URLs, or private/customer data.\n- Never fabricate. Report failures and recover; verify writes by reading the row or screen. Navigation is in `<current-screen>`; use `view-screen` for fresh visible-record details.\n\nFor custom branding, keep `server/plugins/agent-native-email-branding.ts` aligned: `app.name` appears in transactional email and optional `app.logoUrl` must be an absolute HTTPS URL.\n\n## Application state\n\n- `navigation` describes the view and selected ids. The default home view is\n  `home` at `/` (blank app canvas). No agent rail or chat is mounted by\n  default; add one only when the user asks.\n- Use `navigate` when supported and `view-screen` for a fresh read of visible details; basic navigation is already in `<current-screen>`.\n\n## Building a domain app\n\nChoose the primary workflow and route before editing. Build on the blank canvas in `app/routes/_index.tsx` or add domain routes under `app/routes/`. This starter has no Chat route, sidebar, header, or agent rail; add only the navigation the product needs. Set `app.homePath` in the existing `defineAppConfig` in `server/plugins/config.ts` as `DEVELOPING.md` describes.\n\nUse `adding-a-feature` for functional parity and `frontend-design` for a user-facing screen. Keep feature guidance here and update `README.md` as `DEVELOPING.md` describes. After all edits, run one typecheck, one doctor check, and one browser smoke of the primary workflow and its authenticated landing. Skip production build and extra test suites.\n\nBefore building common workspace or agent UI, read `agent-native-toolkit`; for supported customization, read `customizing-agent-native`.\n\n- Guarded verification: run `pnpm agent-native:doctor`; fix findings before done.\n',runtimeAgentsMd:'# App — Agent Guide\n\nThis starter ships as a blank Agent-Native app canvas — that describes its\ninitial state, not necessarily its current one. See `DEVELOPING.md` before\nmaking any source code change.\n\n## Skills\n\nSearch with `rg --hidden --follow`; read the exact linked guide before deeper work. `.agents/skills/build-an-app/SKILL.md` — start here for vague requests to create a domain app. `.agents/skills/adding-a-feature/SKILL.md` — cross-area feature checklist. Data/integrations: `.agents/skills/actions/SKILL.md`, `.agents/skills/storing-data/SKILL.md`, `.agents/skills/security/SKILL.md`, `.agents/skills/secrets/SKILL.md`, `.agents/skills/sharing/SKILL.md`. UI: `.agents/skills/frontend-design/SKILL.md`, `.agents/skills/shadcn-ui/SKILL.md`, `.agents/skills/client-side-routing/SKILL.md`. Agent context/workflows: `.agents/skills/context-awareness/SKILL.md`, `.agents/skills/real-time-sync/SKILL.md`, `.agents/skills/reliable-mutations/SKILL.md`, `.agents/skills/performance/SKILL.md`, `.agents/skills/delegate-to-agent/SKILL.md`. Framework: `.agents/skills/agent-native-docs/SKILL.md`, `.agents/skills/agent-native-toolkit/SKILL.md`, `.agents/skills/customizing-agent-native/SKILL.md`.\n\nUse local docs only (no web research): `pnpm action docs-search --query "<topic>"`, `pnpm action docs-search --slug "<slug>"`, `pnpm action docs-search --list`, `pnpm action source-search --query "<pattern>"`, `pnpm action source-search --path <path>`, or `pnpm action source-search --list`. For external-agent integrations, read `pnpm action docs-search --slug "external-agents"`.\n\nThis repo is a single standalone app (`agent-native.scaffold.shape:\n"standalone"`), not a workspace root. If the user asks for a workspace, a\nplatform or suite of apps, a second app, an app shell or launcher, or Dispatch,\nread the `multi-app-workspace` skill before touching the repo layout.\n\n## Core rules\n\n- UI feedback: target 100 ms, never exceed 400 ms; acknowledge before network work.\n- Normal app data must flow through actions. Keep actions deterministic and focused; use agent chat/AgentSidebar for AI work and follow-ups in the same thread. Keep structured state in SQL and large files in configured storage; persist references only.\n- For external integrations, inspect the workspace/provider connection catalog first; reuse its scoped resolver. Never hardcode credentials, webhook URLs, or private/customer data.\n- Never fabricate. Report failures and recover; verify writes by reading the row or screen. Navigation is in `<current-screen>`; use `view-screen` for fresh visible-record details.\n\nFor custom branding, keep `server/plugins/agent-native-email-branding.ts` aligned: `app.name` appears in transactional email and optional `app.logoUrl` must be an absolute HTTPS URL.\n\n## Application state\n\n- `navigation` describes the view and selected ids. The default home view is\n  `home` at `/` (blank app canvas). No agent rail or chat is mounted by\n  default; add one only when the user asks.\n- Use `navigate` when supported and `view-screen` for a fresh read of visible details; basic navigation is already in `<current-screen>`.\n\n## Building a domain app\n\nChoose the primary workflow and route before editing. Build on the blank canvas in `app/routes/_index.tsx` or add domain routes under `app/routes/`. This starter has no Chat route, sidebar, header, or agent rail; add only the navigation the product needs. Set `app.homePath` in the existing `defineAppConfig` in `server/plugins/config.ts` as `DEVELOPING.md` describes.\n\nUse `adding-a-feature` for functional parity and `frontend-design` for a user-facing screen. Keep feature guidance here and update `README.md` as `DEVELOPING.md` describes. After all edits, run one typecheck, one doctor check, and one browser smoke of the primary workflow and its authenticated landing. Skip production build and extra test suites.\n\nBefore building common workspace or agent UI, read `agent-native-toolkit`; for supported customization, read `customizing-agent-native`.\n\n- Guarded verification: run `pnpm agent-native:doctor`; fix findings before done.\n',developmentAgentsMd:'# App — Agent Guide\n\nThis starter ships as a blank Agent-Native app canvas — that describes its\ninitial state, not necessarily its current one. See `DEVELOPING.md` before\nmaking any source code change.\n\n## Skills\n\nSearch with `rg --hidden --follow`; read the exact linked guide before deeper work. `.agents/skills/build-an-app/SKILL.md` — start here for vague requests to create a domain app. `.agents/skills/adding-a-feature/SKILL.md` — cross-area feature checklist. Data/integrations: `.agents/skills/actions/SKILL.md`, `.agents/skills/storing-data/SKILL.md`, `.agents/skills/security/SKILL.md`, `.agents/skills/secrets/SKILL.md`, `.agents/skills/sharing/SKILL.md`. UI: `.agents/skills/frontend-design/SKILL.md`, `.agents/skills/shadcn-ui/SKILL.md`, `.agents/skills/client-side-routing/SKILL.md`. Agent context/workflows: `.agents/skills/context-awareness/SKILL.md`, `.agents/skills/real-time-sync/SKILL.md`, `.agents/skills/reliable-mutations/SKILL.md`, `.agents/skills/performance/SKILL.md`, `.agents/skills/delegate-to-agent/SKILL.md`. Framework: `.agents/skills/agent-native-docs/SKILL.md`, `.agents/skills/agent-native-toolkit/SKILL.md`, `.agents/skills/customizing-agent-native/SKILL.md`.\n\nUse local docs only (no web research): `pnpm action docs-search --query "<topic>"`, `pnpm action docs-search --slug "<slug>"`, `pnpm action docs-search --list`, `pnpm action source-search --query "<pattern>"`, `pnpm action source-search --path <path>`, or `pnpm action source-search --list`. For external-agent integrations, read `pnpm action docs-search --slug "external-agents"`.\n\nThis repo is a single standalone app (`agent-native.scaffold.shape:\n"standalone"`), not a workspace root. If the user asks for a workspace, a\nplatform or suite of apps, a second app, an app shell or launcher, or Dispatch,\nread the `multi-app-workspace` skill before touching the repo layout.\n\n## Core rules\n\n- UI feedback: target 100 ms, never exceed 400 ms; acknowledge before network work.\n- Normal app data must flow through actions. Keep actions deterministic and focused; use agent chat/AgentSidebar for AI work and follow-ups in the same thread. Keep structured state in SQL and large files in configured storage; persist references only.\n- For external integrations, inspect the workspace/provider connection catalog first; reuse its scoped resolver. Never hardcode credentials, webhook URLs, or private/customer data.\n- Never fabricate. Report failures and recover; verify writes by reading the row or screen. Navigation is in `<current-screen>`; use `view-screen` for fresh visible-record details.\n\nFor custom branding, keep `server/plugins/agent-native-email-branding.ts` aligned: `app.name` appears in transactional email and optional `app.logoUrl` must be an absolute HTTPS URL.\n\n## Application state\n\n- `navigation` describes the view and selected ids. The default home view is\n  `home` at `/` (blank app canvas). No agent rail or chat is mounted by\n  default; add one only when the user asks.\n- Use `navigate` when supported and `view-screen` for a fresh read of visible details; basic navigation is already in `<current-screen>`.\n\n## Building a domain app\n\nChoose the primary workflow and route before editing. Build on the blank canvas in `app/routes/_index.tsx` or add domain routes under `app/routes/`. This starter has no Chat route, sidebar, header, or agent rail; add only the navigation the product needs. Set `app.homePath` in the existing `defineAppConfig` in `server/plugins/config.ts` as `DEVELOPING.md` describes.\n\nUse `adding-a-feature` for functional parity and `frontend-design` for a user-facing screen. Keep feature guidance here and update `README.md` as `DEVELOPING.md` describes. After all edits, run one typecheck, one doctor check, and one browser smoke of the primary workflow and its authenticated landing. Skip production build and extra test suites.\n\nBefore building common workspace or agent UI, read `agent-native-toolkit`; for supported customization, read `customizing-agent-native`.\n\n- Guarded verification: run `pnpm agent-native:doctor`; fix findings before done.\n',workspaceAgentsMd:``,skills:{actions:{meta:{name:`actions`,description:`How to create and run agent actions. Actions are the single source of truth for app operations — the agent calls them as tools and frontend code calls them through client hooks. Use when creating a new action, adding an API integration, or wiring up frontend data fetching.`,scope:`dev`},content:'---\nname: actions\ndescription: >-\n  How to create and run agent actions. Actions are the single source of truth\n  for app operations — the agent calls them as tools and frontend code calls\n  them through client hooks. Use when creating a new action, adding an API\n  integration, or wiring up frontend data fetching.\nscope: dev\nmetadata:\n  internal: true\n---\n\n# Agent Actions\n\n## Rule\n\nActions in `actions/` are the **single source of truth** for app operations. The agent calls them as tools, the frontend calls them through `useActionQuery` / `useActionMutation`, and the framework owns the HTTP transport behind those hooks — no duplicate `/api/` routes.\n\nBefore creating any custom route for app data, check `actions/` and the action table in `AGENTS.md`. An action already exists? Call it directly. Missing? Create or update a `defineAction`. **Stop trigger:** about to add a file under `server/routes/api/` (or middleware to guard one)? Check it against the exception list in *Custom `/api/` Routes* below first — even if you already started the route.\n\n## Keep Actions Deterministic\n\nAn action may call a provider API, validate data, and persist records without being an AI feature — keep it deterministic, focused, and independently useful to the agent. Don\'t put LLM calls or a second model runtime in app actions.\n\nWhen a workflow is research, analysis, generation, recommendation, or synthesis — or spans several provider calls and writes — route it to the AgentSidebar via `sendToAgentChat({ openSidebar: true })` and let the agent orchestrate focused actions instead of hiding an AI-shaped workflow behind one opaque `generate-*`/`create-*` action just because its implementation happens to be deterministic.\n\n## How to Create an Action\n\n**One action per file, default-exported. The filename is the action name** (kebab-case): `actions/list-meals.ts` is the `list-meals` action. Don\'t put several `defineAction`s as named exports in one file — the registry keys actions by filename and only the default export is registered, so extra named exports never become callable and won\'t match `.generated/action-types.d.ts`.\n\n```ts\n// actions/list-meals.ts\nimport { z } from "zod";\nimport { defineAction } from "@agent-native/core/action";\nimport { getDb } from "../server/db/index.js";\nimport { meals } from "../server/db/schema.js";\n\nexport default defineAction({\n  description: "List all meals",\n  schema: z.object({}),\n  http: { method: "GET" },\n  run: async () => {\n    const db = getDb();\n    const rows = await db.select().from(meals);\n    return rows; // Return objects/arrays, NOT JSON.stringify()\n  },\n});\n```\n\n`schema` (Zod or Standard Schema-compatible) gives runtime validation, TS inference for `run()` args, and an auto-generated JSON Schema for the tool. Write it so an agent can call the tool correctly on the first try: `.describe()` every param and state enum values and the default in that text (`z.enum(["open","closed"]).default("open").describe(\'Filter status: "open" or "closed"; defaults to "open"\')`); mark a field `.optional()` only when the action truly tolerates its absence — a silent default the caller cannot see is a required field in disguise; name the primary id the same way across a family (`create-/get-/update-/delete-<thing>` all take `id`, not a mix of `id` and `<thing>Id`), and if one action must differ, accept both with `.or()`; give nested objects a real schema, never a prose description; keep the one-line `description` complete enough to call the tool without a second lookup, because compact catalogs and `tool-search` show only that line. Use `z.coerce.number()` for numeric HTTP params, but write an explicit boolean parser instead of `z.coerce.boolean()`, which treats `"false"` as truthy.\n\nUse Drizzle\'s PostgreSQL query builder, not raw SQL/`getDbExec()` or direct driver imports, unless Drizzle can\'t express the query. Never hardcode API keys/tokens/secrets - read via `readAppSecret` / `resolveCredential` / OAuth helpers; `process.env` is deploy-level config only.\n\n**Decision order:** existing action → extend/create a `defineAction` → custom route as last resort (*Custom `/api/` Routes* below). Actions are already callable by agents, CLIs, hooks, HTTP, and MCP/A2A — don\'t wrap them in an umbrella REST API.\n\n## Keep the Action Surface Small and Orthogonal\n\nEvery agent-exposed action is a tool in the model\'s context window; more tools degrades tool-selection quality. Add the fewest, most orthogonal actions that cover the capability.\n\n- **One orthogonal `update` per resource**, not one per field — `update-<thing>` taking an optional-fields patch, not `update-<thing>-name` + `update-<thing>-order` + …\n- **Reach for a generic escape hatch before minting a new read action** — the `provider-api-catalog`/`docs`/`request` trio for provider data (`references/provider-apis.md`), `db-query` for ad hoc app-data reads in dev.\n- **`agentTool: false`** hides a UI-only/programmatic action from the model while keeping it frontend/HTTP-callable — not `toolCallable: false`, which only blocks the sandboxed extension bridge and leaves the action visible everywhere else; reserve that one for high-blast-radius operations.\n- **Delete or hide stale actions** once you confirm neither the UI nor an agent workflow uses them.\n\n## Key Actions — One Index, Every Surface\n\nDocument the app\'s primary actions in the `AGENTS.md` action table. For first-turn loading, add those action names to the plugin\'s `initialToolNames` (`INITIAL_TOOL_NAMES` in some templates), or mark the full starter set `deferLoading: false` on the actions. When one action opts into per-action eager loading, unmarked actions are deferred; the remaining actions stay discoverable through `tool-search`.\n\nWhen MCP is enabled, its `Key tools` line is generated from `mcp.keyToolNames ?? initialToolNames` and filtered to the actions served on that surface. A configured `mcp.keyToolNames` overrides the advertised MCP/WebMCP key list; it does not change the in-app agent\'s first-turn list. Keep the advertised subset consistent with the primary actions in the `AGENTS.md` table and the external catalog; the table may also document other in-app actions. Do not hand-write another action list in `mcp.instructions`, a skill, or an external skill; describe when to use actions there.\n\n## The `http` Option\n\nControls HTTP exposure:\n\n| Value | Behavior | Use for |\n| --- | --- | --- |\n| _(omitted)_ | `POST /_agent-native/actions/:name` | Write operations (default) |\n| `{ method: "GET" }` | `GET /_agent-native/actions/:name` | Read-only queries |\n| `{ method: "PUT"/"DELETE" }` | matching verb | Update / delete |\n| `{ method: "GET", path: "x" }` | custom route path | Non-default path |\n| `false` | never exposed as HTTP | `navigate`, `view-screen`, internal |\n\nMutating actions (anything but `GET`) auto-refresh the UI on success — don\'t call `refresh-screen` after a normal action. Overrides (`readOnly`, `parallelSafe`) and exact trigger rules: `references/action-fields.md`.\n\n## Return Values\n\nReturn **structured data** (objects, arrays), never `JSON.stringify()` — the framework serializes the response and only tries to parse a returned string as JSON, which isn\'t the same contract.\n\n```ts\nrun: async (args) => await fetchEvents(args.from, args.to); // good\nrun: async (args) => JSON.stringify(await fetchEvents(...)); // bad\n```\n\nA create/update result is read by more than the caller. These keys are well-known and survive result truncation:\n\n- `id` — the created or updated record. Pair it with a pure, synchronous `link` builder on the action (`link: (result) => ({ url: buildDeepLink({ app, view, params: { id: result.id } }), label })`) so MCP hosts and the desktop app surface an "Open …" deep link that lands in the editing view focused on the record; returning `url`/`urlPath` in the result works too.\n- `nextRequiredAction` — the name of the next **tool** to call when the operation is one step of a flow the agent should keep driving (`nextRequiredAction: "update-slide"`). Never phrase it as waiting for the user: an MCP/WebMCP/A2A caller cannot receive an in-app answer. The agent loop keeps this field in continuation prompts even when the rest of a large result is dropped, and MCP callers see it as `Next: …`.\n- `message`/`summary` — the one-line status external callers read; everything else stays in the structured result.\n- `designSystem` — when a record can link a brand or design system, expose it as `designSystem: AgentDesignSystemContext | null` via `loadAgentDesignSystemContext(id, getDesignSystemAction)` from core\'s shared `design-system-agent-context`. Reads get the bounded summary (`scope: "summary"`, with a `next` line naming the full read); only the create action and `get-design-system` itself pass `{ full: true }`. `status: "unavailable"` is not `null`: keep the id and the message. Print it in text results with `formatAgentDesignSystemContext`; do not name the field anything else.\n\nFor actions that attach a `chatUI` renderer, use `chatUI.projectResult` to return\nonly the small structured fields the renderer needs. `chatUI.when` is evaluated\nagainst the full successful result first; the projection is used live and saved\nfor interrupted-run recovery.\n\nAn action that hands control back to the user (question form, intake dialog) sets `endsTurn: true`; that hides it from MCP/WebMCP/A2A unless `mcpTool: true` is explicit — `references/action-fields.md`. For external-agent integrations, use the external-agents documentation slug listed by `agent-native-docs`.\n\nReach for `outputSchema` (validate the return), `_agentImages` (attach images the agent can see), `authorize` (gate who may call it), or `needsApproval` (require human sign-off per call) only when the action needs that guarantee — examples in `references/action-fields.md`.\n\n### Write receipts\n\nA write action that can check its own effect returns a plain-object result with a reserved `_receipt`, so the final answer is reconciled with what the write did, not with the model\'s reading of a JSON string that may be truncated:\n\n```ts\nimport type { WriteReceipt } from "@agent-native/core/action";\n\nconst _receipt: WriteReceipt = {\n  changed: true,\n  verified: false,\n  summary: "Saved; panel 3 returned no rows.",\n  checks: [{ id: "panel-3", ok: false, detail: "0 rows" }],\n};\nreturn { id, _receipt };\n```\n\n`verified` is `true` (the effect was observed), `false` (checked and did not hold), or `"unverified"` (could not be checked); `checks` and `warnings` are optional. The agent loop reads the receipt before the result is stringified and truncated (summary 200 chars, 8 checks, 5 warnings):\n\n- `verified: false` or `changed: false` forces one honest-reconciliation retry per turn: the model must say what the receipt shows and may not call the change visible or working. If the retry is spent, the answer is prefixed with the receipt block.\n- `verified: "unverified"` only prefixes that note; no retry.\n- A receipt that is present but malformed counts as `unverified`, never clean. `changed: false` also records the call as `completedSideEffect: false`, unless a write nested in the action also entered its handler: a receipt, like `retrySafe`, speaks only for the action\'s own write.\n- Set `subject` (the stable target, such as a dashboard id) so a later `changed: true, verified: true` receipt for the same subject can supersede an earlier flagged one in the same turn. When the earlier receipt had failing or unverified `checks`, the later receipts (from this action or another that writes the same subject) must carry an `ok: true` check with the same `id` for each; a receipt without checks never clears one that had them. A flagged receipt with no failing checks is superseded only by the same action. Receipts without a `subject` are never superseded.\n\nA receipt is not an error channel. A write that did not achieve the requested state throws (`fail()`); return `changed: false` only for a benign no-op, such as the record already being in the requested state.\n\n## Frontend Hooks\n\nImport from focused `@agent-native/core/client/*` entry points; the broad\n`@agent-native/core/client` barrel is deprecated. Use action hooks, not\nhand-written `fetch("/_agent-native/actions/...")`.\n\n```ts\nimport { useActionQuery, useActionMutation, callAction } from "@agent-native/core/client/hooks";\n\nconst { data: meals } = useActionQuery("list-meals", { date: "2025-01-01" }); // GET, types auto-inferred\nconst { mutate } = useActionMutation("log-meal");                             // POST/PUT/DELETE\nmutate({ name: "Salad", calories: 350 });\nconst people = await callAction("search-people", { query }, { method: "GET" }); // imperative (debounce, prefetch)\n```\n\nDon\'t add manual generics like `useActionQuery<Meal[]>(...)` — types come from `.generated/action-types.d.ts`. Mutations auto-invalidate all `["action"]` query keys, so GET queries refetch. A revisit paints the persisted result for the signed-in user and org before that refetch; see `references/action-fields.md` for `persistInBrowser: false`.\n\nWhen a query result varies by viewer or another client context that is not part of the action arguments, pass that stable context through `queryKeyScope`. It partitions only the local query cache; it is not sent to the action and never replaces server-side authorization.\n\n## How to Run (Agent)\n\n```bash\npnpm action log-meal --name "Salad" --calories 350\n```\n\nCLI flags become action input fields (`--key value` or `--key=value`); the runner does not read or write files for `--input` or `--output`. The default template dispatches through core\'s `runScript()` in `actions/run.ts`. Action names are lowercase-with-hyphens (`pnpm action my-action` → `actions/my-action.ts`).\n\nAfter adding or changing several related actions, smoke-test **once** (one\nhappy-path call that proves the wire-up), then typecheck once. Do not run\n`pnpm action …` for every method unless a smoke test failed and you need to\nisolate which action broke.\n\n## CRUD + Drizzle in this starter\n\nBefore hunting through `node_modules` for DB helpers, read:\n\n1. `drizzle/START_HERE.md` — where tables live + migrate commands\n2. `drizzle/crud-action-example.ts` — copy-paste list/create/update/delete pattern\n\nDB client: `getDb` / `schema` from `server/db.ts`.\n\n## Custom `/api/` Routes\n\nComplete exception list — justified only when the caller isn\'t your own UI/agent, or the payload isn\'t JSON: **file uploads** (actions take JSON, not multipart), **streaming** (SSE/chunked needing direct H3 control), **webhooks**, **OAuth callbacks** (fixed redirect URL patterns), **public unauthenticated endpoints** (SEO/OG images, share links), **binary/non-JSON responses**.\n\nEverything else — CRUD, settings, search, list/detail reads, auth state, anything the UI fetches as JSON — is an action. Needing middleware to scope a route to the current user is itself a signal it should be an action. Existing template `/api/*` CRUD routes are being migrated; do not add new ones.\n\n## Do / Don\'t\n\n- **Do** keep one action, one job; document a reusable action (when to use it, key args, return fields to preserve) in `AGENTS.md` once it\'s called from outside one narrow screen; promote workflow-heavy actions (provider-backed, cross-app, MCP/A2A, multi-step) into a skill.\n- **Do** use `fail(message, { errorCode, statusCode })` for user-friendly errors and import primitives from `@agent-native/core`(`/action`) instead of redefining them; use the core `upload-image` action or `uploadFile()` for durable images/files — never base64 into SQL, markdown, or action results.\n- **Do** signal failure by throwing, using `fail()` for expected caller-readable failures. Never return `{ error: ... }` as a failure result: a normal return is treated as a successful action. Reserve bare errors for unexpected internal faults.\n- **Do** use `fail()` rather than a bare `Error` for caller-readable failures. It carries the action\'s message, `errorCode`, and `details` to the browser and to agents; unexpected errors become a generic 500. Reserve bare throws for internal faults.\n- **Do** give `fail()` the status that matches the cause: it defaults to `400`, and `useActionQuery` retries only `429`, `502`, `503`, and `504`. Mutations do not retry; use transient statuses only for retryable failures.\n- **Do** render `actionErrorMessage(error) ?? yourCopy` in UI, never bare `error.message`. The message keeps an `Action <name> failed:` prefix that belongs in a console, so a toast built from it reads "Action update-brand-kit failed: That name is taken." The helper returns only what the action wrote, and `undefined` when nothing did (network drop, proxy HTML page), which is why the fallback is not optional.\n- **Do** pass a real `errorCode` when the agent should branch on the failure rather than re-read it. Codes other than the default `action_failed` are appended to the tool result as `(errorCode: not_found)`, on both the in-app agent and MCP. `details` follow as an `Error details: {...}` JSON line, and as `structuredContent.error` over MCP, capped at 2,000 characters, so keep them to what the agent acts on next: ids, limits, field names. The status never reaches either.\n- **Don\'t** re-export actions as REST — `/_agent-native/actions/:name` is already the REST surface; duplicating it under `/api/*` hides the operation from agents.\n- **Don\'t** reach for provider integrations, `outputSchema`, `authorize`, `needsApproval`, or `_agentImages` without checking `references/` first — each has sharp edges covered there, not here.\n\n## Troubleshooting\n\n- **Action not found / type mismatch** — filename must match the command (`pnpm action foo-bar` → `actions/foo-bar.ts`), and the action must be the file\'s **default** export. Multiple `defineAction` named exports in one file register only the default; split them into one file each.\n- **Args not parsing** — use `--key value` / `--key=value`; boolean flags are `--flag` (sets `"true"`).\n- **Frontend 405** — `http.method` doesn\'t match the hook (`useActionQuery` for GET, `useActionMutation` for POST/PUT/DELETE).\n- **Frontend gets undefined** — action must return structured data, not `JSON.stringify()`.\n\n## References\n\n- `references/provider-apis.md` — wiring a credentialed provider (HubSpot, Gong, Slack, …) for querying, reporting, or cross-source research.\n- `references/action-fields.md` — `outputSchema`, `authorize`, `needsApproval`, `_agentImages`, and exact auto-refresh rules.\n- `references/examples.md` — a second worked example and legacy bare-export patterns.\n\n## Related Skills\n\n- **storing-data** — Actions read/write data in SQL\n- **delegate-to-agent** — The agent invokes actions via `pnpm action <name>`\n- **real-time-sync** — Database writes from actions trigger change events to update the UI\n- **adding-a-feature** — Actions are area 2 of the four-area checklist\n- **client-methods** — Client code uses named helpers/hooks instead of raw REST calls\n',dir:`.agents/skills/actions`,extraFiles:[`references/action-fields.md`,`references/examples.md`,`references/provider-apis.md`],files:{"references/action-fields.md":'# Action Field Reference\n\nFull detail on the less-common `defineAction` fields and automatic behaviors.\nRead this when you need output validation, authorization, human approval,\nimage results, or the exact rules for the auto-refresh behavior — the happy\npath in SKILL.md doesn\'t need any of these.\n\n## Screen Refresh (automatic)\n\nThe framework auto-refreshes the UI after any successful mutating action. On completion of a non-`GET` action, the framework emits a change event with `source: "action"` that the client\'s `useDbSync` picks up and uses to invalidate `["action"]` React Query keys — so `list-*` / `get-*` hooks refetch without a full page reload. In-process calls emit directly; dev-mode `pnpm action ...` calls also write a durable marker so the web server sees child-process action changes.\n\nRules:\n\n- `http: { method: "GET" }` → read-only, does NOT trigger a refresh (inferred automatically).\n- Any other action (default `POST`, `PUT`, `DELETE`, or `http: false`) → treated as mutating, triggers a refresh on success.\n- To override the inference on an unusual action (e.g. a `POST` that only reads), pass `readOnly: true` on the action definition.\n- To let a mutating action run concurrently with other same-turn tool calls, pass `parallelSafe: true`. Only do this when the action is internally concurrency-safe and order-independent (for example, it uses an app-level lock or idempotent upsert semantics). Mutating actions remain serialized by default.\n- If a successful call hands control to the user — it renders a question, an intake form, or anything else the turn must wait on — pass `endsTurn: true` and make it the first or only call in the turn. It stops subsequent model steps and later calls, but cannot undo calls emitted before it. Without it a completion guard sees a turn that legitimately paused as one that failed to finish. `endsTurn: true` also hides the action from MCP, WebMCP, and A2A callers by default (`isActionExposedToExternalAgents` in core `action.ts`) — an external host has no in-app chat to receive the answer on. Pass `mcpTool: true` alongside it only when an external caller can complete the same operation without that answer.\n- Read results persist in the browser per signed-in user and org, so a revisit paints the last result before it refetches. Pass `persistInBrowser: false` on a read that must not outlive the page (secrets, one-time codes, another user\'s private data). Mutations never persist.\n- MCP hosts read tool annotations to decide how carefully to treat a call. Every MCP catalog advertises declared `mcpAnnotations` (`readOnlyHint`, `destructiveHint`, `openWorldHint`, optional `idempotentHint`); otherwise `/mcp` derives only `readOnlyHint` and an approval-based `destructiveHint`. Declare them on every action MCP advertises that is not read-only, with `destructiveHint: true` when it removes, overwrites, or replaces user content — recoverable Trash included — and mark idempotency-key-guarded writes `idempotentHint: true`. A contract test fails on a new undeclared write.\n\nAgents do NOT need to call `refresh-screen` after a normal action — it\'s already handled. `refresh-screen` is only needed when the agent mutates data via a path the framework can\'t see (e.g. writing to an external system the app mirrors) or when the agent wants to pass a `scope` hint for narrower invalidation.\n\n## Returning Images the Agent Can See (`_agentImages`)\n\nAn action\'s return object may include the well-known optional field\n`_agentImages` to attach vision images (screenshots, chart previews, rendered\ndesigns) to the tool result. The agent literally sees them — enabling visual\nself-review loops — while the field itself is stripped from the JSON text the\nmodel reads.\n\n```ts\nrun: async ({ dashboardId }) => {\n  const shot = await renderDashboardPng(dashboardId); // Buffer\n  return {\n    dashboardId,\n    panelCount: 6,\n    _agentImages: [\n      // Either a public https URL (preferred — the provider fetches it)…\n      { url: "https://cdn.example.com/previews/dash-1.png", label: "overview" },\n      // …or base64 without a data: prefix (mediaType required; a full\n      // data:image/png;base64,… URL in `data` is also accepted and parsed).\n      { data: shot.toString("base64"), mediaType: "image/png" },\n    ],\n  };\n},\n```\n\nRules and limits:\n\n- Shape: `Array<{ url?: string; data?: string; mediaType?: string; label?: string }>`.\n  Each entry needs `url` (https only) **or** `data`. Supported media types:\n  `image/jpeg`, `image/png`, `image/gif`, `image/webp`.\n- Caps: max **4 images** per result; max **~2MB of base64** per image.\n  Over-cap or invalid entries never fail the call — they become text notes in\n  the result telling the model what was dropped and why.\n- Persistence: the run ledger stores only the string result plus compact\n  `[image: …]` notes (URLs verbatim; base64 as a byte-count placeholder) —\n  never the payload. Images are re-attached only for the live turn; replayed\n  history is text-only, so prefer stable `url` images the model can re-request.\n- Engine support: native Anthropic and vision-capable AI-SDK providers\n  (anthropic, openai, google, openrouter) receive real image blocks; other\n  paths (Builder gateway, non-vision providers) degrade to the text notes.\n- External MCP tools need no changes — standard MCP `image` content parts are\n  converted automatically under the same caps.\n\n## Validating Return Values (`outputSchema`)\n\n`schema` validates inputs; `outputSchema` validates what the action **returns**. Pass any Standard Schema-compatible schema (Zod, Valibot, ArkType) and the framework validates the result _after_ `run()` resolves — input validated before `run`, output after.\n\n```ts\nexport default defineAction({\n  description: "Summarize a thread.",\n  schema: z.object({ threadId: z.string() }),\n  outputSchema: z.object({ summary: z.string(), messageCount: z.number() }),\n  outputErrorStrategy: "warn", // default; "strict" | "fallback"\n  // outputFallback: { summary: "", messageCount: 0 }, // used only by "fallback"\n  run: async ({ threadId }) => {\n    /* ... */\n  },\n});\n```\n\n- `"warn"` (default) — `console.warn` the issues and return the **original** result unchanged. Non-breaking, with one exception: a connection request or stop signal thrown while the result is checked (from a transform or refinement) still ends the call as that signal, with a framework message in place of its own.\n- `"strict"` — throw `ActionOutputContractError` (`errorCode: "output_contract_violation"`) so a buggy action surfaces loudly.\n- `"fallback"` — return `outputFallback` in place of the invalid result.\n\nOn success the validated value is returned, so coercion/defaults on `outputSchema` apply. Omit `outputSchema` and behavior is byte-for-byte unchanged (no wrapping).\n\nThe strict error and such a signal run after `run()`, so they carry `effect`: `"committed"` once a write entered its handler, in the call or in one nested in it (even under a read-only action), and `"none"` otherwise. Writes are classified from the validated arguments, defaults applied. The agent loop, the plan-mode registry, HTTP action routes, and MCP prepare each call once (validated arguments plus that classification) and run exactly that preparation: approval, plan mode, write blocking, batching, and replay all read it, and the run does not parse the arguments again. Preparation reads the validated arguments once into a frozen, plain-data snapshot and hashes it; each gate and `run()` gets its own copy of that snapshot, never the snapshot itself, so mutating `args` in a gate or a handler changes nothing anyone else reads. Validated arguments must therefore be plain data: objects, arrays, strings, numbers, booleans, `null`, `undefined`, BigInts, and valid Dates. A schema whose output holds anything else (a getter or setter, a `Map` or `Set`, a class instance, a function) makes every call fail as invalid. Preparation, its refusals and the per-consumer copies cover calls the agent loop, plan mode, HTTP action routes, and MCP dispatch; a direct `action.run()` (one action composing another, the dev action bridge) gets schema validation only. A call whose arguments are invalid fails before any of them and never reaches the handler. Every reuse of a call\'s outcome keys on the snapshot\'s hash, never on the raw input: a continued turn replays a call only when it recorded a committed effect for the same hash, reads are reused only for the same hash, and an interrupted write recovers only a result recorded for the same hash, otherwise it stops instead of running again. The message names only declared field paths and issue codes, never output values, and tells the caller not to retry a committed write. A connection request keeps its `provider`, `reason`, `appId`, and `source` in its fields, in its message, and in HTTP `details`.\n\nMCP clients see no `outputSchema` by default. Set `mcpOutputSchema: true` (requires `outputErrorStrategy: "strict"`) only after auditing that every real result matches: the tool then advertises the schema as MCP sees it (an array root becomes `{ items }`, linked actions gain `openLink`/`url`), and each `structuredContent` is validated against it before it is returned. Roots must be an object, an object-only union, or an array, and schemas with transforms cannot opt in. The advertised schema allows for MCP\'s redaction (embed ticket fields dropped; a string holding an embed start URL arrives as `"[hidden embed URL]"`, so required fields stay required). A schema is refused at definition time if it uses a keyword or `format` the check cannot enforce (`not`, `$async`, an unknown format), if redaction could break its `const`, `enum`, or `uniqueItems`, or if a linked action\'s root limits its property names or count.\n\n## Authorization (`authorize`)\n\n`authorize` decides whether the caller may run the action at all. It wraps\n`run`, so it holds at **all six dispatch sites** — agent tool, HTTP, frontend\nhook, MCP, A2A, CLI — unlike `needsApproval`, which is honoured only in the\nagent loop. Use `authorize` for "not everyone may do this"; use `needsApproval`\nto ask a human to bless one call a permitted caller is already allowed to make.\n\n```ts\nimport { coachAccess } from "../lib/access.js"; // defineAppRoles(...)\n\nexport default defineAction({\n  description: "Archive a client roster.",\n  schema: z.object({ id: z.string() }),\n  authorize: coachAccess.requireAny("coach-admin"),\n  run: async (args) => {\n    /* ... */\n  },\n});\n```\n\nThe wrappers compose as `validate input -> authorize -> run -> validate output\n-> audit`: the gate sits inside input validation, so a guard reading `args` gets\nthe parsed, coerced value, and auditing is outermost, so denials are recorded.\n\nA guard that throws denies with its own message; returning `false` denies\ngenerically; anything else (including `undefined`) allows. A guarded action\nneeds a user identity, so an unattended CLI/cron caller with no user email is\ndenied. `authorize` gates the operation; `accessFilter` / `assertAccess` still\nscope which rows a permitted caller may touch. Use `agent-native-docs` to find\nthe current authentication and sharing documentation when adding role checks.\n\n## Human-in-the-Loop Approval (`needsApproval`)\n\nFor high-consequence, outward-facing, hard-to-undo actions (sending an email, charging a card, deleting an account), set `needsApproval` so the agent **cannot** run the action without a human approving the specific call:\n\n```ts\nexport default defineAction({\n  description: "Send an email via Gmail.",\n  schema: z.object({ to: z.string(), subject: z.string(), body: z.string() }),\n  needsApproval: true, // boolean, or (args, ctx) => boolean | Promise<boolean>\n  run: async (args) => {\n    /* ...actually send... */\n  },\n});\n```\n\nWhen the gate is truthy and the call isn\'t yet approved, the loop emits an `approval_required` event and **stops the turn — `run()` never executes**. A predicate gates conditionally (e.g. only external recipients) and **fails closed**: a throw is treated as "approval required". It receives its own copy of the prepared snapshot of the validated arguments, defaults applied, and the approval binds to the snapshot\'s hash, so an approved call runs only with the arguments that were approved (a Date binds by its time). The human approves via the chat UI\'s Approve affordance, which re-issues the turn with the call\'s `approvalKey`, and only then does the action run.\n\n**Keep approvals rare** — the default is off and almost every action should leave it off. The canonical example is Mail\'s `send-email` (`needsApproval: true`). See the `security` skill and the Human Approval doc.\n',"references/examples.md":`# Extra Action Examples and Compatibility Patterns

Read this for a second worked example beyond the one in SKILL.md, for the
legacy \`parameters\` form or CLI-only bare-export action you may find in
existing code.

## Common Patterns

**Read action (GET):**

\`\`\`ts
import { z } from "zod";
import { defineAction } from "@agent-native/core/action";

export default defineAction({
  description: "List calendar events",
  schema: z.object({
    from: z.string().describe("Start date"),
    to: z.string().describe("End date"),
  }),
  http: { method: "GET" },
  run: async (args) => {
    return await fetchEvents(args.from, args.to);
  },
});
\`\`\`

**Write action (POST, default):**

\`\`\`ts
import { z } from "zod";
import { defineAction } from "@agent-native/core/action";

export default defineAction({
  description: "Log a meal",
  schema: z.object({
    name: z.string().describe("Meal name"),
    calories: z.coerce.number().describe("Calorie count"),
  }),
  run: async (args) => {
    // args.calories is a number — z.coerce.number() handles string-to-number conversion from HTTP
    const meal = await insertMeal(args);
    return meal;
  },
});
\`\`\`

**Agent-only action:**

\`\`\`ts
import { z } from "zod";
import { defineAction, fail } from "@agent-native/core/action";
import { writeAppStateForCurrentTab } from "@agent-native/core/application-state";

export default defineAction({
  description: "Navigate the UI to a view or path",
  schema: z.object({
    view: z.string().optional().describe("Target view"),
    path: z.string().optional().describe("URL path to navigate to"),
  }),
  http: false,
  run: async (args) => {
    if (!args.view && !args.path) {
      fail("At least --view or --path is required.", {
        errorCode: "invalid_navigation",
      });
    }
    const navigation: Record<string, string> = {};
    if (args.view) navigation.view = args.view;
    if (args.path) navigation.path = args.path;
    navigation._writeId = \`\${Date.now()}-\${Math.random().toString(36).slice(2, 8)}\`;
    await writeAppStateForCurrentTab("navigate", navigation);
    return { message: \`Navigating to \${args.view || args.path}\` };
  },
});
\`\`\`

## Legacy \`parameters\` Field

The older \`defineAction\` form accepts a JSON Schema object through \`parameters\`. It still supplies the agent's input schema and infers TypeScript args for supported parameter shapes, but does not provide the Standard Schema validation and transforms of \`schema\`. Prefer \`schema: z.object({...})\` for new actions and when updating existing ones.

## Legacy Pattern (bare export)

Older actions use a bare async function export with \`parseArgs\`:

\`\`\`ts
import { parseArgs, loadEnv, fail } from "@agent-native/core";

export default async function myAction(args: string[]) {
  loadEnv();
  const parsed = parseArgs(args);
  // ...
}
\`\`\`

The CLI runner still accepts this function form, but it is CLI-only: it is not registered as an agent tool, does not mount an HTTP endpoint, and has no typed frontend hook. Prefer \`defineAction\` for actions shared with the agent or UI. See \`actions-advanced\` for this legacy form and its helpers.
`,"references/provider-apis.md":`# Provider API Integrations

Read this when an action needs to call an external provider API — HubSpot,
Gong, Slack, any credentialed third-party service — for ad hoc analysis,
querying, reporting, or cross-source research.

For provider integrations used in ad hoc analysis, querying, reporting, or
cross-source research, do not hardcode every provider endpoint as a separate
rigid action and do not encode one lookback window, filter shape, or pagination
strategy as the only path the agent can take. Expose the shared provider API
action trio instead:

- \`provider-api-catalog\`: lists provider base URLs, auth style, credential keys,
  docs/spec URLs, placeholders, and examples without exposing secrets.
- \`provider-api-docs\`: fetches public provider docs/spec/changelog URLs when
  the exact endpoint, filter operator, payload shape, or pagination contract is
  uncertain. Registered docs URLs are curated starting points. Use
  \`responseMode: "markdown"\` for clean readable docs, or
  \`responseMode: "matches"\` with \`search: { query | terms | regex }\` for
  compact snippets instead of flooding context with raw HTML.
- \`provider-api-request\`: makes a constrained authenticated HTTP request to the
  provider host, injects configured credentials, blocks private/internal URLs,
  and redacts secrets.

Use \`@agent-native/core/provider-api\` as the shared substrate, and build these
actions as thin factory imports rather than copying \`defineAction\` schemas and
handlers into each template:

\`\`\`ts
import {
  createProviderApiCatalogAction,
  createProviderApiDocsAction,
  createProviderApiRequestAction,
} from "@agent-native/core/provider-api/actions/provider-api";
import {
  createDeleteStagedDatasetAction,
  createListStagedDatasetsAction,
  createQueryStagedDatasetAction,
} from "@agent-native/core/provider-api/actions/staged-datasets";
\`\`\`

Pass the app's existing provider runtime to the provider factories, and pass
its app id to the staged-dataset factories. Keep app-specific descriptions,
provider allow-lists, HTTP/tool-callability settings, and credential adapters
as factory options. Only add a thin credential adapter when the app has
app-specific credential lookup rules. If the app stores a built-in provider's
OAuth grant under a narrower local provider id, use the runtime's
\`oauthProviderOverrides\` instead of duplicating provider config. If credentials
are stored on shareable/resource rows rather than in the shared credential or
OAuth-token stores, build a resolver that enforces those access checks before
exposing raw provider requests. Keep \`provider-api-request\` \`http: false\`
unless a separate UI permission model authorizes arbitrary provider writes.
Specific actions such as \`search-records\`, \`search-emails\`, or \`sync-source\`
are convenience shortcuts, not capability limits; agents should fall back to
the provider API trio when a question requires an endpoint or filter that the
shortcut does not model.

This is a framework tenet. The safety boundary should be provider host
allow-listing, credential scoping, auth injection, private-network blocking,
secret redaction, and user/org access checks, not an artificially small set of
hand-authored read actions. If the upstream provider API supports a capability,
the agent should normally be able to reach it through \`provider-api-request\`
with the user's configured credentials. For large responses, expose staging
(\`stageAs\`, \`itemsPath\`, pagination, and \`query-staged-dataset\`) or sandboxed
code execution so the agent can reduce data without flooding context.

For broad provider questions, cross-source joins, corpus-wide mention/search
work, classification, or any answer where absence matters, design the action
surface for full coverage instead of convenience-only samples. The agent should
be able to fetch every relevant page or an explicitly bounded cohort, stage or
save the raw provider response outside chat, and then use
\`query-staged-dataset\`, \`run-code\`, or provider-side search to count, join,
grep, classify, and aggregate. Tool descriptions and AGENTS.md guidance should
teach agents to report source, filters, time window, row/record counts,
pagination status, truncation, failed pages, and uncovered gaps. They must not
turn default limits, sampled rows, truncated excerpts, or aborted calls into a
confident "none found", "all records", or exhaustive conclusion.

For public web pages and docs, prefer the token-efficient path: \`web-search\`
to find likely URLs, \`web-request\` or \`provider-api-docs\` with clean
\`responseMode\` output to read a page, and \`run-code\` with \`webRead()\` /
\`webFetch()\` when you need to grep, aggregate, or compare many pages before
returning a small result.

For LONG compute, \`run-code\` supports durable background executions: pass
\`background: true\` and the code is enqueued to a \`sandbox_executions\` row and
executed out-of-band with a generous budget (default 10 min), surviving the
hosted agent run's ~40s soft timeout. The call returns
\`{ executionId, status: "queued" }\` immediately with polling guidance; check
progress with \`run-code\` \`{ executionId }\` (or the \`get-code-execution\` tool
where registered) — results persist after completion. Use background for big
cross-source joins, multi-page provider sweeps, and heavy analysis scripts;
keep quick scripts in the default foreground mode. Agents should continue
other work between polls, and on \`failed\`/\`timed_out\` split the computation or
persist intermediate progress with \`workspaceWrite\` and re-run.
`}},"adding-a-feature":{meta:{name:`adding-a-feature`,description:`The four-area checklist every new feature must complete. Use when adding any feature, integration, or capability to ensure the agent and UI stay in parity.`,scope:`dev`},content:'---\nname: adding-a-feature\ndescription: >-\n  The four-area checklist every new feature must complete. Use when adding any\n  feature, integration, or capability to ensure the agent and UI stay in parity.\nscope: dev\nmetadata:\n  internal: true\n---\n\n# Adding a Feature — The Four-Area Checklist\n\n## Rule\n\nEvery new feature MUST update all four areas. Skipping any one breaks the agent-native contract — the agent and UI must always be equal partners.\n\nScope check first: this is the checklist for a feature that adds app data or a new capability. A restyle, a copy change, or a screen with no new data model and no new agent-visible operation only needs the areas it actually touches — do not manufacture actions, state keys, or a skill for it.\n\n## Why\n\nAgent-Native apps are defined by parity: everything the UI can do, the agent can do, and vice versa. A feature that only has UI is invisible to the agent. A feature that only has scripts is invisible to the user. A feature without app-state sync means the agent is blind to what the user is doing.\n\n## The Checklist\n\nWhen you add a new feature, work through these four areas in order:\n\n### 1. UI Component\n\nBuild the user-facing interface — a page, component, dialog, or route. Use `useActionQuery` and `useActionMutation` from `@agent-native/core/client/hooks` to call actions for data fetching and mutations. Do not create a custom REST endpoint just so React can call action-backed data; the action endpoint already exists.\n\n**Agent edits must refresh the UI without a background poll.** Local chat-run\ntool completions invalidate action queries and source counters after each\nside-effecting tool and again at run end. There are two query paths:\n\n- **`useActionQuery` / `useActionMutation`** — local action mutations invalidate `[\'action\']` observers, and chat-run tool completions invalidate them for agent writes. No background sync opt-in is needed for the current user\'s agent run. **Prefer this path.**\n- **Raw `useQuery` with custom keys** — fold `useChangeVersions([<source>, "action"])` from `@agent-native/core/client/hooks` into the `queryKey` and set `placeholderData: (prev) => prev`. Local chat-run side effects bump those counters too. Remote changes require the page\'s explicit `useDbSync({ realtime: { reason } })` opt-in only when data changes without the current user acting and must appear before refresh.\n\nNever opt in public, anonymous, marketing, docs, or SSR routes, settings,\nforms, or read-mostly lists. Refetch those on focus or navigation. Shared Slides\nediting and the Mail inbox are the current first-party examples that need\nremote updates. Each opted-in open tab adds a shared background transport and\none poll per idle interval; hidden tabs pause, and idle polling backs off to 1,\n2, then 5 minutes. See `real-time-sync` for the decision rule and examples.\n\n  ```tsx\n  import { useChangeVersions } from "@agent-native/core/client/hooks";\n  import { useQuery } from "@tanstack/react-query";\n\n  const v = useChangeVersions(["dashboards", "action"]);\n  useQuery({\n    queryKey: ["dashboard", id, v],\n    queryFn: () => fetchDashboard(id),\n    placeholderData: (prev) => prev, // no flicker on refetch\n  });\n  ```\n\n  See the `real-time-sync` skill for the full pattern and source catalog.\n\n### 2. Action\n\nCreate an action in `actions/` using `defineAction`. This serves double duty: the agent calls it as a tool, and the UI calls it through `useActionQuery` / `useActionMutation` while the framework owns the HTTP transport. Set `http: { method: "GET" }` for read actions, leave default for writes, or set `http: false` for agent-only actions like `navigate` and `view-screen`.\n\nBefore adding a new route or endpoint, inspect the existing actions. Reuse an\naction if it already covers the business operation, extend it if the shared\ncontract is incomplete, or create a new `defineAction` if the agent and UI both\nneed the capability. Do not add pass-through `/api/*` routes that re-export\nactions. If client code needs a new framework/app route, expose a named helper\nor hook first and use that helper from components and docs.\n\nFor provider-backed analysis/query/reporting integrations, do not turn every\nprovider endpoint or filter into a rigid action. Prefer the shared\n`provider-api-catalog` / `provider-api-docs` / `provider-api-request` pattern\nfrom `@agent-native/core/provider-api`, then add narrow convenience actions only\nfor workflows that truly deserve a first-class shortcut. Treat this as a\ncapability requirement, not a nice-to-have: convenience actions must not become\nthe ceiling of what the agent can ask the provider to do. Pair broad provider\naccess with staging or sandboxed code execution when responses may be too large\nfor chat context. If provider credentials live on resource/share rows, add the\nscoped resolver first so broad access preserves the same ownership boundary as\nthe app UI.\n\nIf the feature needs credentials, design the credential path in the same change.\nNever hardcode credentials or include personal or customer data in source,\nfixtures, docs, prompts, or generated app content. Register required secrets,\nuse OAuth helpers, or read scoped values from the credential store.\n\nBefore writing custom setup or credential UI, perform the shared-primitive\npreflight from `agent-native-toolkit`: inspect the workspace/provider connection\ncatalog first, then settings, secrets/vault, OAuth, onboarding, and provider API\nsupport. Reuse an existing connection\'s app grant and scoped credential\nresolver; only use app-local vault or OAuth primitives when no reusable\nconnection exists. Keep any wizard thin and provider-specific - it may explain\nprerequisites, ordering, or readiness, but must not become a second vault or\ncustom credential transport. Do not mark each field `required` by reflex;\nmodel onboarding around the logical connection outcome.\n\nIf the feature involves attachments, images, recordings, screenshots, exports,\nor other file-like payloads, design the upload path in the same change:\nprovider upload first, then URL/id/blob handle in SQL. Do not add base64/binary\ncolumns or stuff files into `application_state`.\n\nIf the feature adds a heavy server-side dependency, read the startup guidance in\n`performance` before adding it. Keep expensive setup and processing out of\nrequest-startup paths; use a background job when the work does not need to block\nthe current request.\n\n**If the action produces or lists a navigable resource**, add a `link` builder that returns `{ url: buildDeepLink({ app, view, params }), label }`. MCP hosts can surface a deep link that returns the user to the running app at that record. If a compatible host should render an inline review or edit surface, also add `mcpApp` with `embedApp()` so the action embeds the real app route. Keep `link` and `mcpApp` metadata pure and synchronous. Use the external-agent documentation when exposing actions to other agent hosts.\n\nScaffolding a new app of a known type (slides, design, content, forms)? Start from that template\'s `AGENTS.md` and `.agents/skills/`, not a blank app.\n\n### 3. Skills / Instructions\n\nUpdate `AGENTS.md` and/or create a skill in `.agents/skills/` if the feature introduces patterns the agent needs to know. At minimum, add the new actions to the action table in the template\'s `AGENTS.md`.\n\nBefore completing this area, identify the feature\'s primary actions:\n\n- Document primary workflows in the `AGENTS.md` action table.\n- If the app configures `initialToolNames` (`INITIAL_TOOL_NAMES` in some\n  templates), add the primary actions there. If it uses per-action loading,\n  mark the complete starter set `deferLoading: false`; once one action opts in,\n  unmarked actions are deferred. The remaining actions stay discoverable through\n  `tool-search`.\n- If `mcp.keyToolNames` is configured, align it with primary actions actually\n  served on MCP/WebMCP. It controls the external key-tools list and does not\n  change the in-app agent\'s first-turn list.\n\nReusable actions are part of the app contract, not just implementation detail. When an action is useful outside one screen, update agent instructions in the same change so app agents know when to call it, which arguments matter, and what output to preserve. If the capability is workflow-heavy, cross-app, provider-backed, or has a non-obvious sequence of actions, add or update a skill instead of burying the behavior in one long `AGENTS.md` paragraph.\n\n- For chat prompt dispatch, put the readiness gate at the shared dispatch boundary and cover submits, retries, edits/forks, queue drains, continuations, and imperative sends. Dispatch only after readiness is authoritatively configured; return a typed setup-required error and preserve the draft when readiness is missing or unavailable. Composer checks and setup cards are UX, not enforcement, and no new `...ChecksEnabled={false}` bypass is allowed.\n\nInstruction examples may name secret keys like `SLACK_WEBHOOK`, but must use\nplaceholders such as `${keys.SLACK_WEBHOOK}` or `<SLACK_WEBHOOK>`. Do not paste\nreal keys, internal data, or customer data into instructions as examples.\n\nIf the feature adds or changes visible UI copy, prompts, toasts, labels, empty\nstates, or formatting, edit the English strings inline in components. Do **not**\nadd i18n catalogs unless the user explicitly asks for localization; only then\nread the `internationalization` skill.\n\nFor app-backed skills, declare skill visibility in the app-skill manifest:\n\n- `internal` — only the app\'s own agents should use it.\n- `exported` — marketplace installs receive it, but the app does not need it loaded internally.\n- `both` — shared between the app\'s internal agents and exported marketplace bundles.\n\n### 4. Application State Sync\n\nExpose navigation and selection state so the agent knows what the user is looking at. Write to the `navigation` app-state key on route changes. Update the `view-screen` action to fetch relevant data for the new feature. Add a `navigate` command if the agent needs to open the new view. Text resources participate in `export-resource-pack`; binaries and secrets do not.\n\n## Examples\n\n### Adding "compose email" to a mail app\n\n| Area | What to build |\n| --- | --- |\n| UI | Compose panel with tabs, to/cc/bcc fields, body editor. Use `useActionQuery`/`useActionMutation` for data. |\n| Action | `manage-draft` action (create/update/delete drafts), `send-email` action |\n| Skills/AGENTS | Document compose state shape, draft lifecycle, action args in AGENTS.md |\n| App-state sync | `compose-{id}` keys for each draft tab, `navigation` includes compose state |\n\n### Adding "create form" to a forms app\n\n| Area | What to build |\n| --- | --- |\n| UI | Form builder page with drag-and-drop fields, preview, settings. Use `useActionQuery` for lists. |\n| Action | `create-form` action, `update-form` action, `list-forms` action (GET) |\n| Skills/AGENTS | Document form schema shape, field types, validation rules in AGENTS.md |\n| App-state sync | `navigation` includes `{ view: "form-builder", formId: "..." }`, `view-screen` fetches form data |\n\n### Adding "chart type" to an analytics app\n\n| Area | What to build |\n| --- | --- |\n| UI | New chart component, chart type selector in dashboard |\n| Action | `create-chart` or `update-dashboard` action that sets chart type and config |\n| Skills/AGENTS | Document supported chart types, config options, data requirements |\n| App-state sync | `navigation` includes selected chart/dashboard, `view-screen` returns chart config |\n\n## Adding a new route\n\nTemplates are single-page apps with client-side routing. The app shell (AgentSidebar + top-level nav) MUST persist across navigation — it is mounted once, either in `root.tsx` around `<Outlet />` or via a pathless `_app.tsx` layout route that all authed routes nest under.\n\n**Never wrap each new route in its own `<AppLayout>` / `<Layout>`.** That causes React to unmount the entire app shell on every navigation, reloading the agent sidebar and destroying in-progress work.\n\n- If the template has `<AppLayout>` in `root.tsx` — just render page content in your new route file, nothing else.\n- If the template has `app/routes/_app.tsx` (pathless layout) — name your new route `_app.<segment>.tsx` to inherit the shell, or bare `<segment>.tsx` for public routes that should NOT have the shell.\n- If a page needs per-route data (e.g. highlighting the active item in the sidebar), read it in the layout from `useParams()` / `useLocation()`. Don\'t pass it as a prop through every route file.\n\nSee the "Client-Side Routing" section in the root `CLAUDE.md` for full details.\n\n## Anti-Patterns\n\n- **Per-route `<AppLayout>` wrappers** — Every route file wraps its content in `<AppLayout>` or `<Layout>`. React sees a different component at the outlet on each nav and unmounts the whole shell, causing the agent sidebar to reload on every click. Mount the shell once above `<Outlet />` (root.tsx or `_app.tsx` pathless layout).\n- **UI without actions** — The user can create forms but the agent cannot. The agent says "I don\'t have access to that" when it should be able to do it.\n- **Actions without AGENTS.md** — The actions exist but the agent doesn\'t know about them because they\'re not documented. The agent reinvents solutions instead of using the actions.\n- **Duplicate API routes** — Creating `/api/` routes for operations that actions already handle, including pass-through routes that just call or repackage an action. Use `useActionQuery`/`useActionMutation` instead.\n- **Raw client route calls** — Teaching or adding `fetch("/_agent-native/...")`,\n  `fetch(agentNativePath(...))`, or template `/api/*` calls in components for\n  normal app work. Add a named client helper/hook and call that instead.\n- **Features without app-state** — The agent cannot see that the user is looking at a specific form, email, or chart. It asks "which one?" instead of acting on the current selection.\n- **Actions without UI** — The agent can do something the user cannot. This is less common but still breaks parity.\n\n## Verification\n\nAfter completing all four areas, verify:\n\n1. Can the user perform the operation from the UI?\n2. Can the agent perform the same operation via actions?\n3. Does `pnpm action view-screen` show the relevant state when the user is using the feature?\n4. Can the agent navigate to the feature view via the `navigate` action?\n5. Is the feature documented in AGENTS.md with action names and args?\n6. Are credentials supplied through approved runtime channels, with no\n   hardcoded keys, tokens, or user data?\n\n## One more area — sharing\n\nIf the feature stores **user-authored resources** (documents, dashboards, forms, decks, etc.), make them ownable so they get private-by-default semantics and a share dialog for free. See the `sharing` skill.\n\nTL;DR: spread `ownableColumns()` into the resource table, pair it with `createSharesTable(...)`, call `registerShareableResource(...)`, wrap list/read queries with `accessFilter`, guard writes with `assertAccess`, and drop `<ShareButton>` in the resource header. The `share-resource`, `unshare-resource`, `list-resource-shares`, and `set-resource-visibility` actions are auto-mounted framework-wide.\n\n## One more area — who inside the app may do it\n\nIf only some teammates may perform a feature (such as an admin-only import), use a per-app role rather than creating an organization or using a share grant. Use `agent-native-docs` to find the current role guide if needed.\n\nTL;DR: declare the vocabulary once with `defineAppRoles({ appId, roles, defaultRole })`, guard the action with `authorize: appAccess.requireAny("...")`, and render the picker with `<TeamPage appRoles={descriptor} />`. `defaultRole` is display only — it never satisfies a guard — and `authorize` gates the operation while `accessFilter` / `assertAccess` still scope the rows.\n\n## Related Skills\n\n- **sharing** — How to make a new resource ownable (private by default, share with users/orgs/public)\n- **context-awareness** — How to expose UI state to the agent (area 4 in detail)\n- **actions** — How to create actions with `defineAction` and the `http` option (area 2 in detail)\n- **build-an-app** — Start a complete app from a vague domain prompt\n- **storing-data** — Where to store the feature\'s data\n- **real-time-sync** — How the UI stays in sync when the agent writes data\n- **performance** — Query/load cost and expensive startup work\n- **agent-native-docs** — Find current docs for roles, external agents, or localization\n',dir:`.agents/skills/adding-a-feature`,extraFiles:[],files:{}},"agent-engines":{meta:{name:`agent-engines`,description:`How to inspect and configure the AI engine (model provider) powering the agent. Use when the user asks to switch models, check which engine is active, test a new provider, or register a custom engine.`,scope:`both`},content:'---\nname: agent-engines\ndescription: >-\n  How to inspect and configure the AI engine (model provider) powering the\n  agent. Use when the user asks to switch models, check which engine is active,\n  test a new provider, or register a custom engine.\n---\n\n# Agent Engines\n\n## Overview\n\nThe framework supports pluggable AI engines beneath the agent loop. The **Anthropic engine** is the default and best-in-class path (Claude models). Additional engines can be added via the Vercel AI SDK (OpenAI, Google Gemini, Groq, Mistral, Cohere, Ollama).\n\n## Available Tools\n\n| Tool | Purpose |\n|---|---|\n| `list-agent-engines` | List all registered engines, their capabilities, the current selection, and whether you can change the organization default (`canUpdateDefault`) |\n| `set-agent-engine` | Set the organization\'s default engine and model (owners and admins only) |\n| `test-agent-engine` | Send a trivial prompt to verify the engine works (connectivity + API key) |\n| `check-provider-key` | Check a provider API key by listing the models it reaches, before saving it |\n| `get-provider-models` | Read which models each provider shows in the model picker and default-model select |\n| `manage-provider-models` | Choose those models (`set`) or go back to the recommended ones (`reset`) |\n| `list-model-providers` | What Settings › Model shows: each provider\'s organization and personal key (masked), rejections, the restriction, and the stored default |\n\n## Checking the Current Engine\n\n```\nlist-agent-engines\n```\n\nReturns the registry of all engines (name, label, capabilities, supported models) plus the currently active engine and model. `supportedModels` is what the model picker offers: the provider\'s checked models when `modelSelection.state` is `"selected"`, otherwise its `recommendedModels`. `credentialRejected: true` means the provider rejected that engine\'s saved key (`credentialRejectedAt` says when); chats with it stop until the key is replaced, so tell the user.\n\n## Switching Engines\n\n```\nset-agent-engine --engine "ai-sdk:openai" --model "gpt-4o"\n```\n\nChanges take effect on the next conversation. The default belongs to the organization (the `agent-engine` org setting), and only owners and admins can change it. A member\'s call is refused with an error to relay: ask an owner or admin, or pick a model for this chat in the model picker. A user with no organization sets their own default.\n\nResolution order (highest priority first):\n1. Explicit `engine` option passed to `createAgentChatPlugin()` in the server plugin\n2. The organization\'s default (`agent-engine` org setting)\n3. `AGENT_ENGINE` environment variable\n4. Default: `"anthropic"` (requires `ANTHROPIC_API_KEY`)\n\n## Settings › Model\n\nThe Model page (`/settings/model`, page id `model`) has three groups:\n\n- **Organization providers:** the organization\'s Builder.io connection and each organization key. Owners and admins manage them; members see only "N models".\n- **Personal providers:** a member\'s own Builder.io connection, their own keys, and the ChatGPT subscription while its lab is on. A personal key is used before the organization\'s, for that person only.\n- **Organization settings:** Default model (`manage-agent-engine` `set`, organization models only), Restrict personal API keys (`manage-provider-key-policy`), and Max iterations (`manage-agent-loop-settings`, 1 to 1000). Owners and admins change them; members see the values.\n\nRead the page\'s state with `list-model-providers`, and the models each provider shows with `get-provider-models`. Keys are added and replaced in the provider dialog, which checks a pasted key by listing its models; you can\'t save a key for the user, so check one with `check-provider-key` and send them to Model (`open-settings-page`) to paste it. Before they remove a provider, run `preview-secret-removal` with the provider\'s key name and scope and tell them what stops.\n\n## Restricting Personal API Keys\n\n`manage-provider-key-policy` reads or changes the organization\'s "Restrict personal API keys" setting. While it is on, members (not owners or admins) can\'t use or save their own provider keys or a personal Builder.io connection, so their chats use organization providers; with none, a chat fails with "Owners and admins restricted personal API keys." Nothing is deleted, and turning it off restores their keys.\n\n```\nmanage-provider-key-policy            # read; owners/admins also get affectedMembers\nmanage-provider-key-policy --set true # owners and admins only\n```\n\nRead it first and tell the user which members lose which providers before turning it on.\n\n## Testing a New Engine\n\nBefore switching, verify the engine is working:\n\n```\ntest-agent-engine --engine "ai-sdk:openai" --model "gpt-4o"\n```\n\nReturns `{ ok, latencyMs, response, capabilities }`. If `ok: false`, the error message explains what\'s wrong (missing API key, package not installed, etc.).\n\nTo check a key without sending a prompt, for example one the user just gave you:\n\n```\ncheck-provider-key --provider "anthropic" --key "<the key>"\n```\n\nReturns `{ ok: true, models }` or `{ ok: false, code, reason }` (`rejected`, `wrong-provider`, `missing-key`, `invalid-endpoint`, `unreachable`, `provider-error`). Relay the reason. Omit `--key` to re-check the saved key; it is only checked against its saved endpoint, so `--baseUrl` needs `--key` (except for Ollama). `--scope org` is for owners and admins.\n\n## Choosing Which Models Show\n\nEach provider (Builder.io included) keeps the models its owner checked. Only checked models appear in the chat model picker and the default-model select; Builder.io and providers with their own key show side by side.\n\n```\nget-provider-models --provider "openai"\nmanage-provider-models --action "set" --provider "openai" --models \'["gpt-6-sol"]\'\nmanage-provider-models --action "reset" --provider "openai"\n```\n\n- A selection lives at the same scope as the provider\'s key: `--scope user` is the caller\'s own, `--scope org` is the organization\'s (owners and admins only; members get an error to relay). Without `--scope`, the call changes the selection in effect, which follows the key in effect (a member\'s personal key uses their personal selection).\n- A member\'s personal selection never changes the organization\'s. The default-model select always offers the organization\'s checked models.\n- `set` with an empty list hides the provider\'s chat models, for a key used only by services. Builder.io accepts only its own catalog.\n- A chat already on an unchecked model keeps running on it. When nothing picked a model and the engine default is unchecked, chats use the first checked model.\n- A row with `models: null` has nothing chosen and shows the recommended models. `state: "unreadable"` means the selection couldn\'t be read, not that it is empty.\n\n## Built-in Engines\n\n| Engine Name | Provider | Requires |\n|---|---|---|\n| `anthropic` | Anthropic Claude SDK | `ANTHROPIC_API_KEY` |\n| `ai-sdk:anthropic` | Claude via Vercel AI SDK | `ANTHROPIC_API_KEY` |\n| `ai-sdk:openai` | OpenAI via Vercel AI SDK | `OPENAI_API_KEY` |\n| `ai-sdk:openrouter` | 300+ models (Anthropic, OpenAI, Google, Meta, …) routed through OpenRouter | `OPENROUTER_API_KEY` |\n| `ai-sdk:google` | Google Gemini via Vercel AI SDK | `GOOGLE_GENERATIVE_AI_API_KEY` |\n| `ai-sdk:groq` | Groq LPU via Vercel AI SDK | `GROQ_API_KEY` |\n| `ai-sdk:mistral` | Mistral via Vercel AI SDK | `MISTRAL_API_KEY` |\n| `ai-sdk:cohere` | Cohere via Vercel AI SDK | `COHERE_API_KEY` |\n| `ai-sdk:ollama` | Local Ollama via Vercel AI SDK | None (local) |\n\n## Engine Capabilities\n\nEach engine advertises its capabilities:\n\n| Capability | Anthropic | AI SDK: Anthropic | AI SDK: OpenAI | AI SDK: Google |\n|---|---|---|---|---|\n| `thinking` | ✓ | ✓ | ✗ | ✓ |\n| `promptCaching` | ✓ | ✓ | ✗ | ✗ |\n| `vision` | ✓ | ✓ | ✓ | ✓ |\n| `computerUse` | ✓ | ✗ | ✗ | ✗ |\n| `parallelToolCalls` | ✓ | ✓ | ✓ | ✓ |\n\n## Anthropic-Exclusive Features\n\nWhen using the `anthropic` engine (or `ai-sdk:anthropic`):\n\n- **Prompt caching** is applied automatically to the system prompt — cutting latency and cost on repeated turns.\n- **Extended thinking** can be enabled via `providerOptions.anthropic.thinking` — the agent reasons longer before responding.\n\nThese features are silently ignored when a non-Anthropic engine is active (capability-gated, no breakage).\n\n## Using OpenRouter\n\n`ai-sdk:openrouter` gives access to 300+ models from many providers through a single API. Model IDs use the `vendor/model` form:\n\n```\nset-agent-engine --engine "ai-sdk:openrouter" --model "anthropic/claude-sonnet-4.5"\nset-agent-engine --engine "ai-sdk:openrouter" --model "openai/gpt-4o"\nset-agent-engine --engine "ai-sdk:openrouter" --model "google/gemini-2.5-pro"\n```\n\nAny `vendor/model` string from [openrouter.ai/models](https://openrouter.ai/models) works — the `supportedModels` list in the registry is a UI hint, not an allow-list.\n\n**App attribution** (optional): pass `appName` / `appUrl` in the engine config to set the `X-OpenRouter-Title` / `HTTP-Referer` headers — useful to see your app on the OpenRouter dashboard and leaderboards:\n\n```ts\ncreateAISDKEngine("openrouter", {\n  apiKey: process.env.OPENROUTER_API_KEY,\n  appName: "My App",\n  appUrl: "https://myapp.example",\n});\n```\n\n## Registering a Custom Engine\n\nRegister custom engines in a server plugin at startup. Import from the\n`@agent-native/core/agent/engine` subpath:\n\n```ts\n// server/plugins/my-engine.ts\nimport {\n  registerAgentEngine,\n  type AgentEngine,\n  type EngineEvent,\n  type EngineStreamOptions,\n} from "@agent-native/core/agent/engine";\n\nregisterAgentEngine({\n  name: "my-engine",\n  label: "My Custom Engine",\n  description: "...",\n  capabilities: {\n    thinking: false,\n    promptCaching: false,\n    vision: false,\n    computerUse: false,\n    parallelToolCalls: true,\n  },\n  defaultModel: "my-model-v1",\n  supportedModels: ["my-model-v1", "my-model-v2"],\n  requiredEnvVars: ["MY_ENGINE_API_KEY"],\n  create: (config): AgentEngine => ({\n    name: "my-engine",\n    label: "My Custom Engine",\n    defaultModel: "my-model-v1",\n    supportedModels: ["my-model-v1", "my-model-v2"],\n    capabilities: {\n      /* same shape as above */\n    } as any,\n    async *stream(opts: EngineStreamOptions): AsyncIterable<EngineEvent> {\n      // yield text-delta / thinking-delta / tool-call / usage events\n      // as they arrive, then:\n      yield { type: "assistant-content", parts: /* final content parts */ [] };\n      yield { type: "stop", reason: "end_turn" };\n    },\n  }),\n});\n```\n\n### Engine stream contract\n\nEvery engine\'s `stream(opts)` MUST emit, in order:\n\n1. Zero or more `text-delta`, `thinking-delta`, `tool-call`, and `usage`\n   events as they arrive from the model.\n2. Exactly one `{ type: "assistant-content", parts }` event with the\n   structured content for the turn. `runAgentLoop` reads this to\n   reconstruct the assistant message for the next turn.\n3. Exactly one terminal `{ type: "stop", reason }` event.\n\nAfter registering, the engine appears in `list-agent-engines` output and can\nbe selected via `set-agent-engine`.\n\n## Env Vars Reference\n\n| Variable | Purpose |\n|---|---|\n| `ANTHROPIC_API_KEY` | Required for `anthropic` and `ai-sdk:anthropic` engines |\n| `OPENAI_API_KEY` | Required for `ai-sdk:openai` |\n| `OPENROUTER_API_KEY` | Required for `ai-sdk:openrouter` |\n| `GOOGLE_GENERATIVE_AI_API_KEY` | Required for `ai-sdk:google` |\n| `GROQ_API_KEY` | Required for `ai-sdk:groq` |\n| `MISTRAL_API_KEY` | Required for `ai-sdk:mistral` |\n| `COHERE_API_KEY` | Required for `ai-sdk:cohere` |\n| `AGENT_ENGINE` | Default engine name (overridden by settings store) |\n',dir:`.agents/skills/agent-engines`,extraFiles:[],files:{}},"agent-native-docs":{meta:{name:`agent-native-docs`,description:`How to find version-matched Agent-Native framework docs and source bundled in node_modules. Use before implementing or answering questions about @agent-native/core APIs, generated apps, workspaces, templates, or advanced features.`,scope:`dev`},content:`---
name: agent-native-docs
description: >-
  How to find version-matched Agent-Native framework docs and source bundled in
  node_modules. Use before implementing or answering questions about
  @agent-native/core APIs, generated apps, workspaces, templates, or advanced
  features.
scope: dev
metadata:
  internal: true
---

# Agent-Native Docs Lookup

## Rule

Before implementing or explaining non-trivial Agent-Native behavior, read the
version-matched docs installed with \`@agent-native/core\`. When examples,
imports, or implementation details matter, inspect the packaged source corpus
too.

## Why

Generated apps and workspaces may be on a different framework version than the
public docs or model memory. The installed package is the source that matches
the app in front of you. A version-matched \`@agent-native/core-corpus\` package
provides first-party template source when an app needs those examples, without
adding the corpus to every Core installation.

## How

From a generated app directory:

\`\`\`bash
pnpm action framework-search --pattern "defineAction"
pnpm action framework-search \\
  --pattern "defineAction" \\
  --scope source \\
  --path "templates/*/actions/*.ts"
pnpm action framework-search --pattern "Agent(?:Panel|Sidebar)" --mode regex --scope source
\`\`\`

Use \`framework-search\` first when a question may cross the docs and source
boundary. It searches version-matched framework docs, runtime-visible skills,
readable Core or Toolkit package source, and first-party template source when
the optional corpus is installed, in one bounded read-only call. Use
\`scope: docs\` or \`scope: source\` to narrow it, then use the focused readers for
the page or file you need.

The headless \`pnpm agent\` loop and built-in app agents expose read-only
\`framework-search\`, \`docs-search\`, and \`source-search\` tools when Core's docs
scripts are bundled. The default substring mode is safest for ordinary
questions; use \`glob\` for wildcard paths, \`sql-like\` for \`%\` and \`_\` wildcards,
and \`regex\` for precise structural matches. Results are bounded, so refine the
pattern or path instead of treating a truncated result as exhaustive.

From a generated app directory, the lower-level readers remain available:

\`\`\`bash
pnpm action docs-search --query "actions"
pnpm action docs-search --slug actions-defining
pnpm action docs-search --list
pnpm action source-search --query "defineAction"
pnpm action source-search --path templates/plan/AGENTS.md
pnpm action source-search --path templates/chat/actions/hello.ts
pnpm action source-search --list
\`\`\`

If a search reports that the optional first-party template corpus is not
installed, add it at the same version as Core:

\`\`\`bash
core_version=$(node -p 'require("./node_modules/@agent-native/core/package.json").version')
pnpm add -D "@agent-native/core-corpus@$core_version"
\`\`\`

Use the unified tool for discovery, then the focused tools for full page or
file reads.

If the action runner is unavailable, search the package directly:

\`\`\`bash
rg -n "actions|automations|a2a|sharing" node_modules/@agent-native/core/docs
rg -n "defineAction|useActionQuery" node_modules/@agent-native/core-corpus/corpus
\`\`\`

Then read \`node_modules/@agent-native/core/docs/AGENTS.md\` or the matching file
under \`node_modules/@agent-native/core/docs/content/\`. For template examples,
read files under \`node_modules/@agent-native/core-corpus/corpus/templates/\`. The corpus
carries templates only; for Core's own implementation read
\`node_modules/@agent-native/core/dist/\` (compiled sources plus \`.d.ts\`).

Toolkit ships readable TypeScript under
\`node_modules/@agent-native/toolkit/src/\`. Read
\`customizing-agent-native\` before taking ownership of a shared component: inspect package
source as a read-only reference, then configure, compose, or eject the smallest
supported unit into app-owned source. Preserve public actions, application
state, auth, and agent-chat runtime contracts. Never edit \`node_modules\` or
deep-import its private source. Manual copying is only the fallback described by
an unknown third-party package's add-style blueprint.

## Reuse Proven Patterns (rg + cp)

Version-matched installed source outranks web docs or memory: it is the exact
code shipping with this app. \`node_modules/@agent-native/core-corpus/corpus/templates/\`
holds source for every first-party template, not just the one this app started
from, so a pattern from the mail template is fair game for a tasks app. Grep
across it, then copy a whole file as a starting point instead of writing the
pattern from scratch:

\`\`\`bash
# Find how other templates solved a similar problem
rg -n "drag.*drop|reorder" node_modules/@agent-native/core-corpus/corpus/templates

# Grab a proven action file as a starting point, then adapt names/schema
cp node_modules/@agent-native/core-corpus/corpus/templates/chat/actions/hello.ts \\
   actions/greet.ts

# Read the framework's own implementation behind an API
rg -n "defineAction" node_modules/@agent-native/core/dist/action.js
\`\`\`

Copying template-level app code (actions, components, skill files) is the
expected reuse path — templates exist to be forked. This is different from
copying \`core\`/\`toolkit\` **runtime internals**: for those, follow
\`customizing-agent-native\`'s configure/compose/eject ladder instead of
hand-duplicating framework logic.

## Useful Slugs

| Need                           | Slugs |
| ------------------------------ | ----- |
| Define and call actions        | \`actions-overview\`, \`actions-defining\`, \`actions-advanced\` |
| Typed client calls and data    | \`client-overview\`, \`client-entry-points\`, \`client-data\` |
| SQL, auth, access, sharing     | \`postgres\`, \`server-database\`, \`authentication\`, \`security\`, \`sharing\` |
| UI state visible to the agent  | \`context-awareness\` |
| Headless and chat-first apps   | \`pure-agent-apps\`, \`agent-surfaces\`, \`using-your-agent\` |
| Automations and schedules      | \`automations\`, \`recurring-jobs\` |
| Cross-app and external agents  | \`a2a-protocol\`, \`external-agents\`, \`mcp-protocol\`, \`mcp-apps\` |
| Skills and instructions        | \`skills-guide\`, \`writing-agent-instructions\` |

## Don't

- Do not rely on memory for framework APIs when package docs are present.
- Do not add custom REST wrappers for app data before reading
  \`actions-overview\` and \`actions-defining\`.
- Do not add inline LLM calls before reading \`using-your-agent\` and
  \`agent-surfaces\`.
- Do not copy framework runtime internals when a public API or narrow UI copy
  will do; read \`customizing-agent-native\` for the supported override ladder.

## Authoring visual docs blocks

Treat the shared \`Diagram\` block as a renderer, not as a reason to style every
docs UI as a sketch. Use the hand-drawn font and Rough.js only for actual
diagrams or wireframes that communicate structure, flow, or a design draft.
For polished UI-like content - cards, logo walls, tables, controls, or product
shells — set \`renderMode="design"\` (and usually \`frame="hide"\` when the block
is the content itself). Design mode preserves normal docs typography and
disables the Rough.js overlay. Keep \`data-rough\` only on elements intentionally
sketched inside a real diagram.
`,dir:`.agents/skills/agent-native-docs`,extraFiles:[],files:{}},"agent-native-toolkit":{meta:{name:`agent-native-toolkit`,description:`Inventory and ownership rules for shared Agent-Native workspace UI. Use before building app chrome, settings, navigation, sharing, collaboration, setup, history, comments, chat rails, agent UX, or repeated workspace behavior.`,scope:`dev`},content:`---
name: agent-native-toolkit
description: >-
  Inventory and ownership rules for shared Agent-Native workspace UI. Use
  before building app chrome, settings, navigation, sharing, collaboration,
  setup, history, comments, chat rails, agent UX, or repeated workspace behavior.
scope: dev
metadata:
  internal: true
---

# Agent-Native Toolkit

Use this skill when deciding whether app chrome, settings, collaboration,
sharing, navigation, organization, setup, history, comments, or agent UX should
be built app-locally or moved into reusable framework/toolkit pieces.

## Core Rule

Apps own domain models, domain actions, and product-specific workflows. The
framework and \`@agent-native/toolkit\` own repeated workspace behavior users
expect to work the same everywhere.

Move behavior into shared toolkit primitives when it is:

- workspace-wide, such as settings, nav, search, org membership, or setup
- agent-visible, such as context, actions, run progress, or proof-of-done
- governed, such as secrets, permissions, sharing, audit, or billing
- repeated by two or more apps
- not tied to one domain model

Keep behavior app-local when the abstraction would hide important domain
language or make a simple app-specific workflow harder to understand.

## Agent Surface Contract

When using the shared app shell, keep its two navigation surfaces distinct:

- The left rail owns domain destinations and chat history when the app has a
  full-page chat route. Do not label a domain workflow as \`Chat\` just because
  the app was scaffolded from the chat template.
- Settings is not a rail item. It opens from the account menu (\`OrgSwitcher\`
  in the sidebar footer) and from ⌘, (Ctrl+, elsewhere), which \`AppProviders\`
  binds. Keep the \`/settings\` route; don't add a Settings entry to \`items\`,
  \`secondaryItems\`, or the footer.
- The right \`AgentSidebar\` owns contextual agent work. Domain buttons that call
  \`sendToAgentChat\` should open it (\`openSidebar: true\`) so the user can see,
  steer, and review the agent without losing the page they were using.
- Keep \`/\` or \`/chat/*\` as the full-page chat surface when the starter provides
  one. Put domain workflows on named routes and wire the shell's route checks,
  navigation labels, and handoffs to those routes together.
- Use familiar message or neutral action icons for agent affordances. Never use
  sparkle, wand, magic, or robot icons as an AI label; the copy should carry the
  meaning.
- Give the right rail a quiet visual boundary with a subtle surface shift,
  divider, or both. The domain page and AgentSidebar should not collapse into a
  single undifferentiated background.
- Any button labeled as agent work must use \`sendToAgentChat\` with bounded
  context and \`openSidebar: true\`; local deterministic analysis should be
  labeled as local, preview, or analyze. For original/generated review, stack
  the source above the result by default and use side-by-side only for short,
  highly scannable content.
- Deterministic implementation does not make an AI-shaped experience
  deterministic. If the user expects research, analysis, generation,
  recommendation, synthesis, visible progress, or steering, route the button
  to the AgentSidebar and let the agent call focused actions. Keep revisions in
  the same thread instead of adding a second freeform prompt box.
- Standalone apps with \`AgentSidebar\` must use one AgentKit controller and
  transport. Core's \`AssistantChat\` export remains supported as an alias for
  \`AgentKitAssistantChat\`; use AgentKit slots and registries for custom message
  UI. Keep assistant-ui transcript/runtime imports inside the shared composer
  integration; when linked dependencies need Vite aliases, resolve one
  \`@agent-native/agentkit\` context and verify a real handoff.

Contextual agent UI is not a reason to expose every option at once. Start with
the domain task's primary action, reveal review or configuration only when the
current state needs it, and let the sidebar carry conversational depth.

When an app exposes context sources or integration shortcuts, show only
capabilities available to that app and the current caller. Keep retrieving
context distinct from asking the agent to invoke an integration, and recheck
availability when the user submits. Do not infer agent-tool access from a
connected messaging account or expose credential values. Link to shared
Integrations settings when a required connection is missing.

## Visual Direction And Workspace Variety

Shared workspace behavior should be consistent without forcing every app into
the same visual skin. Keep shell and component tokens semantic, then let each
app record a visual direction in \`DESIGN.md\` before styling. Choose its palette
and composition from the product context, and keep semantic states accessible.

Do not make warm beige plus terracotta the workspace fallback. Preserve a
workspace-level brand when one exists; otherwise keep shared chrome neutral and
allow app-owned accents to distinguish products while retaining accessible
semantic states and the shared AgentSidebar contract.

## Discover Before Building

Before creating an app-local version of repeated workspace or agent UI:

1. Check the reusable kits below and the installed package documentation.
2. Search installed public components and source with \`docs-search\` and
   \`source-search\`.
3. Run \`agent-native eject --list\` to see the version-matched units published
   by the packages installed in this app.
4. Read \`customizing-agent-native\` and configure, compose, or eject the
   smallest unit instead of recreating shared behavior from memory.

Use public package exports at runtime. Published source and ejection manifests
are discovery and ownership-transfer mechanisms, not private runtime APIs.

## Design-System Boundary

For apps with a UI, keep an explicit design-system seam in
\`app/design-system.ts\` using \`defineDesignSystem\` from
\`@agent-native/toolkit/design-system\`, and supply it to \`ToolkitProvider\`. The
semantic contract contains:

- nine leaf components: \`ActionButton\`, \`IconButton\`, \`TextField\`, \`TextArea\`,
  \`Spinner\`, \`Skeleton\`, \`Status\`, \`Surface\`, and \`Avatar\`
- eight behavior components: \`Tooltip\`, \`Menu\`, \`Popover\`, \`Dialog\`, \`Picker\`,
  \`Checkbox\`, \`Switch\`, and \`Tabs\`

These are semantic contracts, not styling contracts. An adapter may use
Tailwind/shadcn, MUI-style theme providers, React Aria, CSS modules, CSS-in-JS,
or another React design system. Do not assume CVA, utility classes, or even a
\`className\`; behavior adapters may supply their overlay and focus
implementation wholesale while honoring portal, focus-restoration, keyboard,
dismissal, ARIA, and z-index interoperability.

Pages, routes, and domain components import ordinary controls through the app's
local adapter layer, usually \`@/components/ui/*\`. They must not import
\`@agent-native/toolkit/ui/*\` directly. Toolkit feature exports are still the
right home for shared workspace behavior; their presentation flows through the
registered semantic components, feature controller, and product-level slots.

Import any design-system adapter explicitly; do not auto-detect it or load React
components from JSON. Run a custom adapter against
\`@agent-native/toolkit/conformance\` in the app's CI before adopting it.

## Settings Direction

Durable settings belong in Settings. The agent sidebar should not become a
second settings app; it can show contextual quick controls and deep links.
Settings has the same groups in every app, and page ids are stable URL segments
(\`/settings/<page>/<sub>\`):

- Account: \`profile\`, \`preferences\`, \`security\`
- Connections: \`integrations\` (\`integrations/builder\`), \`api-keys\`
- Agent: \`model\`, \`instructions\`, \`memory\`, \`skills\`, \`files\`, \`sub-agents\`
- Organization: \`org\`, \`members\`, \`usage\`, and for owners and admins \`auth\`,
  \`apps\`, \`infra\`, \`audit\`
- The app's group: \`app\` (areas at \`app/<id>\`), \`notifications\`,
  \`automations\`, \`channels\` (\`channels/<platform>\`), \`mcp\`, \`creative-context\`
- Footer: \`labs\`, \`whats-new\`

Link with \`buildSettingsRoute(page, sub?, { anchor? })\`; older tab and section
ids continue to resolve through framework redirects. Account › Profile is the
canonical profile surface (\`get-user-profile\`, \`update-user-profile\`); don't
build an app-local profile page. Read the \`toolkit-settings\` documentation for
the current route and page ids.

When adding a new API key, OAuth grant, provider connection, model selector, app
preference, notification preference, or usage/billing surface, find the page
that owns that kind of setting first: provider keys go through the one provider
dialog on Model, other keys on API keys, channels on Channels, and app-only
preferences in the app's group. Only add sidebar UI when it is needed in the
moment of agent use.

### The app's group in Settings

Settings has a group named after the app.
Core owns its pages: General, Notifications, Automations, Channels, MCP server,
Creative context, plus Labs and What's new in the footer. A template supplies
only its own content, through these \`SettingsTabsPage\` props:

- \`generalGroups\`: the app's own \`SettingsGroup\`s on its General page. Core puts
  Agent › Default model above them (owners and admins change it; the agent
  uses \`manage-agent-engine\` \`set-app-default\`) and This browser › Demo mode
  below. Until a template passes it, today's \`general\` shows there.
- \`appAreas\`: \`[{ id, label, content, visible?, keywords?, searchEntries? }]\`,
  tabs on the General page routed \`/settings/app/<id>\`. Set \`visible: false\`
  while the lab behind an area is off. A tab with
  \`settingsPlacement: "app-area"\` in \`extraTabs\` works the same.
- \`notifications\` (plus \`notificationsSearchEntries\`): the Notifications page
  shows only when this is passed.
- \`mcpAbout\`: the MCP server page's about line, naming what an MCP host can do
  in this app.
- Labs come from \`labs\`; What's new comes from \`whatsNewMarkdown\`, or from the
  \`ChangelogSettingsCard\` passed as \`whatsNew\`.
- Any other \`extraTabs\` item becomes its own page in the app's group. To swap a
  core page for a variant, \`registerSettingsPages([{ ...corePage, component }])\`
  at module scope (Dispatch's Members keeps its app-role column this way). To
  add a group to one channel's page, \`registerChannelSettingsExtensions\`.

The route needs a \`settings.$.tsx\` splat next to \`settings.tsx\`, and the layout
hides its own sidebar and header on Settings routes while the flag is on or
loading (\`isSettingsPathname\`), because the shell brings its own.

Search entries per area: each \`searchEntries\` item's \`hash\` is the row's
\`SettingsRow\` id, and a hit opens that area's tab and scrolls to the row. With
the flag off, the same props render as today's tabs, so a migrated template
works either way. Link with \`buildSettingsRoute("app", "<area>")\`, never a
hand-written path.

Gate UI on a lab with \`useLab(LAB_DEFINITION)\` rather than \`useLab(key)\`: a
definition reads as its \`defaultEnabled\` until the server answers, while a bare
key reads as on.

## Integration Setup Preflight

Before building any setup, settings, credential, OAuth, or connection surface,
search the workspace/provider connection catalog first. If the provider already
has a reusable connection, use its catalog, app grant, and scoped credential
resolver rather than registering a parallel secret. Only then classify fields
that still need app-local setup by lifecycle and scope:

| Need | Default primitive |
| --- | --- |
| Deploy- or app-level configuration | Runtime configuration or deployment env vars |
| Existing workspace/provider connection | Workspace-connection catalog/grant plus \`resolveWorkspaceConnectionCredential(s)ForApp\` |
| App-local API/service key with no reusable connection | \`registerRequiredSecret({ kind: "api-key" })\` and the vault |
| Authorization-code or refresh-token flow | \`kind: "oauth"\` with \`@agent-native/core/oauth-tokens\` |
| Account, customer, or other non-secret identifiers | Scoped connection metadata or app data |
| Provider-specific prerequisites, sequencing, or health | A thin app-local guide over the shared primitives |

Do not register every provider field as a generic secret, mark every field as
required, or create a second credential-management surface. One logical
connection should normally produce one onboarding outcome. A custom setup page
is appropriate only when it adds domain-specific guidance or readiness checks;
it should link to or call the shared settings, OAuth, and action surfaces rather
than duplicating their storage or transport.

## Reusable Kits

- **Settings kit**: one searchable Settings page with Account, Connections,
  Agent, and Organization groups plus a group for the app's own settings. The
  index is built from page declarations; give every row a search entry whose
  anchor is its \`SettingsRow\` id so users find settings by name.
- **Collaboration kit**: Yjs docs, presence, agent presence, live cursors,
  remote selections, recent edit highlights, real-time sync indicators, and
  undo/redo grouping.
- **Sharing kit**: private/workspace/org/public-link access, invites, roles,
  expirations, agent-readable links, and resource registration.
- **Navigation and command kit**: app shell, side nav, breadcrumbs, app switcher,
  command palette entries, recent resources, pinned resources, and global search.
- **Organization kit**: folders, tags, favorites, archive, trash, ownership,
  membership, and common resource metadata.
- **Setup and connections kit**: declarative setup requirements, model readiness,
  missing-secret states, OAuth grants, and provider connection health.
- **Agent UX kit**: sidebar, composer, staged context, mentions, voice, human
  approval, generative UI, progress, and screen-state exposure.
- **Custom block kit**: optional, sandboxed extensions for one-off behavior or
  views. Apps opt in; Core owns sandboxing, storage, and access checks, while
  Toolkit provides reusable adoption UI. Promote repeated or durable workflows
  to app-owned actions and UI.
- **Chat history kit**: presentational chat lists and recent-chat rails belong
  in Toolkit; Core keeps thread persistence, agent execution, transport, and
  page-to-sidebar handoff. Apps provide routing, labels, and domain actions.
- **Data grid kit**: provider-agnostic spreadsheet mechanics belong in
  \`@agent-native/toolkit/data-grid\`. Apps provide rows, typed columns, editor
  slots, selection and width state, persistence callbacks, and product-level
  row/body slots. Keep database models, access checks, grouping, drag/drop,
  and domain actions in the app adapter.
- **Agent page kit**: the full-page Agent surface (\`AgentTabsPage\` from
  \`@agent-native/toolkit/app/agent-page\`) for agent resources, context
  snapshots, integrations, automations, settings, and MCP access. The page
  supports app-provided tabs. Use \`agent-native-docs\` to find current guidance
  before adding it.
- **History and recovery kit**: audit log, activity feed, version history,
  checkpoints, undo, redo, restore, and proof-of-done.
- **Comments and review kit**: anchored comments, pins, mentions, review
  requests, resolved threads, agent follow-up tasks, and notifications.
- **Workflow and observability kit**: notifications, approvals, scheduled work,
  background runs, recurring jobs, traces, evals, feedback, and run timelines.

## Implementation Checklist

When adding or refactoring one of these areas:

1. Search app code and installed package documentation/source for an existing
   feature before building an app-local version.
2. Configure the public feature through its data, action, controller, semantic
   component, and product-level render seams.
3. Keep shared data provider-agnostic and scoped by auth/sharing rules.
4. Expose the same capability to the UI and agent through actions or documented
   client helpers.
5. Keep app-specific labels, routes, resource adapters, and settings panels in
   the app integration instead of forking shared UI for one app.
6. Document app-specific configuration for the next contributor; use
   \`agent-native-docs\` when the installed package behavior is unclear.
7. Prefer public props and slots; if they cannot express the need, use the
   smallest supported ejection unit. See \`customizing-agent-native\` for the
   configure → compose → eject → propose seam ladder.
8. Keep one controller as the source of truth for the default and custom render
   paths. A custom design must not fork actions, analytics, async state, or
   accessibility behavior.
9. If the app registers a custom adapter, verify it with the conformance kit,
   including focus, keyboard, dismissal, and portal behavior where components
   meet framework surfaces.

## Related Skills

Read these alongside this skill when the work touches the specific area:

- \`sharing\`
- \`secrets\`
- \`adding-a-feature\`
- \`agent-native-docs\`

Use \`agent-native-docs\` to find installed-version guidance for navigation,
screen context, collaboration, visual direction, and other capabilities not
included in your scaffold's skill set.
`,dir:`.agents/skills/agent-native-toolkit`,extraFiles:[],files:{}},authentication:{meta:{name:`authentication`,description:`How to wire this app's login experience through the framework's createAuthPlugin — branded loginHtml, public paths, and signup/logout UI. Read before creating or editing server/plugins/auth.ts, or before adding gated routes / a public marketing page.`,scope:`dev`},content:`---
name: authentication
description: >-
  How to wire this app's login experience through the framework's
  createAuthPlugin — branded loginHtml, public paths, and signup/logout UI.
  Read before creating or editing server/plugins/auth.ts, or before adding
  gated routes / a public marketing page.
scope: dev
metadata:
  internal: true
---

# Authentication

## Rule

If a user requests authentication or login or other similar terms, you should setup
authentication in their app using this skill.

\`server/plugins/auth.ts\` exports \`createAuthPlugin(options)\` from
\`@agent-native/core/server\` — that plugin is the app's auth. Do not hand-roll
session cookies, a parallel login route, or a custom auth backend; configure
the existing plugin instead.

## Choose the landing route before wiring auth

Before writing \`loginHtml\` or the sign-in journey, inspect \`app/routes\`, the
app's navigation, and any existing \`app.homePath\` in
\`server/plugins/config.ts\`. Preserve a valid existing \`homePath\`; otherwise
pick the app's actual primary authenticated route (\`/\`, \`/dashboard\`,
\`/tasks\`, ...) and persist it there — never assume \`/home\` unless that route
really exists. \`loginHtml\` and the journey script below both need this value:
a hardcoded \`/\` only works for apps whose real landing page is root.

## Branded login page

Pass \`loginHtml: string\` — a full HTML document that replaces the built-in
login page and its framework chrome entirely, so it can carry this app's own
layout, fonts, colors, and copy. Write it to match this app's actual look and
feel (its palette, type, and voice) — do not ship the generic framework login
page, and do not reuse another app's \`loginHtml\` verbatim without replacing
its copy and styling first.

The login HTML must call the framework's own auth endpoints, so behavior
matches the built-in page:

- \`POST /_agent-native/auth/register { email, password, callbackURL? }\` →
  \`{ ok: true }\` or \`{ error }\`. **\`{ ok: true }\` only means the account was
  created — register does NOT set a session cookie, so the visitor is still
  signed out at this point.**
- \`POST /_agent-native/auth/login { email, password }\` → sets the session
  cookie and returns \`{ ok: true }\` or \`{ error }\`. This is the only
  endpoint that establishes a session.
- \`GET /_agent-native/google/auth-url?return=<path>\` → \`{ url }\` to send the
  browser to for Google sign-in (only relevant when Google OAuth is
  configured)

**Sign-up must chain register → login before treating the user as signed
in.** A custom \`loginHtml\` that posts to \`/register\` and redirects on that
response's \`{ ok: true }\` alone creates the account but leaves the visitor
logged out — they land back on the app, still unauthenticated, and have to
log in separately right after signing up. The framework's own built-in login
page (not the custom \`loginHtml\` you write) already does this chaining
internally, which is why this bug only shows up once an app supplies its own
\`loginHtml\`. Every sign-up handler must call login immediately after a
successful register, with the same email/password, and only redirect once
*that* call also returns \`{ ok: true }\`:

\`\`\`js
function submitSignup(email, password) {
  return postJson("/_agent-native/auth/register", email, password).then(
    function (data) {
      if (!(data && data.ok)) throw new Error(data && data.error);
      // Register succeeded but did not sign the visitor in — log in now.
      return postJson("/_agent-native/auth/login", email, password);
    },
  );
}
\`\`\`

On success there is no redirect to follow — reload the current URL (e.g.
\`location.reload()\`) and it now passes the auth guard.

**This shortcut only works at the root path.** For any other gated route
(e.g. \`/toppings\`), the client \`<RequireSession>\` gate does not serve
\`loginHtml\` in place at that URL — it navigates the browser to
\`/sign-in?c=<opaque-continuation>\` first, so \`location.reload()\` there just
re-shows the login form forever instead of returning the visitor to
\`/toppings\`. To resume the original page, decode that continuation with the
framework's own helper instead of hand-rolling redirect logic:

\`\`\`html
<script>\${signInJourneyInlineScript()}<\/script>
<!-- import { signInJourneyInlineScript } from "@agent-native/core/shared" -->
<script>
  // Second arg is the app home path — use the app's configured \`app.homePath\`
  // from server/plugins/config.ts (e.g. "/dashboard"), not a hardcoded "/".
  var journey = __anCreateSignInJourney("", "/dashboard");
  var resumeHref = journey.journeyForLocation(window.location).resumeHref;
  // On page load: if already authenticated, window.location.replace(resumeHref)
  // On login/signup success: window.location.replace(resumeHref) instead of reload()
<\/script>
\`\`\`

\`resumeHref\` decodes the \`c\` continuation back to the originally-requested
path, falling back to that configured \`homePath\` when there isn't one —
hardcoding \`/\` here silently sends visitors to the wrong page on any app
whose real landing route isn't root. Embed \`signInJourneyInlineScript()\` in
every custom \`loginHtml\` that guards more than just \`/\`.

The login page must include:

- A **sign-in** form (email/password) posting to \`/_agent-native/auth/login\`.
- A **sign-up** control — a visible "Sign up" / "Create account" affordance
  that posts to \`/_agent-native/auth/register\`. Never ship a login-only page
  with no way to register.

## Logging out

Once a user is signed in, the app's authenticated UI must include a **logout**
control — do not leave users with no way to sign out. Use the framework's
\`signOut()\` helper from \`@agent-native/core/client\` rather than posting to
\`/_agent-native/auth/logout\` directly; it revokes the server session and only
then navigates, avoiding a stale authenticated screen that renders against a
dead cookie:

\`\`\`ts
import { signOut } from "@agent-native/core/client";

<button onClick={() => signOut()}>Log out</button>;
\`\`\`

## Separating a public marketing page from the private app

When an app needs a public landing surface in front of a gated authenticated
app, keep the two on different routes rather than gating everything or exposing
everything. The blank starter ships \`app/routes/_index.tsx\` as a placeholder
canvas at \`/\`; a common split is:

- **Public marketing page** at \`/\` — listed in \`workspaceAppPublicPaths\` (and
  \`PUBLIC_PATHS\` in \`app/root.tsx\`, see below) so signed-out visitors can reach
  it.
- **Private app** behind auth at a separate route (e.g. \`/dashboard\`), used as
  \`app.homePath\`.

For the public page, prefer the framework's ready-made shell
\`MarketingHome\` from \`@agent-native/toolkit/marketing\` instead of hand-rolling
a hero. It renders a branded landing shell with a hero, value props, and CTA
buttons that can deep-link into sign-in and the app:

\`\`\`tsx
import { MarketingHome } from "@agent-native/toolkit/marketing";
import { appPath } from "@agent-native/core/client/api-path";
import { APP_TITLE } from "@/lib/app-config";

export default function MarketingHomeRoute() {
  return (
    <MarketingHome
      appName={APP_TITLE}
      tagline="One-line value proposition."
      description="Supporting product description."
      valueProps={["First benefit", "Second benefit", "Third benefit"]}
      primaryActionHref={appPath("/dashboard")} // the app's real homePath
      secondaryActionHref={appPath("/sign-in")}
    />
  );
}
\`\`\`

Point \`primaryActionHref\` at the app's actual authenticated landing route (the
same value chosen for \`app.homePath\`), not a hardcoded \`/home\`. Pass
\`variant="auth"\` with an \`auth\` node to compose the login form beside the
marketing copy on a single public page. Only reach for \`MarketingHome\` when the
app actually wants a public marketing surface — a purely private app needs no
public landing page at all.

## Public paths

\`workspaceAppPublicPaths: string[]\` exempts page-route prefixes from the
private-app auth gate, e.g. \`["/"]\` so a logged-out visitor hitting the
marketing root gets the SPA (which renders the public landing page) instead of
being redirected to sign-in. Every route not listed here — and every
action/API — stays gated and requires a session. Set this explicitly for any
route a signed-out visitor should be able to reach; use
\`workspaceAppProtectedPaths\` for the inverse (an otherwise-public audience
with specific pages, e.g. an admin screen, that must still require a session).

**This only configures the server.** There is a SEPARATE client-side gate in
\`app/root.tsx\`: \`<AppProviders queryClient={...}>\` defaults its \`isPublicPath\`
prop to \`false\`, which wraps the *entire* app in \`<ClientOnly>\` +
\`<RequireSession>\` — every route, including ones already listed in
\`workspaceAppPublicPaths\`. Setting \`workspaceAppPublicPaths\` alone does
**not** make a page public; the two must be kept in sync by hand:

\`\`\`tsx
// app/root.tsx — must match workspaceAppPublicPaths in server/plugins/auth.ts
const PUBLIC_PATHS = ["/", "/menu", "/order"];

export default function Root() {
  const location = useLocation();
  const isPublicPath = PUBLIC_PATHS.includes(location.pathname);
  return (
    <AppProviders queryClient={queryClient} isPublicPath={isPublicPath}>
      {/* ... */}
    </AppProviders>
  );
}
\`\`\`

Forgetting this makes every route require sign-in even when the server
config says otherwise — the symptom is public marketing pages redirecting to
login for no apparent reason. When adding or changing
\`workspaceAppPublicPaths\`, always update this array in \`app/root.tsx\` too.

**Setting \`isPublicPath={true}\` streams real SSR markup for that route
instead of a \`<ClientOnly>\` shell** (see \`AppProviders\`'s own doc comment).
Most generated \`root.tsx\` files already mount router-dependent app-shell
services next to \`<Outlet />\` — e.g. a \`DbSyncSetup\`-style component calling
\`useNavigationState\` / \`useLocation\`, or anything else needing Router
context. Those services were only ever exercised inside the \`<ClientOnly>\`
branch before; once a route becomes public, they render during SSR too,
where that context may not be established, and the whole page 500s with
\`Error: useLocation() may be used only in the context of a <Router>
component\`, repeated several times in the server log. Wrap any such service
in \`<ClientOnly>\` explicitly so it keeps deferring to the client regardless
of \`isPublicPath\`:

\`\`\`tsx
import { ClientOnly } from "@agent-native/core/client/ui";

<AppProviders queryClient={queryClient} isPublicPath={isPublicPath}>
  <ClientOnly>
    <DbSyncSetup />
  </ClientOnly>
  <AppLayout>
    <Outlet />
  </AppLayout>
</AppProviders>;
\`\`\`

Do this once when first adding any public path, not per-route — the app
shell services live above the routed \`<Outlet />\` regardless of which page
is loading.

## Example

\`\`\`ts
import { createAuthPlugin } from "@agent-native/core/server";

export default createAuthPlugin({
  workspaceAppPublicPaths: ["/"],
  loginHtml: \`<!doctype html>
<html>
  <head>
    <title>Sign in — Acme</title>
    <style>/* match this app's palette, type, and voice */</style>
  </head>
  <body>
    <!-- sign-in form -> POST /_agent-native/auth/login -->
    <!-- sign-up form/toggle -> POST /_agent-native/auth/register,
         THEN POST /_agent-native/auth/login with the same credentials —
         register alone does not create a session. -->
    <script>
      // Sign-in: on { ok: true } from /login, location.reload()
      // Sign-up: on { ok: true } from /register, immediately call /login;
      //          only reload once THAT also returns { ok: true }
    <\/script>
  </body>
</html>\`,
});
\`\`\`
`,dir:`.agents/skills/authentication`,extraFiles:[],files:{}},"build-an-app":{meta:{name:`build-an-app`,description:`Fast end-to-end workflow for turning this starter into a working domain app from a short or vague request. Use when asked to build, make, create, or prototype an app, tool, tracker, dashboard, booking, inventory, or CRM system with Agent-Native. Read before the first edit.`,scope:`both`},content:`---
name: build-an-app
description: >-
  Fast end-to-end workflow for turning this starter into a working domain app
  from a short or vague request. Use when asked to build, make, create, or
  prototype an app, tool, tracker, dashboard, booking, inventory, or CRM
  system with Agent-Native. Read before the first edit.
scope: both
metadata:
  internal: true
---

# Build an App

Done means one useful domain workflow with a designed route, shared UI/agent
actions, correct access, agent context, and a smoke run that proves its key
rule. Finish a narrow slice before expanding it.

This skill edits source files. If this session cannot write files (a deployed
app's runtime agent), say the change needs a code session and stop.

The four-area parity rule from \`adding-a-feature\` (UI, action, instructions,
application state) applies to everything you add. This skill supplies the
order and decisions; use the edit-point reference for the scaffold you have.

## 1. Orient

Read \`AGENTS.md\`, this skill, and only the files you will edit. Skip broad repo
surveys, \`README.md\`, and \`DESIGN.md\`. Use the bundled docs/source commands in
\`AGENTS.md\` only to answer a concrete API question; do not web-research
framework APIs.

## 2. Decide

Choose these six things before writing code:

1. **Slice**: the one workflow that proves the app. For a booking app: create a
   booking, reject an overlap, cancel, weekly grid per room. Name what you are
   deferring (recurrence, notifications, roles, integrations) unless requested.
2. **Who sees each table**: pick one row of the access table in
   \`references/data-and-access.md\`: private, team-visible, shared on invite, or a
   child that inherits its parent's access. Making a team resource private per
   user is the usual wrong turn. Everyone then sees an empty list, and no
   conflict check can see anyone else's rows. Give each table \`owner_email\`
   and/or \`org_id\`, directly or via \`ownableColumns()\`; \`org_id\` alone passes
   \`[db-tool-scoping]\`. Doctor checks the schema marker, not query authorization;
   never denylist or opt out \`rooms\` or \`bookings\`.
3. **Invariants**: rules that must hold under concurrent requests (no overlap,
   stock never negative, unique slug). Enforce them in a write action inside a
   transaction or with a database constraint; the UI alone is insufficient.
4. **Actions**: \`list-<things>\`, \`create-<thing>\`, a single \`update-<thing>\`
   patch per resource, and the domain verbs (\`cancel-booking\`). Fewer,
   orthogonal tools make the agent choose better.
5. **Route**: give the domain its own route (for example, \`/rooms\`). Preserve
   existing routes and set \`app.homePath\` so sign-in lands on the domain when
   that is the requested home screen.
6. **Agent context**: URL ids and filters (for example \`roomId\`, \`week\`) that
   belong in \`navigation\`.

## 3. Build: write everything, then verify once

In a generated app, read \`package.json\` at
\`["agent-native"].scaffold.template\` and choose the matching reference:

- \`builder-code-starter\`: this starter has no Chat shell. Use \`AGENTS.md\`,
  \`DEVELOPING.md\`, and \`drizzle/START_HERE.md\` for edit points.
- \`default\`: \`references/edit-points-default.md\`
- workspace root: use \`adding-workspace-apps\` to create an app, then follow the
  new app's own \`AGENTS.md\` and scaffold reference.
- another domain template: use its \`AGENTS.md\` and \`adding-a-feature\`; do not
  apply Chat or default shell instructions to it.

If metadata is absent, inspect the actual route, layout, plugin, and navigation
files before choosing an edit point. Do not infer a shell from the app name.

Write the UI, actions, instructions, and state before running the verification
steps below. Do not leave placeholder or comment-only screens.

\`references/rooms-example.md\` gives a booking slice to adapt. It was verified
against the Chat starter; use the selected edit-point reference for the shell.
Use \`frontend-design\` for a deliberate visual direction and finish the
requested screens and interactions.

### Data

- Use PostgreSQL only, and keep migrations additive: new columns are nullable
  or have a default, and nothing is dropped or renamed. Never edit an applied
  entry; append a new named one.
- Set \`ownerEmail\` from \`ctx.userEmail\` and \`orgId\` from \`ctx.orgId\` on inserts
  where those columns exist. Never rely on a development identity fallback.
- Ids are text from \`crypto.randomUUID()\`.
- Bound every list (a time range or \`.limit()\`), select only the columns it
  renders, and index the columns it filters and sorts on.
- Store normalized UTC ISO timestamps; collect/display local times in the
  user's timezone. Validate offsets at the action boundary before parsing.

The access table, the concurrency pattern, and the security rules are in
\`references/data-and-access.md\`.

### Actions

- \`schema\` is zod, with \`.describe()\` on every field stating its units and
  format (for example, "ISO 8601 date-time with offset").
- Reads use \`http: { method: "GET" }\` and \`readOnly: true\`. Leave writes on the
  default POST so \`useActionMutation\` needs no \`method\`.
- Reject with \`fail(message, { errorCode, statusCode })\` from
  \`@agent-native/core/action\`: 409 for a conflict, 404 for not found, 403 for
  forbidden. A returned \`{ error }\` is counted as success everywhere, and a
  bare \`throw\` reaches the browser as a generic 500.
- Return plain objects that include the \`id\`. Keep LLM calls out of actions;
  AI-shaped work belongs in the agent chat.
- When the request is batch-shaped ("add these 20"), write one action that
  takes an array and writes it in one transaction.

### UI

- Load and write data with \`useActionQuery\` and \`useActionMutation\` from
  \`@agent-native/core/client/hooks\`. No \`fetch\`, and no \`/api/*\` routes for app
  data. Those routes are only for uploads, webhooks, OAuth callbacks, and streaming.
- While data loads, show a \`Skeleton\` in the shape of the final layout, not a
  spinner or "Loading…".
- Writes should feel instant. In \`onMutate\`, update \`["action", "<name>", params]\`
  with \`setQueryData\`; in \`onError\`, roll back and show
  \`toast.error(actionErrorMessage(error) ?? "<fallback>")\`.
- Import controls from \`@/components/ui/*\`. When one is missing (dialog,
  select, skeleton, alert-dialog), add a one-line re-export like \`button.tsx\`:
  \`export * from "@agent-native/toolkit/ui/dialog";\`.
- Use Tabler icons only. Confirm with \`AlertDialog\`; never use \`window.confirm\`,
  \`alert\`, or \`prompt\`.
- Don't add a page title that repeats the nav item, a subtitle under a title,
  or a stats strip. The data is the page. For visual direction, see \`frontend-design\`.
- Follow the app's existing localization pattern for user-facing copy.
- Add a pure \`link\` builder with \`buildDeepLink()\` to actions that create or
  list navigable resources; see \`adding-a-feature\` for the shape.

### Agent instructions

Append one section of about 1,500 characters at most to \`AGENTS.md\`. The
runtime prompt cuts the file off at 6,000 characters. Cover:

- a one-line purpose with the routes
- the invariants, and how to report a rejection
- time and format conventions
- the new \`navigation\` fields
- an action table with unpadded cells

Keep the action table aligned with the scaffold's primary tool list when one
exists; other actions should remain discoverable through \`tool-search\`. Leave
unrelated AGENTS.md sections, README, and DESIGN.md as they are.

### Real-time

Agent writes need no wiring, because the chat run refreshes action queries
after each tool. Add \`useDbSync({ realtime: { reason } })\` to a page only when
other people change its data while it is open and the user must see the change
before refreshing. A booking grid doesn't qualify: the server rejects bookings
made from a stale view. See \`real-time-sync\`.

## 4. Verify, once, in this order

1. Start \`pnpm exec agent-native dev\` in the background, without \`--open\`, and
   wait for the ready URL. Startup regenerates \`.generated/action-types.d.ts\`
   and the actions registry, so a typecheck run before this is meaningless.
   On loopback, automatic dev sign-in works when the local database has no real
   users. If the sign-in page appears, use an existing local account or switch
   to a separate disposable local database; do not create accounts or set
   \`AUTH_DISABLED\`.
2. Run \`pnpm typecheck\`, then \`pnpm agent-native:doctor\`. Plain \`pnpm doctor\`
   runs pnpm's own command and exits 0 without running Agent-Native Doctor. Fix
   every finding, then rerun only what failed.
3. Check the agent path. Call a guarded write twice with the same input via
   \`pnpm action <name> --key value\`. The second call must fail with the expected
   message; read back the saved state through the matching list/get action.
   The CLI prints the failure message, not its structured \`errorCode\`, so also
   verify any code-specific behavior in the action contract or browser.
4. Run one browser smoke on the domain route:
   - create a record
   - trigger the rejection: a toast appears and nothing is written
   - cancel or undo, repeat the previously rejected write, and confirm it
     succeeds

   Inspect console and network failures. Fix errors from the new route or actions
   and identify existing scaffold messages separately. The only expected 4xx/5xx
   is the rejection being tested. Capture the finished workflow.
5. Stop the dev server and close the tab.

Skip the production build, unrelated test suites, and README or DESIGN rewrites.
To triage failures, see \`references/verification.md\`.

## 5. Report

State what works and the proof, what you deferred, and anything the user still
has to do (for example, set \`DATABASE_URL\` before deploying). Never report a
check you didn't run.

## Related

- \`adding-a-feature\`: the parity checklist for each later feature in this app.
- \`frontend-design\`, \`actions\`, \`sharing\`, \`real-time-sync\`, and \`security\`:
  go deeper on one area when the references aren't enough.
`,dir:`.agents/skills/build-an-app`,extraFiles:[`references/data-and-access.md`,`references/edit-points-default.md`,`references/rooms-example.md`,`references/verification.md`],files:{"references/data-and-access.md":"# Data and access decisions\n\nUse this when choosing who may see a row or when adding a schema/migration. A\ntable's columns control framework SQL-tool scoping; app actions still need their\nown access checks for the people and records they return.\n\n## Choose the row model\n\n| Data                                                             | Columns                                                                            | App action behavior                                                                                                                                                      |\n| ---------------------------------------------------------------- | ---------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |\n| Private to its creator (notes, drafts)                           | `owner_email`                                                                      | Filter reads and writes by `ctx.userEmail`; set the owner on insert.                                                                                                     |\n| Shareable resource (documents, dashboards)                       | `...ownableColumns()` plus `createSharesTable()` and `registerShareableResource()` | Use `accessFilter(table, shares)` for lists; use `assertAccess(type, id, role)` before reads/writes by id. Choose `private`, `org`, or `public` visibility deliberately. |\n| Team resource (rooms, products, customers)                       | Same shareable-resource columns                                                    | Use `visibility: \"org\"` when an org is active. Without an org, choose a deliberate private or no-create behavior.                                                        |\n| Child of a resource (bookings in a room, line items in an order) | `parent_id`, `owner_email`, and the parent's `org_id` when present                 | Check access to the parent in the action, then scope every child query by parent id and tenant. Apply child-specific rules in the write action.                          |\n| Organization-only rows (for example, membership records)         | `org_id` only                                                                      | Filter each app action by the active org; this does not support private ownership or per-user share grants.                                                              |\n| Public URL (published form or booking page)                      | Separate slug/token                                                                | Use a public route with its own validation and read policy; sharing visibility does not create anonymous URL access.                                                     |\n\nDo not make a shared team resource private by adding only `owner_email`: that\ncauses normal app actions and lists to hide coworkers' rows. Use\n`ownableColumns()` and the registered sharing helpers. Conversely, a room's\nbookings can inherit the room's access if the booking actions check the room\nbefore returning its rows.\n\n### What agent SQL tools can see\n\n`db-query`/`db-exec` create scoped views: an `owner_email` table is limited to\nthe current owner. If the caller has an active org and the table also has\n`org_id`, rows are further limited to that org or a null org; without an active\norg, only the owner filter applies. An `org_id`-only table is limited to the\ncurrent org and denied when there is no org. A table with neither column is\ndenied. This is deliberately narrower than share grants, so use typed app\nactions to list team-shared records or children that inherit parent access.\nDo not add filters to raw SQL that duplicate these views.\n\nThe same row scoping does not replace action authorization. `accessFilter`\nresolves resource visibility/share grants; `assertAccess` checks one resource\nand role. The person who owns a row and a person with an org role are different\naccess concepts.\n\n## Schema and migrations\n\n- PostgreSQL only. Define tables with `drizzle-orm/pg-core`; use\n  `drizzle-orm` query operators. Import framework sharing helpers from\n  `@agent-native/core/db/schema` only for ownable resources.\n- Chat has no database files or Drizzle migration config. Add\n  `server/db/schema.ts`, `server/db/index.ts` with `createGetDb(schema)`, and\n  `server/plugins/db.ts` with `runMigrations([...], { table })`. Follow the\n  bundled Database docs. Other starters may document their own migration path.\n- Each migration entry needs a unique stable `{ version, name, sql }`. Never\n  renumber or edit an applied entry; append a new additive migration.\n- Additive only: new columns are nullable or have a default, and nothing is\n  dropped, renamed, or retyped. Keep SQL DDL aligned with the Drizzle schema.\n- Use text ids from `crypto.randomUUID()`. For sortable time text, normalize\n  every input to UTC `Date#toISOString()` before storing or comparing it.\n- Use a `CHECK` or `UNIQUE` constraint for single-row rules such as valid\n  status, `end > start`, or unique slugs.\n\n`ownableColumns()` provides a development fallback owner value for framework\ncompatibility. App actions must still set the authenticated `ownerEmail` from\n`ctx.userEmail`; never rely on that fallback to identify a real user.\n\n## Invariants across rows\n\nFor rules such as no overlapping bookings or no overselling:\n\n1. Validate and normalize input, then check the caller's access to the parent.\n2. Start `getDb().transaction(async (tx) => { ... })`.\n3. Lock the parent row with `tx.select(...).from(parent).where(...).for(\"update\")`\n   so concurrent writers for that parent serialize.\n4. Query for conflicts with `tx`; if one exists, use `fail()` with a stable\n   `errorCode`, `statusCode: 409`, and a safe conflict identifier.\n5. Insert with `tx` and return the saved result. Do not open a separate query\n   or call another action from inside the transaction callback.\n\nThe lock is effective only when every writer follows the same parent-lock\nprotocol. Put the invariant in one action and use a database constraint when a\nsingle-row constraint can express it.\n\n## Query and security defaults\n\n- Give every action a zod schema. Bound every list with a time range, `.limit()`,\n  or pagination; select only fields the caller needs; index hot filters/sorts.\n- Use parameterized Drizzle queries. Never concatenate user input into SQL.\n- Keep secrets in workspace connections or the vault, not source, SQL, seeds, or\n  instructions. See the `secrets` skill before adding credentials.\n- Put file/image/audio/video/PDF payloads in configured blob storage and save\n  only the returned URL or opaque id in SQL.\n- Add a custom `/api/*` route only for uploads, webhooks, OAuth callbacks,\n  streaming, or public unauthenticated responses. Use actions for app data.\n- Keep startup limited to framework/plugin initialization and migrations;\n  put imports, backfills, and provider calls behind an action or job.\n","references/edit-points-default.md":'# Default scaffold edit points\n\nUse only when `package.json["agent-native"].scaffold.template` is `default`.\nThis scaffold has a document/provider root and a sample `/home` route. It has\nno Chat sidebar, `Layout.tsx`, `server/plugins/agent-chat.ts`, or\n`INITIAL_TOOL_NAMES` list.\n\n| File                                            | Change                                                                                                                           |\n| ----------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |\n| `server/db/schema.ts` (new)                     | Define PostgreSQL tables with `drizzle-orm/pg-core`; use the shared schema helpers when access/sharing needs them                |\n| `server/db/index.ts` (new)                      | Export `getDb = createGetDb(schema)` and register shareable resources as needed                                                  |\n| `server/plugins/db.ts` (new)                    | Add named, additive migrations with `runMigrations`                                                                              |\n| `actions/<verb>-<noun>.ts`                      | One default-exported `defineAction` per file; the filename becomes the tool name                                                 |\n| `app/routes.ts` and `app/routes/<domain>.tsx`   | `flatRoutes()` discovers route files; add the domain route and nested routes using the filename conventions already present      |\n| `app/root.tsx`                                  | Keep the document, providers, and `<Outlet />`; do not replace it with a domain shell                                            |\n| `app/hooks/use-navigation-state.ts`             | Extend the current path-derived navigation state only when the agent needs selected domain ids or filters beyond the current URL |\n| `server/plugins/agent-native-email-branding.ts` | Set `app.homePath` to the requested authenticated home route; the create command adds this plugin when it renames the scaffold   |\n| `AGENTS.md`                                     | Add a concise domain section with routes, invariants, state, and primary actions                                                 |\n\n`app/routes/_index.tsx` is the sign-in landing route. `app/routes/home.tsx`\nis the authenticated sample page. Preserve both unless the requested workflow\nspecifically replaces the home experience. The default template has no app\nnavigation shell to extend; add only the navigation the product needs.\n',"references/rooms-example.md":`# Worked example: meeting-room booking slice

Request: "Build a meeting room booking app that prevents double-bookings and
shows a weekly grid per room." Adapt the access and invariant patterns; build
complete screens for the requested workflow.

Plan (step 2):

1. Slice: create room, book a slot, reject overlap, cancel, weekly grid. Defer
   recurrence, invites, and notifications.
2. Access: rooms are org-visible when an org is active, and private to their
   creator otherwise. Bookings inherit room visibility; only the booker can
   cancel their booking.
3. Invariant: confirmed bookings for one room never overlap. Enforced in
   \`create-booking\` inside a transaction that locks the room row.
4. Actions: \`list-rooms\`, \`create-room\`, \`list-bookings\`, \`create-booking\`,
   \`cancel-booking\`.
5. Route: \`/rooms\` and \`/rooms/:roomId?week=YYYY-MM-DD\`, nested under a layout
   route with an \`<Outlet />\`. Set \`homePath: "/rooms"\`.
6. Navigation: \`roomId\`, \`week\`.

## Schema: \`server/db/schema.ts\`

\`\`\`ts
import { sql } from "drizzle-orm";
import { integer, pgTable, text } from "drizzle-orm/pg-core";
import {
  createSharesTable,
  ownableColumns,
} from "@agent-native/core/db/schema";

export const rooms = pgTable("rooms", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  capacity: integer("capacity"),
  createdAt: text("created_at")
    .notNull()
    .default(sql\`now()\`),
  ...ownableColumns(), // owner_email, org_id, visibility
});
export const roomShares = createSharesTable("room_shares");

// Times are ISO text (same as the Calendar template's bookings). Always store
// Date#toISOString() output so string order equals time order.
export const bookings = pgTable("bookings", {
  id: text("id").primaryKey(),
  roomId: text("room_id").notNull(),
  title: text("title").notNull(),
  startsAt: text("starts_at").notNull(),
  endsAt: text("ends_at").notNull(),
  status: text("status", { enum: ["confirmed", "cancelled"] })
    .notNull()
    .default("confirmed"),
  ownerEmail: text("owner_email").notNull(), // the booker
  orgId: text("org_id"), // copied from the parent room for tenant scoping
  createdAt: text("created_at")
    .notNull()
    .default(sql\`now()\`),
});
\`\`\`

## Client and sharing registration: \`server/db/index.ts\`

\`\`\`ts
import { createGetDb } from "@agent-native/core/db";
import { registerShareableResource } from "@agent-native/core/sharing";

import * as schema from "./schema.js";

export const getDb = createGetDb(schema);
export { schema };

registerShareableResource({
  type: "room",
  resourceTable: schema.rooms,
  sharesTable: schema.roomShares,
  displayName: "Room",
  titleColumn: "name",
  getResourcePath: (room) => \`/rooms/\${room.id}\`,
  getDb,
});
\`\`\`

## Migration: \`server/plugins/db.ts\`

\`\`\`ts
import { runMigrations } from "@agent-native/core/db";

export default runMigrations(
  [
    {
      version: 1,
      name: "rooms-and-bookings",
      sql: \`CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  capacity INTEGER,
  created_at TEXT NOT NULL DEFAULT (now()),
  owner_email TEXT NOT NULL DEFAULT 'local@localhost',
  org_id TEXT,
  visibility TEXT NOT NULL DEFAULT 'private'
);
CREATE TABLE IF NOT EXISTS room_shares (
  id TEXT PRIMARY KEY,
  resource_id TEXT NOT NULL,
  principal_type TEXT NOT NULL,
  principal_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'viewer',
  created_by TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (now()),
  notified_at TEXT
);
CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES rooms(id),
  title TEXT NOT NULL,
  starts_at TEXT NOT NULL,
  ends_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'cancelled')),
  owner_email TEXT NOT NULL,
  org_id TEXT,
  created_at TEXT NOT NULL DEFAULT (now()),
  CHECK (ends_at > starts_at)
);
CREATE INDEX IF NOT EXISTS rooms_owner_org_name_idx ON rooms (owner_email, org_id, name);
CREATE INDEX IF NOT EXISTS room_shares_resource_idx ON room_shares (resource_id, principal_type, principal_id);
CREATE INDEX IF NOT EXISTS bookings_room_starts_idx ON bookings (room_id, starts_at);
CREATE INDEX IF NOT EXISTS bookings_org_room_starts_idx ON bookings (org_id, room_id, starts_at)\`,
    },
  ],
  { table: "rooms_app_migrations" },
);
\`\`\`

Later schema changes are new entries (\`version: 2, name: "bookings-notes"\`,
\`ALTER TABLE bookings ADD COLUMN IF NOT EXISTS notes TEXT\`). Never edit entry 1
once it has run.

## Shared helper: \`server/lib/bookings.ts\`

\`\`\`ts
import { fail } from "@agent-native/core/action";
import { and, eq, gt, isNull, lt } from "drizzle-orm";

import { schema } from "../db/index.js";

export function toIso(value: string, field: string): string {
  if (!/^\\d{4}-\\d{2}-\\d{2}T.*(?:Z|[+-]\\d{2}:\\d{2})$/.test(value)) {
    fail(\`\${field} must include a time and UTC offset.\`, {
      errorCode: "invalid_time",
    });
  }
  const ms = Date.parse(value);
  if (Number.isNaN(ms)) {
    fail(\`\${field} must be an ISO 8601 date-time.\`, {
      errorCode: "invalid_time",
    });
  }
  return new Date(ms).toISOString();
}

/** Confirmed bookings in \`roomId\` that intersect [from, to). */
export function overlapping(
  roomId: string,
  orgId: string | null,
  from: string,
  to: string,
) {
  const b = schema.bookings;
  return and(
    eq(b.roomId, roomId),
    orgId ? eq(b.orgId, orgId) : isNull(b.orgId),
    eq(b.status, "confirmed"),
    lt(b.startsAt, to),
    gt(b.endsAt, from),
  );
}
\`\`\`

## Actions

\`actions/list-rooms.ts\`

\`\`\`ts
import { defineAction } from "@agent-native/core/action";
import { buildDeepLink } from "@agent-native/core/server";
import { accessFilter } from "@agent-native/core/sharing";
import { z } from "zod";

import { getDb, schema } from "../server/db/index.js";

export default defineAction({
  description: "List the rooms the current user can see and book.",
  schema: z.object({}),
  http: { method: "GET" },
  readOnly: true,
  link: () => ({
    url: buildDeepLink({ view: "rooms", to: "/rooms" }),
    label: "Open Rooms",
  }),
  run: async () => {
    const { rooms, roomShares } = schema;
    const rows = await getDb()
      .select({ id: rooms.id, name: rooms.name, capacity: rooms.capacity })
      .from(rooms)
      .where(accessFilter(rooms, roomShares))
      .orderBy(rooms.name)
      .limit(200);
    return { rooms: rows };
  },
});
\`\`\`

\`actions/create-room.ts\`

\`\`\`ts
import { defineAction, fail } from "@agent-native/core/action";
import { buildDeepLink } from "@agent-native/core/server";
import { z } from "zod";

import { getDb, schema } from "../server/db/index.js";

export default defineAction({
  description:
    "Create a bookable room. It is visible to the organization when one is active, otherwise only to its creator.",
  schema: z.object({
    name: z.string().min(1).describe('Room name, e.g. "Atlas"'),
    capacity: z.coerce
      .number()
      .int()
      .min(1)
      .optional()
      .describe("Seats; omit when unknown"),
  }),
  link: ({ result }) => ({
    url: buildDeepLink({
      view: "rooms",
      to: \`/rooms/\${encodeURIComponent(result.id)}\`,
      params: { roomId: result.id },
    }),
    label: \`Open \${result.name}\`,
  }),
  run: async (args, ctx) => {
    const ownerEmail =
      ctx?.userEmail ?? fail("Sign in to create rooms.", { statusCode: 401 });
    const orgId = ctx?.orgId ?? null;
    const room = {
      id: crypto.randomUUID(),
      name: args.name,
      capacity: args.capacity ?? null,
      ownerEmail,
      orgId,
      visibility: orgId ? ("org" as const) : ("private" as const),
    };
    await getDb().insert(schema.rooms).values(room);
    return { id: room.id, name: room.name, capacity: room.capacity };
  },
});
\`\`\`

\`actions/list-bookings.ts\`

\`\`\`ts
import { defineAction, fail } from "@agent-native/core/action";
import { buildDeepLink } from "@agent-native/core/server";
import { accessFilter } from "@agent-native/core/sharing";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

import { getDb, schema } from "../server/db/index.js";
import { overlapping, toIso } from "../server/lib/bookings.js";

export default defineAction({
  description:
    "List confirmed bookings for a room that overlap a time range (for example, one week).",
  schema: z.object({
    roomId: z.string().describe("Room id from list-rooms"),
    from: z
      .string()
      .datetime({ offset: true })
      .describe("Range start, ISO 8601 with offset"),
    to: z
      .string()
      .datetime({ offset: true })
      .describe("Range end (exclusive), ISO 8601 with offset"),
  }),
  http: { method: "GET" },
  readOnly: true,
  link: ({ args }) => ({
    url: buildDeepLink({
      view: "rooms",
      to: \`/rooms/\${encodeURIComponent(args.roomId)}?week=\${encodeURIComponent(args.from.slice(0, 10))}\`,
      params: { roomId: args.roomId, week: args.from.slice(0, 10) },
    }),
    label: "Open room schedule",
  }),
  run: async (args) => {
    const { rooms, roomShares, bookings } = schema;
    const [room] = await getDb()
      .select({ orgId: rooms.orgId })
      .from(rooms)
      .where(and(eq(rooms.id, args.roomId), accessFilter(rooms, roomShares)))
      .limit(1);
    if (!room)
      fail("Room not found.", { errorCode: "not_found", statusCode: 404 });
    const b = bookings;
    const rows = await getDb()
      .select({
        id: b.id,
        title: b.title,
        startsAt: b.startsAt,
        endsAt: b.endsAt,
      })
      .from(b)
      .where(
        overlapping(
          args.roomId,
          room.orgId,
          toIso(args.from, "from"),
          toIso(args.to, "to"),
        ),
      )
      .orderBy(b.startsAt)
      .limit(500);
    return { bookings: rows };
  },
});
\`\`\`

\`actions/create-booking.ts\`: the invariant lives here and nowhere else.

\`\`\`ts
import { defineAction, fail } from "@agent-native/core/action";
import { buildDeepLink } from "@agent-native/core/server";
import { accessFilter } from "@agent-native/core/sharing";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

import { getDb, schema } from "../server/db/index.js";
import { overlapping, toIso } from "../server/lib/bookings.js";

export default defineAction({
  description:
    "Book a room for a time range. Fails with errorCode booking_conflict (409) if it overlaps a confirmed booking; report the conflict instead of retrying.",
  schema: z.object({
    roomId: z.string().describe("Room id from list-rooms"),
    title: z.string().min(1).describe("What the booking is for"),
    startsAt: z
      .string()
      .datetime({ offset: true })
      .describe("Start, ISO 8601 with offset, e.g. 2026-10-06T09:00:00-07:00"),
    endsAt: z
      .string()
      .datetime({ offset: true })
      .describe("End, ISO 8601 with offset; must be after startsAt"),
  }),
  link: ({ args }) => ({
    url: buildDeepLink({
      view: "rooms",
      to: \`/rooms/\${encodeURIComponent(args.roomId)}\`,
      params: { roomId: args.roomId },
    }),
    label: "Open room schedule",
  }),
  run: async (args, ctx) => {
    const ownerEmail =
      ctx?.userEmail ?? fail("Sign in to book a room.", { statusCode: 401 });
    const startsAt = toIso(args.startsAt, "startsAt");
    const endsAt = toIso(args.endsAt, "endsAt");
    if (endsAt <= startsAt)
      fail("endsAt must be after startsAt.", { errorCode: "invalid_range" });

    return getDb().transaction(async (tx) => {
      const { rooms, roomShares, bookings } = schema;
      // Locking the room row serializes bookings per room; without it two
      // simultaneous requests both pass the overlap check.
      const [room] = await tx
        .select({ id: rooms.id, orgId: rooms.orgId })
        .from(rooms)
        .where(and(eq(rooms.id, args.roomId), accessFilter(rooms, roomShares)))
        .for("update");
      if (!room)
        fail("Room not found.", { errorCode: "not_found", statusCode: 404 });

      const [clash] = await tx
        .select({
          id: bookings.id,
          title: bookings.title,
          startsAt: bookings.startsAt,
          endsAt: bookings.endsAt,
        })
        .from(bookings)
        .where(overlapping(args.roomId, room.orgId, startsAt, endsAt))
        .limit(1);
      if (clash) {
        fail(
          \`Overlaps "\${clash.title}" (\${clash.startsAt} to \${clash.endsAt}).\`,
          {
            errorCode: "booking_conflict",
            statusCode: 409,
            details: { conflictId: clash.id },
          },
        );
      }

      const booking = {
        id: crypto.randomUUID(),
        roomId: args.roomId,
        title: args.title,
        startsAt,
        endsAt,
        ownerEmail,
        orgId: room.orgId,
      };
      await tx.insert(bookings).values(booking);
      return {
        id: booking.id,
        roomId: booking.roomId,
        title: booking.title,
        startsAt: booking.startsAt,
        endsAt: booking.endsAt,
        status: "confirmed" as const,
      };
    });
  },
});
\`\`\`

Inside the transaction callback, use only \`tx\`. Run any other lookups
(\`assertAccess\`, other actions) before you open it.

\`actions/cancel-booking.ts\`

\`\`\`ts
import { defineAction, fail } from "@agent-native/core/action";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

import { getDb, schema } from "../server/db/index.js";

export default defineAction({
  description: "Cancel a booking made by the current user.",
  schema: z.object({ id: z.string().describe("Booking id") }),
  run: async ({ id }, ctx) => {
    const email = ctx?.userEmail ?? fail("Sign in first.", { statusCode: 401 });
    const b = schema.bookings;
    const [cancelled] = await getDb()
      .update(b)
      .set({ status: "cancelled" })
      .where(
        and(eq(b.id, id), eq(b.ownerEmail, email), eq(b.status, "confirmed")),
      )
      .returning({ id: b.id });
    if (!cancelled) {
      fail("Booking not found or you cannot cancel it.", {
        errorCode: "not_found",
        statusCode: 404,
      });
    }
    return { id, status: "cancelled" as const };
  },
});
\`\`\`

## Screens

\`app/components/ui/skeleton.tsx\` (one line, like the shipped \`button.tsx\`):

\`\`\`ts
export * from "@agent-native/toolkit/ui/skeleton";
\`\`\`

\`app/routes/rooms.tsx\` is a nested route layout that renders \`<Outlet />\`.
\`app/routes/rooms._index.tsx\` lists rooms with an inline add form using
\`useActionQuery("list-rooms", {})\`, a \`<Link to={\`/rooms/\${id}\`}>\` per row,
and \`useActionMutation("create-room")\`. The underscore keeps the index as the
parent's index route in React Router's file-based config.

\`app/routes/rooms.$roomId.tsx\` is a complete weekly grid with local-time inputs,
seven responsive day columns, optimistic booking/cancel updates, conflict feedback,
and a confirmation dialog. It uses the Chat starter route imports; other starters
should follow their edit-point reference for route layout and component paths.

Add the UI strings used by this route and the room list to the existing English
message catalog under \`rooms\`: \`addRoom\`, \`addingRoom\`, \`backToRooms\`, \`book\`,
\`booking\`, \`bookingCreated\`, \`bookingName\`, \`cancel\`, \`cancelBookingDescription\`,
\`cancelBookingTitle\`, \`cancelFailed\`, \`cancelling\`, \`capacity\`, \`confirmCancel\`,
\`conflict\`, \`createFailed\`, \`emptyDay\`, \`emptyRooms\`, \`end\`, \`invalidRange\`,
\`keepBooking\`, \`nav\`, \`nextWeek\`, \`previousWeek\`, \`roomCreated\`, \`roomName\`,
\`roomNotFound\`, \`seats\`, and \`start\`. Follow the scaffold localization pattern
for any additional configured locales.

\`\`\`tsx
import {
  actionErrorMessage,
  useActionMutation,
  useActionQuery,
} from "@agent-native/core/client/hooks";
import { useT } from "@agent-native/core/client/i18n";
import {
  IconChevronLeft,
  IconChevronRight,
  IconClock,
  IconUsers,
} from "@tabler/icons-react";
import { useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router";
import { toast } from "sonner";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";

type Booking = {
  id: string;
  title: string;
  startsAt: string;
  endsAt: string;
  status?: string;
};

function startOfWeek(date: Date) {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  return start;
}

function dateKey(date: Date) {
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
  ].join("-");
}

function weekRange(week: string) {
  const parsed = new Date(week + "T00:00:00");
  const start = startOfWeek(
    Number.isNaN(parsed.getTime()) ? new Date() : parsed,
  );
  const end = new Date(start);
  end.setDate(end.getDate() + 7);
  return { start, from: start.toISOString(), to: end.toISOString() };
}

function localInputValue(date: Date) {
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000)
    .toISOString()
    .slice(0, 16);
}

function initialTimes() {
  const start = new Date();
  start.setMinutes(0, 0, 0);
  start.setHours(start.getHours() + 1);
  const end = new Date(start);
  end.setHours(end.getHours() + 1);
  return { startsAt: localInputValue(start), endsAt: localInputValue(end) };
}

function hour(value: string) {
  return new Intl.DateTimeFormat(undefined, {
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
}

function errorCode(error: unknown) {
  if (
    error &&
    typeof error === "object" &&
    "errorCode" in error &&
    typeof error.errorCode === "string"
  )
    return error.errorCode;
  return undefined;
}

export default function RoomWeekRoute() {
  const t = useT();
  const { roomId = "" } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [formTimes] = useState(initialTimes);
  const [title, setTitle] = useState("");
  const [startsAt, setStartsAt] = useState(formTimes.startsAt);
  const [endsAt, setEndsAt] = useState(formTimes.endsAt);
  const [pendingCancelId, setPendingCancelId] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const week = searchParams.get("week") ?? dateKey(startOfWeek(new Date()));
  const range = useMemo(() => weekRange(week), [week]);
  const params = useMemo(
    () => ({ roomId, from: range.from, to: range.to }),
    [roomId, range.from, range.to],
  );
  const queryKey = ["action", "list-bookings", params];
  const { data, isPending } = useActionQuery("list-bookings", params);
  const roomsQuery = useActionQuery("list-rooms", {});
  const room = roomsQuery.data?.rooms.find(
    (candidate) => candidate.id === roomId,
  );

  const book = useActionMutation("create-booking", {
    onMutate: async (input) => {
      await queryClient.cancelQueries({ queryKey });
      const previous = queryClient.getQueryData(queryKey);
      queryClient.setQueryData(
        queryKey,
        (old: { bookings: Booking[] } | undefined) =>
          old && {
            bookings: [
              ...old.bookings,
              { ...input, id: "pending-" + Date.now(), status: "confirmed" },
            ],
          },
      );
      return { previous };
    },
    onError: (error, _input, context) => {
      queryClient.setQueryData(
        queryKey,
        (context as { previous?: unknown } | undefined)?.previous,
      );
      toast.error(
        errorCode(error) === "booking_conflict"
          ? t("rooms.conflict")
          : (actionErrorMessage(error) ?? t("rooms.createFailed")),
      );
    },
    onSuccess: () => {
      setTitle("");
      toast.success(t("rooms.bookingCreated"));
    },
  });

  const cancel = useActionMutation("cancel-booking", {
    onMutate: async ({ id }) => {
      await queryClient.cancelQueries({ queryKey });
      const previous = queryClient.getQueryData(queryKey);
      queryClient.setQueryData(
        queryKey,
        (old: { bookings: Booking[] } | undefined) =>
          old && {
            bookings: old.bookings.filter((booking) => booking.id !== id),
          },
      );
      return { previous };
    },
    onError: (error, _input, context) => {
      queryClient.setQueryData(
        queryKey,
        (context as { previous?: unknown } | undefined)?.previous,
      );
      toast.error(actionErrorMessage(error) ?? t("rooms.cancelFailed"));
    },
    onSuccess: () => setPendingCancelId(null),
  });

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const start = new Date(startsAt);
    const end = new Date(endsAt);
    if (
      !title.trim() ||
      Number.isNaN(start.getTime()) ||
      Number.isNaN(end.getTime()) ||
      end <= start
    ) {
      toast.error(t("rooms.invalidRange"));
      return;
    }
    book.mutate({
      roomId,
      title: title.trim(),
      startsAt: start.toISOString(),
      endsAt: end.toISOString(),
    });
  }

  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(range.start);
    date.setDate(date.getDate() + index);
    return date;
  });
  const bookings = data?.bookings ?? [];

  function moveWeek(amount: number) {
    const next = new Date(range.start);
    next.setDate(next.getDate() + amount * 7);
    setSearchParams({ week: dateKey(next) });
  }

  if (roomsQuery.isPending || isPending) {
    return (
      <main className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 xl:grid-cols-7">
        {Array.from({ length: 7 }, (_, index) => (
          <Skeleton key={index} className="h-72 rounded-xl" />
        ))}
      </main>
    );
  }
  if (!room) {
    return (
      <main className="p-6">
        <p className="text-sm text-muted-foreground">
          {t("rooms.roomNotFound")}
        </p>
        <Link className="mt-3 inline-block text-sm underline" to="/rooms">
          {t("rooms.backToRooms")}
        </Link>
      </main>
    );
  }

  return (
    <main className="flex min-h-full flex-col gap-4 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <Link
            to="/rooms"
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            {t("rooms.backToRooms")}
          </Link>
          <h1 className="mt-1 truncate text-xl font-semibold tracking-tight">
            {room.name}
          </h1>
          {room.capacity ? (
            <p className="mt-1 inline-flex items-center gap-1.5 text-sm text-muted-foreground">
              <IconUsers className="size-4" />
              {room.capacity} {t("rooms.seats")}
            </p>
          ) : null}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            aria-label={t("rooms.previousWeek")}
            onClick={() => moveWeek(-1)}
          >
            <IconChevronLeft className="size-4" />
          </Button>
          <span className="min-w-32 text-center text-sm font-medium">
            {new Intl.DateTimeFormat(undefined, {
              month: "short",
              day: "numeric",
            }).format(range.start)}
          </span>
          <Button
            variant="outline"
            size="icon"
            aria-label={t("rooms.nextWeek")}
            onClick={() => moveWeek(1)}
          >
            <IconChevronRight className="size-4" />
          </Button>
        </div>
      </div>

      <form
        onSubmit={submit}
        className="grid gap-3 rounded-xl border border-border bg-card p-4 md:grid-cols-[minmax(10rem,1fr)_minmax(11rem,1fr)_minmax(11rem,1fr)_auto] md:items-end"
      >
        <div className="space-y-1.5">
          <Label htmlFor="booking-title">{t("rooms.bookingName")}</Label>
          <Input
            id="booking-title"
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            maxLength={100}
            required
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="booking-start">{t("rooms.start")}</Label>
          <Input
            id="booking-start"
            type="datetime-local"
            value={startsAt}
            onChange={(event) => setStartsAt(event.target.value)}
            required
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="booking-end">{t("rooms.end")}</Label>
          <Input
            id="booking-end"
            type="datetime-local"
            value={endsAt}
            onChange={(event) => setEndsAt(event.target.value)}
            required
          />
        </div>
        <Button type="submit" disabled={!title.trim() || book.isPending}>
          {book.isPending ? t("rooms.booking") : t("rooms.book")}
        </Button>
      </form>

      <div className="grid min-h-0 grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-7">
        {days.map((day) => {
          const dayBookings = bookings.filter(
            (booking) => dateKey(new Date(booking.startsAt)) === dateKey(day),
          );
          return (
            <section
              key={dateKey(day)}
              className="min-h-40 rounded-xl border border-border bg-card p-3"
            >
              <h2 className="mb-3 flex items-center justify-between border-b border-border pb-2 text-sm font-medium">
                <span>
                  {new Intl.DateTimeFormat(undefined, {
                    weekday: "short",
                  }).format(day)}
                </span>
                <time className="text-muted-foreground" dateTime={dateKey(day)}>
                  {new Intl.DateTimeFormat(undefined, {
                    month: "numeric",
                    day: "numeric",
                  }).format(day)}
                </time>
              </h2>
              <div className="space-y-2">
                {dayBookings.length ? (
                  dayBookings.map((booking) => (
                    <article
                      key={booking.id}
                      className="rounded-lg border border-border bg-background p-2.5"
                    >
                      <div className="flex items-start gap-2">
                        <IconClock className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" />
                        <span className="min-w-0">
                          <strong className="block truncate text-xs font-medium">
                            {booking.title}
                          </strong>
                          <time className="text-xs text-muted-foreground">
                            {hour(booking.startsAt)}–{hour(booking.endsAt)}
                          </time>
                        </span>
                      </div>
                      {!booking.id.startsWith("pending-") ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="mt-1 h-7 px-1.5 text-xs text-muted-foreground"
                          onClick={() => setPendingCancelId(booking.id)}
                        >
                          {t("rooms.cancel")}
                        </Button>
                      ) : null}
                    </article>
                  ))
                ) : (
                  <p className="py-5 text-center text-xs text-muted-foreground">
                    {t("rooms.emptyDay")}
                  </p>
                )}
              </div>
            </section>
          );
        })}
      </div>

      <AlertDialog
        open={Boolean(pendingCancelId)}
        onOpenChange={(open) => {
          if (!open) setPendingCancelId(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("rooms.cancelBookingTitle")}</AlertDialogTitle>
            <AlertDialogDescription>
              {t("rooms.cancelBookingDescription")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("rooms.keepBooking")}</AlertDialogCancel>
            <AlertDialogAction
              disabled={cancel.isPending}
              onClick={() => {
                if (pendingCancelId) cancel.mutate({ id: pendingCancelId });
              }}
            >
              {cancel.isPending
                ? t("rooms.cancelling")
                : t("rooms.confirmCancel")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
}
\`\`\`

The booking mutation reports \`booking_conflict\` through \`fail()\`; the route
shows the localized conflict toast and rolls back its optimistic row. The cancel
mutation removes the booking optimistically and the query refresh confirms the
released slot. The mutation hook refetches action queries after success.

## Shell edits

\`app/components/layout/Sidebar.tsx\`: add \`IconDoor\` to the existing
\`@tabler/icons-react\` import, then add this inside \`<nav>\`, directly above
\`<ChatThreadsSection collapsed={collapsed} />\`:

\`\`\`tsx
<div className={collapsed ? undefined : "px-2 pb-1"}>
  <Link
    to="/rooms"
    aria-label={collapsed ? "Rooms" : undefined}
    className={cn(
      "flex items-center text-sidebar-accent-foreground transition-colors hover:bg-sidebar-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sidebar-ring",
      collapsed
        ? "size-10 justify-center rounded-md"
        : "h-10 w-full gap-3 rounded-lg px-3 text-sm font-medium",
    )}
  >
    <IconDoor className="size-4 shrink-0" strokeWidth={1.8} />
    <span className={collapsed ? "sr-only" : "truncate"}>Rooms</span>
  </Link>
</div>
\`\`\`

\`app/hooks/use-navigation-state.ts\`:

\`\`\`ts
export interface NavigationState {
  view: string;
  path?: string;
  threadId?: string;
  roomId?: string;
  week?: string;
}

// in getNavigationState({ pathname, searchParams }):
const roomId = pathname.match(/^\\/rooms\\/([^/]+)/)?.[1];
const week = searchParams.get("week");
return {
  view: viewForPath(pathname),
  path: appPath(pathname),
  ...(threadId ? { threadId } : {}),
  ...(roomId ? { roomId: decodeURIComponent(roomId) } : {}),
  ...(week ? { week } : {}),
};

// first line of viewForPath:
if (pathname.startsWith("/rooms")) return "rooms";
// in pathForView:
case "rooms":
  return "/rooms";
\`\`\`

The agent can now \`navigate --path "/rooms/<id>?week=2026-10-05"\`, and
\`view-screen\` (which returns \`navigation\`) shows \`roomId\` and \`week\`. Extend
\`view-screen\` only if the agent needs a summary of what is visible, and keep
that to ids and titles.

\`server/plugins/agent-chat.ts\`:

\`\`\`ts
const INITIAL_TOOL_NAMES = [
  "view-screen",
  "navigate",
  "list-rooms",
  "create-room",
  "list-bookings",
  "create-booking",
  "cancel-booking",
];
// systemPrompt first line: "You are the Rooms app agent. You book meeting rooms without double-booking."
\`\`\`

\`server/plugins/agent-native-email-branding.ts\`: change \`homePath: "/home"\` to
\`homePath: "/rooms"\`.

## \`AGENTS.md\` section (about 900 characters)

\`\`\`md
## Rooms

Book meeting rooms without double-booking. \`/rooms\` lists rooms; \`/rooms/:roomId?week=YYYY-MM-DD\` is the weekly grid. Chat stays at \`/home\`.

- Rooms are org-visible when an organization is active and private to their creator otherwise. Bookings belong to a room and inherit its access.
- \`create-booking\` is the only way to book. It rejects overlaps with \`booking_conflict\`; tell the user which booking clashes and don't retry with other times unless asked.
- Enter times in the user's timezone and send ISO 8601 with an offset; actions store normalized UTC values.
- On room pages \`navigation\` adds \`roomId\` and \`week\`.

| Action         | Purpose                                                   |
| -------------- | --------------------------------------------------------- |
| list-rooms     | Rooms the user can book                                   |
| create-room    | Add an org-visible room, or a private room without an org |
| list-bookings  | Confirmed bookings in a range                             |
| create-booking | Book a slot (409 on overlap)                              |
| cancel-booking | Cancel a booking made by the current user                 |
\`\`\`

## Smoke for this slice

\`\`\`bash
pnpm action create-room --name Atlas                     # note the id
pnpm action create-booking --roomId <id> --title Sync --startsAt 2026-10-06T10:00:00Z --endsAt 2026-10-06T11:00:00Z
pnpm action create-booking --roomId <id> --title Clash --startsAt 2026-10-06T10:30:00Z --endsAt 2026-10-06T11:30:00Z   # must fail: booking_conflict
pnpm action list-bookings --roomId <id> --from 2026-10-06T00:00:00Z --to 2026-10-07T00:00:00Z
pnpm action cancel-booking --id <booking-id>
pnpm action create-booking --roomId <id> --title Clash --startsAt 2026-10-06T10:30:00Z --endsAt 2026-10-06T11:30:00Z   # now succeeds
\`\`\`

In the browser, open \`/rooms/<id>?week=2026-10-05\` and check:

- booking 10:00 to 11:00 appears immediately
- booking 10:30 to 11:30 shows the conflict toast, and the grid keeps one booking
- canceling the first booking lets the 10:30 booking succeed in that slot
`,"references/verification.md":'# Verification: run order and triage\n\n## Run order and why\n\n1. **Dev server first.** Run `pnpm exec agent-native dev` in the background.\n   `pnpm dev` also works but passes `--open` and launches a browser. Starting\n   the server runs your migrations and regenerates `.generated/action-types.d.ts`\n   and `.generated/actions-registry.ts`. Until it has run, `useActionQuery("new-action")`\n   cannot type-check and the agent cannot see the new tools.\n2. **`pnpm typecheck`.** This runs React Router typegen, then `tsc --noEmit`.\n   It does not regenerate action types; step 1 does that.\n3. **`pnpm agent-native:doctor`.** It scans `actions/` and `server/` for\n   unscoped queries on ownable tables, credentials read from `process.env`,\n   and similar mistakes. If the script is missing, run `pnpm exec agent-native doctor`.\n4. **Agent path.** Run `pnpm action <name> --key value`. When the dev server is\n   running, the CLI forwards the call to it, so it shares the same database and\n   dev identity. Call the guarded write twice with the same input and verify\n   the second fails with the expected message; read the saved state through the\n   matching list/get action. The CLI prints failure messages, not structured\n   `errorCode` values, so verify code-specific behavior in the action contract\n   or browser. Raw `db-query` views are scoped to the current owner or\n   organization and do not include all records granted through app-level sharing.\n5. **One browser smoke** on the domain route: create, the rejected case, and\n   undo or cancel. Inspect console and failed network requests. Fix errors from\n   the new route or actions; identify existing scaffold messages separately.\n   On loopback, automatic dev sign-in works while the database has no real\n   users. If it shows a sign-in page, use an existing local account or a\n   separate disposable local database; do not create accounts or set\n   `AUTH_DISABLED`. Capture the finished workflow.\n6. **Clean up.** Close the tab and stop the dev server.\n\nRun each check once. After a fix, rerun only the check that failed. Don\'t\nadd a production build, new test files, or a second full pass.\n\n## Triage\n\n| Symptom                                                                 | Usual cause                                                                                                 | Fix                                                                                                                                                      |\n| ----------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |\n| `useActionQuery("x")` type error, or the action is unknown to the agent | `.generated/*` is stale                                                                                     | Make sure the dev server is running, save the action file, and rerun typecheck                                                                           |\n| `relation "x" does not exist`                                           | The table has no migration entry, or `server/plugins/db.ts` doesn\'t default-export `runMigrations(...)`     | Add the entry and restart dev                                                                                                                            |\n| Migration ignored after an edit                                         | You changed an entry that had already run                                                                   | Revert the edit and append a new named entry                                                                                                             |\n| 405 from an action                                                      | The HTTP method and the hook disagree                                                                       | Reads use `http: { method: "GET" }` with `useActionQuery`; writes use the default POST with `useActionMutation`                                          |\n| Toast says "Internal server error"                                      | A bare `throw`                                                                                              | Throw with `fail(message, { statusCode })`                                                                                                               |\n| A rejected write shows as a success                                     | The action returned `{ error }`                                                                             | Throw with `fail()`                                                                                                                                      |\n| `view-screen` reports `view: "chat"` on a domain page                   | `viewForPath` has no case for the route                                                                     | Add the case                                                                                                                                             |\n| The agent asks "which one?" on a detail page                            | The id isn\'t in `navigation`                                                                                | Add it in `getNavigationState`                                                                                                                           |\n| The agent doesn\'t reach for the new actions                             | They aren\'t in `INITIAL_TOOL_NAMES` or `AGENTS.md`                                                          | Add them to both                                                                                                                                         |\n| Sign-in lands on `/home`                                                | `homePath` is unset, or set somewhere other than a server plugin                                            | Set it with `defineAppConfig` in `server/plugins/` and restart dev                                                                                       |\n| Sign-in page during the smoke                                           | The DB has a real user, `AGENT_NATIVE_DISABLE_AUTO_DEV_ACCOUNT=1`, or the server isn\'t loopback development | Use an existing local account or a separate disposable local DB; verify loopback dev and clear the opt-out. Don\'t create accounts or set `AUTH_DISABLED` |\n| Doctor reports an unscoped query                                        | An ownable table is read without an access helper in that statement or block                                | Put `accessFilter(...)` in the query\'s `where`, or call `assertAccess` first in the same block                                                           |\n| `Named export \'IconX\' not found`                                        | The icon name was guessed                                                                                   | Grep the exact name in `node_modules/@tabler/icons-react/dist/tabler-icons-react.d.ts`                                                                   |\n| A `@/components/ui/<x>` import fails                                    | The starter doesn\'t ship that primitive                                                                     | Add `export * from "@agent-native/toolkit/ui/<x>";`                                                                                                      |\n| The UI doesn\'t update after an agent write                              | The page uses raw `useQuery`, not the action hooks                                                          | Switch to `useActionQuery`                                                                                                                               |\n| Two quick writes both succeed despite a rule                            | The check runs outside a transaction or without a lock                                                      | Use the lock-then-check pattern in `data-and-access.md`                                                                                                  |\n\nIf you couldn\'t run a step (no browser tool, port blocked), say so in the\nreport. Don\'t claim it passed.\n'}},"client-side-routing":{meta:{name:`client-side-routing`,description:"How to add routes without remounting the app shell. Use when adding a new route, fixing agent sidebar reloads on navigation, or choosing between `root.tsx` layout and pathless `_app.tsx` layout patterns.",scope:`dev`},content:`---
name: client-side-routing
description: >-
  How to add routes without remounting the app shell. Use when adding a new
  route, fixing agent sidebar reloads on navigation, or choosing between
  \`root.tsx\` layout and pathless \`_app.tsx\` layout patterns.
scope: dev
metadata:
  internal: true
---

# Client-Side Routing

## Rule

All templates are single-page apps using React Router. **Navigation must not remount the app shell.** The agent sidebar, document tree, and any other persistent chrome must survive route changes.

## Why

If the shell unmounts on every navigation, the agent chat reconnects/reloads, destroying in-progress work and hammering the backend.

## Hard Rule

**The app shell (AgentSidebar + any top-level navigation) must be mounted ONCE, above the \`<Outlet />\`.** Never wrap each page in its own \`<AppLayout>\` / \`<Layout>\`. React sees a different component at the outlet position on each nav and unmounts the entire subtree.

## Two Correct Patterns

### 1. All routes need the shell

Mount \`<AppLayout>\` in \`root.tsx\` around \`<Outlet />\`:

\`\`\`tsx
// app/root.tsx
<AppLayout>
  <Outlet />
</AppLayout>
\`\`\`

### 2. Mix of protected and public routes

Use a React Router **pathless layout route**:

\`\`\`
app/routes/
  _app.tsx                  # renders <AppLayout><Outlet /></AppLayout>
  _app._index.tsx           # / → under AppLayout
  _app.settings.tsx         # /settings → under AppLayout
  _app.team.tsx             # /team → under AppLayout
  book.$slug.tsx            # /book/:slug → no layout (public)
  f.$.tsx                   # /f/* → no layout (public form filler)
\`\`\`

The \`_\` prefix on \`_app.tsx\` makes it a **pathless** parent — it contributes the layout but no URL segment. Route files prefixed with \`_app.\` nest under it and share the layout instance across navigations.

## Anti-Pattern

\`\`\`tsx
// ❌ BAD — each route wraps its own Layout, causing full remount on every nav
export default function Settings() {
  return (
    <AppLayout>
      <SettingsContent />
    </AppLayout>
  );
}
\`\`\`

If a page needs per-route data (e.g. sidebar highlighting the active document), derive it inside the layout from \`useParams()\` / \`useLocation()\` — don't pass it as a prop through every route file.

## Chat-First Routes

If \`/\` is a full-page chat such as \`AgentChatHome\`, keep the app shell mounted
around it when possible so \`AgentSidebar\` URL sync and route warmup stay active.
If the chat route intentionally lives outside the shell, add a tiny app-owned
prewarm for the routes agents commonly open from that chat. In local dev,
React Router can update the address bar before a cold Vite route chunk commits,
which makes navigation look broken even when the URL is correct.

## Adding a New Route

- **Pattern #1** (AppLayout in \`root.tsx\`): just render page content — nothing else.
- **Pattern #2** (pathless \`_app.tsx\`): name the file \`_app.<segment>.tsx\` for authed routes, or bare \`<segment>.tsx\` for public routes.

## Related Skills

- \`adding-a-feature\` — The four-area checklist referencing route layout patterns
- \`context-awareness\` — Navigation state written on every route change
`,dir:`.agents/skills/client-side-routing`,extraFiles:[],files:{}},"context-awareness":{meta:{name:`context-awareness`,description:`How the agent knows what the user is looking at. Use when exposing UI state to the agent, implementing view-screen or navigate actions, wiring navigation state, or debugging agent context issues.`,scope:`dev`},content:`---
name: context-awareness
description: >-
  How the agent knows what the user is looking at. Use when exposing UI state to
  the agent, implementing view-screen or navigate actions, wiring navigation
  state, or debugging agent context issues.
scope: dev
metadata:
  internal: true
---

# Context Awareness

## Rule

Apps can sync semantic navigation state when the route changes by using the
shared route-state hook. When screen context is available, Core includes a
\`<current-screen>\` snapshot in each agent turn, so the agent can get basic
route context without first calling another tool. Apps can add concise
visible-record details to that snapshot and expose selection in tab-scoped
state.

## Why

Without context awareness, the agent is blind. It asks "which email?" when the user is staring at one. It cannot act on the current selection, cannot provide relevant suggestions, and cannot modify what the user sees. Context awareness is what makes the agent feel like a collaborator rather than a disconnected chatbot.

## The Core Patterns

### 1. Navigation State (\`navigation\` key)

Use the shared route-state hook to write a tab-scoped \`navigation\` key as the
route changes. Include semantic screen state such as the view, open IDs, active
tab, and focused object.

**UI side** — use \`useAgentRouteState\` in the app's route-state hook. The app
can wrap it in an app-owned \`useNavigationState\` hook to map route paths to
semantic views and consume the agent's \`navigate\` command.

\`\`\`tsx
// app/hooks/use-navigation-state.ts
import { useAgentRouteState } from "@agent-native/core/client/navigation";
import { TAB_ID } from "@/lib/tab-id";

export function useNavigationState() {
  useAgentRouteState({
    browserTabId: TAB_ID,
    requestSource: TAB_ID,
    getNavigationState: ({ pathname, searchParams }) => ({
      view:
        pathname === "/"
          ? "home"
          : pathname === "/sign-in"
            ? "sign-in"
            : pathname.replace(/^\\/+/, ""),
      // Optional semantic alias. Raw query params are already exposed in
      // <current-url> and controllable with set-search-params.
      label: searchParams.get("label"),
    }),
    getCommandPath: (command: any) =>
      command.path ?? \`/\${command.view === "home" ? "home" : command.view}\`,
  });
}
\`\`\`

The default scaffold uses \`/home\` for home and \`/sign-in\` for authentication;
\`/\` redirects according to the configured home route. Map navigation to the
app's actual routes and pass an explicit \`path\` for destinations that do not
follow the \`/<view>\` convention.

\`TAB_ID\` comes from the framework's \`getBrowserTabId()\` (see the scaffolded \`app/lib/tab-id.ts\`; never redefine it). The server resolves tab-scoped \`application_state\` writes and page-local WebMCP calls (\`X-Agent-Native-Browser-Tab\`) against this same id, so a hand-rolled random id silently breaks selection sync for hidden and background tabs.

**Agent side** — read before acting:

\`\`\`ts
import { readAppState } from "@agent-native/core/application-state";

const navigation = await readAppState("navigation");
// e.g. { view: "thread", threadId: "abc123", subject: "Re: Q3 Planning" }
\`\`\`

**What to include in navigation state:**

- \`view\` — the current page/section (e.g., "inbox", "form-builder", "dashboard")
- Item IDs — the selected/open item (e.g., \`threadId\`, \`formId\`, \`issueKey\`)
- Semantic aliases — label names, active tabs, focused row, or stable filter names the agent should reason about
- Focused object IDs and active tabs that are not already represented by URL state

Keep text-selection ranges and excerpts in the tab-scoped \`selection\` key, not
in \`navigation\`.

Raw URL query params are already synced by the framework to \`__url__\` and shown to the built-in agent as \`<current-url>\`. Keep shareable filters in URL state, then use \`view-screen\` to summarize important query params as \`activeFilters\` when helpful.

Keep \`application_state\` values small. Do not store pasted files, base64 images,
recording chunks, screenshots, or other large blobs in navigation or app-state
keys; upload them and store only a URL or storage handle.

### Selection state

For app-owned per-tab selection, suffix the key with \`TAB_ID\`; \`requestSource\`
labels the write origin but does not scope the key. Keep the value to stable ids
and a short label or excerpt, never the full document:

\`\`\`ts
import { writeClientAppState } from "@agent-native/core/client/hooks";
import { TAB_ID } from "@/lib/tab-id";

await writeClientAppState(
  \`selection:\${TAB_ID}\`,
  { kind: "text", id: "artifact-123", text: "short excerpt" },
  { requestSource: TAB_ID },
);
\`\`\`

A server action can read that tab's value with
\`readAppStateForCurrentTab("selection")\`. A \`view-screen\` result may include the
selection and a specific next action when that helps the agent target an edit.

### 2. Current URL (\`__url__\` key)

\`AgentPanel\` automatically writes \`__url__\` with \`{ pathname, search, hash, searchParams }\`. The built-in agent sees it as a \`<current-url>\` block in every turn.

Use this for URL-reachable filters and search state. The agent can update it with the built-in \`set-search-params\` and \`set-url-path\` tools; do not duplicate the whole query string into \`navigation\`.

### Settings page (\`settings-view\` key)

The redesigned Settings shell writes tab-scoped \`settings-view\` = \`{ page, sub, label }\` (for example \`{ page: "integrations", sub: "builder", label: "Connections › Integrations › Builder.io" }\`) and deletes it when Settings closes. \`<current-url>\` shows it as a \`settingsPage:\` line, because a legacy or mounted pathname doesn't name the page the shell resolved. To send the user to a page, call the built-in \`open-settings-page\` tool with a page id (plus \`sub\` or \`anchor\`); it resolves old tab and section ids through the same redirect table as links. A template's own \`navigate\` action only needs a Settings branch for its app areas (\`/settings/app/<area>\`), built with \`buildSettingsRoute\`.

### 3. The \`view-screen\` Action

Use a \`view-screen\` action for a concise snapshot of visible record data the
agent needs in addition to basic navigation. Read navigation and selection
state, then query the relevant summaries through existing data helpers or
Drizzle. Do not add REST wrappers just so \`view-screen\` can read app data.

\`\`\`ts
// actions/view-screen.ts
import { defineAction } from "@agent-native/core/action";
import {
  readAppState,
  readAppStateForCurrentTab,
} from "@agent-native/core/application-state";
import { z } from "zod";

export default defineAction({
  description: "Return a concise snapshot of the current screen.",
  schema: z.object({}),
  http: false,
  readOnly: true,
  run: async () => {
    const navigation = await readAppState("navigation");
    const screen: Record<string, unknown> = {};
    if (navigation) screen.navigation = navigation;

    const selection = await readAppStateForCurrentTab("selection");
    if (selection) screen.selection = selection;

    // Add concise visible-record summaries using the app's existing data helpers.
    return screen;
  },
});
\`\`\`

Core builds the \`<current-screen>\` block for each agent turn by running the
surfaced \`view-screen\` action. If no such action is available, it falls back to
the current tab's \`navigation\` state. The scaffold action returns navigation;
extend it with concise, relevant visible-record details when the app has them.
The agent can use the injected snapshot directly and call \`view-screen\` again
when it needs a fresh read after context has changed.

### 4. The \`navigate\` Action

The agent writes a one-shot \`navigate\` command to application-state. The UI reads it, performs the navigation, and deletes the entry.

**Agent side:**

\`\`\`ts
import { writeAppStateForCurrentTab } from "@agent-native/core/application-state";

// Navigate the user to a specific thread
await writeAppStateForCurrentTab("navigate", {
  view: "inbox",
  path: "/inbox/abc123",
  threadId: "abc123",
});
\`\`\`

**UI side** — use \`useAgentRouteState\`, shown above. It polls command keys,
dedupes \`_writeId\`, deletes consumed commands, and applies app-local routing.

When a destination has a real URL, let the \`navigate\` command carry that local
\`path\` (plus semantic fields when useful) and have the UI prefer \`path\` before
falling back to semantic routing. Keep app navigation single-channel: do not
also write \`__set_url__\` for the same navigation. \`__set_url__\` belongs to the
framework URL tools (\`set-url-path\`, \`set-search-params\`) and URL-only filter
changes. If a command can arrive while a chat stream is rendering, prefer
\`navigate(path, { replace: true, flushSync: true })\` over a view-transition
wrapper so the URL and visible route commit together.

## Jitter Prevention

Agent-side application-state writes are tagged with
\`requestSource: "agent"\`. The UI uses \`useDbSync({ ignoreSource: TAB_ID })\` so
it ignores its own writes while still picking up changes from agents, other
tabs, and scripts.

Import \`useAgentRouteState\` and \`useSemanticNavigationState\` from
\`@agent-native/core/client/navigation\`. Import
\`setClientAppState\`, \`writeClientAppState\`, \`readClientAppState\`, and
\`deleteClientAppState\` from \`@agent-native/core/client/hooks\`; avoid the
deprecated \`@agent-native/core/client\` barrel. Pass \`{ requestSource: TAB_ID }\`
on UI writes when pairing with \`useDbSync({ ignoreSource: TAB_ID })\`; pass
\`{ keepalive: true }\` for short-lived writes such as selection cleanup during
unload.

\`\`\`ts
// app/root.tsx
import { TAB_ID } from "@/lib/tab-id";

useDbSync({
  queryClient,
  ignoreSource: TAB_ID,  // ignore events from this tab's own writes
});
\`\`\`

The UI sends its browser tab ID in \`X-Agent-Native-Browser-Tab\`; when a write
has a \`requestSource\`, the client sends it in \`X-Request-Source\` and the server
records it as the event origin. \`useDbSync\` ignores events whose origin matches
\`ignoreSource\`, preventing a tab from refetching after its own state writes.

## Gold-Standard Example: Mail Template

The mail template demonstrates these patterns working together:

**Navigation state shape:**
\`\`\`json
{ "view": "inbox", "threadId": "thread-123", "focusedEmailId": "msg-456", "label": "important" }
\`\`\`

**view-screen output:**
- Reads navigation state
- Reads \`__url__\` if URL query filters matter
- Fetches email list matching current view/filter state
- Fetches thread messages if a thread is open
- Returns everything as a single JSON snapshot

**navigate command:**
- \`{ "view": "starred" }\` — switch to starred view
- \`{ "view": "inbox", "threadId": "thread-123" }\` — open a specific thread
- For pure query-filter changes, use \`set-search-params\`

## Do

- Use the auto-injected \`<current-screen>\` block for basic context — call \`view-screen\` only when you need richer data
- Include semantic route state in the \`navigation\` key (view, item IDs, active tab, focused row)
- Keep shareable filters in URL query params so \`<current-url>\` and \`set-search-params\` work
- Add concise visible-record details to \`view-screen\` for views where the agent needs them beyond the injected navigation context
- Use \`useAgentRouteState\` or \`useSemanticNavigationState\` for UI-side navigation sync and command consumption
- Use the one-shot \`navigate\` command pattern for app navigation; include a same-origin \`path\` when the target URL is known
- Tag agent writes with \`requestSource: "agent"\` (the script helpers do this automatically)

## Don't

- Don't assume the user is on a specific page — use \`<current-screen>\` or read
  navigation state when context is missing or stale
- Don't hardcode navigation paths in scripts — read the current state and branch
- Don't write to the \`navigation\` key from the agent — it belongs to the UI. Use \`navigate\` instead.
- Don't write both \`navigate\` and \`__set_url__\` for one app navigation; competing consumers can make the browser URL change before React Router commits the page.
- Don't ignore the \`<current-screen>\` block — it tells you where the user is
- Don't duplicate whole URL query strings into \`navigation\` when \`<current-url>\` already exposes them
- Don't store fetched data in navigation state — it holds IDs and semantic UI state only. The \`view-screen\` script fetches the actual data.

## Related Skills

- **adding-a-feature** — Context awareness is area 4 of the four-area checklist
- **real-time-sync** — How \`useDbSync\` delivers app-state changes to the UI
- **actions** — How to create the \`view-screen\` and \`navigate\` actions
- **storing-data** — Application-state is one of the core SQL stores
`,dir:`.agents/skills/context-awareness`,extraFiles:[],files:{}},"customizing-agent-native":{meta:{name:`customizing-agent-native`,description:`How to configure, compose, or eject Agent-Native features into app-owned code. Use when overriding shared components or integrations, customizing a template, adding UI to chat or headless apps, or inspecting package source.`,scope:`dev`},content:`---
name: customizing-agent-native
description: >-
  How to configure, compose, or eject Agent-Native features into app-owned
  code. Use when overriding shared components or integrations, customizing a
  template, adding UI to chat or headless apps, or inspecting package source.
scope: dev
metadata:
  internal: true
---

# Customizing Agent-Native

## Rule

Start with the app's registered design system and local UI adapters, then use
the public feature's props, semantic components, controller, product slots,
and callbacks. If those seams are not enough, use the eject CLI to transfer
the smallest supported feature into the app and make that copy app-owned.
Never edit \`node_modules\`, deep-import a private source file at runtime, or
patch an \`@agent-native/*\` package.

Use this order:

1. Set brand tokens with the build-time theme configuration when tokens are
   enough.
2. Register company components in \`app/design-system.ts\` with
   \`defineDesignSystem\`, then pass that definition to \`ToolkitProvider\`.
3. Configure a public feature through its semantic components, headless
   controller, and product-level render slots.
4. Compose app primitives behind the app's local UI adapter layer.
5. Eject the smallest feature into app-owned source.
6. Propose a new Toolkit seam when the same override is useful in two apps.

Ejection is for intentional product customization, not for hiding an upgrade
failure or replacing Core runtime behavior.

## Use A Company Design System

Keep the explicit, typed registration seam in \`app/design-system.ts\`:

\`\`\`tsx
import { defineDesignSystem } from "@agent-native/toolkit/design-system";
import {
  AcmeActionButtonAdapter,
  AcmeDialogAdapter,
} from "./design-system/acme-adapter";

export const designSystem = defineDesignSystem({
  name: "Acme",
  components: {
    ActionButton: AcmeActionButtonAdapter,
    Dialog: AcmeDialogAdapter,
  },
});
\`\`\`

Adapters translate the semantic Toolkit contract into company component props.
They are ordinary React components and may use MUI-style providers, React Aria,
CSS modules, CSS-in-JS, or another styling runtime. \`className\` and \`style\` are
optional interoperability hooks, not Tailwind or CVA requirements.

The contract has nine leaf components (\`ActionButton\`, \`IconButton\`,
\`TextField\`, \`TextArea\`, \`Spinner\`, \`Skeleton\`, \`Status\`, \`Surface\`, \`Avatar\`)
and eight behavior components (\`Tooltip\`, \`Menu\`, \`Popover\`, \`Dialog\`,
\`Picker\`, \`Checkbox\`, \`Switch\`, \`Tabs\`). \`Picker\` covers select and combobox
behavior, not date picking. Behavior adapters own their portal, focus,
keyboard, dismissal, and stacking implementation while honoring the semantic
props and \`portalContainer\` interop contract.

App product code imports standard controls from its local adapter path, usually
\`@/components/ui/*\`. Do not import \`@agent-native/toolkit/ui/*\` directly from
pages, routes, or domain components. That bypasses the app seam and makes a
future design-system replacement incomplete. Toolkit feature packages remain
valid imports; configure their presentation through the registered semantic
components, controller, and product slots.

Run the published conformance kit against a complete adapter in its own CI:

\`\`\`tsx
import { assertDesignSystemConformance } from "@agent-native/toolkit/conformance";
import { DESIGN_SYSTEM_CONTRACT_VERSION } from "@agent-native/toolkit/design-system";

await assertDesignSystemConformance({
  adapterName: "Acme",
  components,
  contractVersion: DESIGN_SYSTEM_CONTRACT_VERSION,
});
\`\`\`

## Customize A Shared Feature

Prefer feature-level headless controllers over rebuilding individual widgets.
One controller must power both the Toolkit default view and every custom render
path so behavior, actions, analytics, accessibility state, and error handling
cannot drift. Use a product-level render slot to replace the view while keeping
that controller. Eject only when the controller and slots cannot express the
required product behavior.

## Eject A Feature

Discover and inspect the ejection units published by installed first-party
packages before changing source:

\`\`\`bash
agent-native eject --list
agent-native eject inspect <unit>
agent-native eject <unit> --app <app>
agent-native eject <unit> --app <app> --apply
\`\`\`

The command is dry-run by default. It prints the file closure, consumer import
rewrites, protected package contracts, and verification commands before
writing. \`--apply\` copies the package-version-matched source into the app and
rewrites only imports covered by the unit manifest.

If a framework feature has no ejection unit, follow its documented
configuration, adapter, or extension seam; do not invent a manual package-copy
recipe. For an unknown third-party package, use the emitted add-style blueprint
as a starting point. Protected runtime behavior is never copied.

Applied ejections are recorded in the committed
\`agent-native.ejections.json\`, including package version, manifest digest,
target hashes, and import rewrites. Use the recorded state to review drift or
undo an unchanged ejection:

\`\`\`bash
agent-native eject diff <unit> --app <app>
agent-native eject restore <unit> --app <app>
agent-native eject restore <unit> --app <app> --apply
\`\`\`

Restore is hash-gated. It refuses to remove locally edited files or reverse
changed imports and prints their diff instead. Keep an edited ejection as
app-owned code, or reconcile those edits before restoring it.

## Find The Installed Implementation

Use the source that matches the installed package version:

The template corpus is optional. If source-search reports it is unavailable,
follow \`agent-native-docs\` to install the matching package before using the
direct corpus path below.

\`\`\`bash
pnpm action docs-search --query "<component or feature>"
pnpm action source-search --query "<component or symbol>"
rg -n "<component or symbol>" node_modules/@agent-native/toolkit/src
rg -n "<component or symbol>" node_modules/@agent-native/core-corpus/corpus
\`\`\`

- Toolkit publishes readable TypeScript under
  \`node_modules/@agent-native/toolkit/src/\` for selective UI adoption.
- First-party template source lives under
  \`node_modules/@agent-native/core-corpus/corpus/templates/\`; Core's own implementation
  lives under \`node_modules/@agent-native/core/dist/\`.
- Treat those trees as read-only references. Prefer \`agent-native eject\` so the
  package manifest selects the complete source closure and rewrites imports.
  Manual inspection is still useful for deciding whether to configure,
  compose, eject, or propose a shared seam.

Do not manually guess at sibling dependencies. The ejection manifest owns the
required file closure and keeps protected contracts on public package imports.

## Preserve The Agent-Native Contract

UI ownership may change; product contracts should not:

- Keep app operations in \`defineAction\` actions and call them through
  \`useActionQuery\`, \`useActionMutation\`, or another named client helper.
- Keep navigation, selection, and focused-object state visible through the
  existing application-state keys.
- Keep AI work in the shared agent chat instead of adding direct LLM calls.
- Keep auth, access checks, persistence, chat transport, and agent execution in
  Core. Do not copy those runtimes into the app.
- Keep local adapters narrow so package upgrades still improve every surface
  the app has not intentionally taken ownership of.
- Keep page, route, and domain code on local UI adapter imports. Never reach
  around the registered design system with direct Toolkit UI primitive imports.

## App Shapes

- **Template app:** begin with \`app/design-system.ts\`, its local UI adapters,
  and domain UI. Use Toolkit features for repeated workspace behavior; eject
  only the unit being customized.
- **Chat app:** keep \`AgentChatSurface\`, thread state, and chat transport in
  Core. Compose or eject Toolkit presentation such as chat-history UI around it.
- **Headless app:** stay action-first while no UI is needed. When adding a UI,
  use the Chat template as the on-ramp or add Toolkit components without
  replacing the existing actions.
- **Workspace:** keep one-app overrides in that app. Promote a local component
  to a shared workspace package when multiple workspace apps use it.

## After Ejecting

- Commit \`agent-native.ejections.json\` with the app-owned files and rewrites.
- Remove unused dependencies and imports from the ejected files.
- Keep visible text in the app's localization catalogs.
- Run the manifest verification commands plus the app's formatter, typecheck,
  and focused tests.
- Re-check the installed source during future package upgrades; the app-owned
  ejection does not receive upstream fixes automatically. Use \`eject diff\` to
  distinguish recorded output from subsequent local edits.

## Don't

- Don't edit or import from \`node_modules/@agent-native/*/src\` at runtime.
- Don't add \`pnpm.overrides\`, patches, or resolutions for Agent-Native packages.
- Don't copy Core auth, DB, action, agent-loop, or transport internals.
- Don't manually copy a package feature when no supported ejection is published;
  use its documented configuration, adapter, or extension seam.
- Don't eject a full package when a prop, slot, wrapper, or smaller unit works.
- Don't fork feature state into a custom view; consume the feature's controller.

## Related Skills

- \`agent-native-docs\` — version-matched docs, source lookup, and package upgrades
- \`agent-native-toolkit\` — shared-vs-app-owned architecture boundary
- \`adding-a-feature\` — UI/action/instructions/application-state parity
`,dir:`.agents/skills/customizing-agent-native`,extraFiles:[],files:{}},"delegate-to-agent":{meta:{name:`delegate-to-agent`,description:`Route user-facing AI work through the app's agent chat. Use when adding an AI-powered button, workflow, research task, generation flow, or follow-up.`,scope:`dev`},content:`---
name: delegate-to-agent
description: >-
  Route user-facing AI work through the app's agent chat. Use when adding an
  AI-powered button, workflow, research task, generation flow, or follow-up.
scope: dev
---

# Delegate AI Work to Agent Chat

## Rule

Use the agent chat for work that needs AI reasoning, research, generation, or
multi-step decisions. Keep app actions deterministic; let the agent orchestrate
them so the user can see and steer the work.

## Start a visible agent turn

Call \`sendToAgentChat()\` from the UI and open the AgentSidebar for user-initiated
work:

\`\`\`ts
import { sendToAgentChat } from "@agent-native/core/client/agent-chat";

sendToAgentChat({
  message: userRequest,
  context: JSON.stringify({ documentId }),
  submit: true,
  openSidebar: true,
});
\`\`\`

Keep the user's request in \`message\`. Put only concise supporting context—such
as a selected record id, current view, or bounded excerpt—in \`context\`. Use
attachments or image fields for files and visuals; do not serialize full
records or credentials into a prompt. The agent should read private or large
data through the app's authorized actions.

Use \`submit: true\` when a clear user action already states the intent. Use
\`submit: false\` to open the composer with a prefill when the user should review
or complete the request. Do not auto-submit a generic generation prompt before
the user has supplied the request.

Reserve \`background: true\` with \`openSidebar: false\` for work the product
intentionally runs silently, such as a system-initiated task. A button that
asks the user to do AI work should open the sidebar.

## Keep the boundary clear

- Use focused actions for provider reads, validation, deterministic
  transformations, database writes, and other explicit operations.
- Let the agent choose and sequence those actions for AI-shaped workflows.
- Keep a user's freeform prompt in the AgentSidebar composer. Use controls for
  structured parameters; do not add a second prompt or follow-up textbox.
- Do not call model-provider SDKs, \`completeText()\`, or AI SDK generation
  functions from app UI, actions, or server helpers. Do not make an action a
  hidden second agent.

## Related skills

- \`actions\` — define deterministic operations shared by the UI and agent.
- \`context-awareness\` — provide navigation and selected-record context.
`,dir:`.agents/skills/delegate-to-agent`,extraFiles:[],files:{}},"frontend-design":{meta:{name:`frontend-design`,description:`Product-specific interface design for an Agent-Native app. Use when creating or changing any user-facing UI, including screenshot feedback, copy or density cleanup, settings, controls, or a visual redesign.`,scope:`both`},content:`---
name: frontend-design
description: >-
  Product-specific interface design for an Agent-Native app. Use when creating
  or changing any user-facing UI, including screenshot feedback, copy or
  density cleanup, settings, controls, or a visual redesign.
scope: both
---

# Frontend Design

Design around the user's task and the app's existing visual language. A
distinctive interface comes from a clear product point of view, not extra
decoration. Keep implementation accessible and responsive.

## Choose a direction

Before a substantial new surface or redesign, decide who is using it, what
they came to do, and what they should see or do next. Pick a visual direction
that fits the product's brand and domain. For routine changes, inspect and
follow the existing components, type, color tokens, and spacing.

If a screen has two unrelated primary jobs, split the workflows or states.
Do not solve an unclear structure by adding more cards, tabs, controls, or
explanatory copy.

## Keep the starting view focused

The first view should show where the user is, the current work or state, and
the input or decision needed now. Make one action clear. Defer rare, advanced,
diagnostic, destructive, and historical controls to a relevant menu or
disclosure.

Every visible element should orient the user, show useful content or state,
collect required input, or enable the next action. If it has no job, remove it
or disclose it. Density should come from useful data, not extra chrome.

Do not add a page title that repeats the selected navigation item, a subtitle
or eyebrow under a title, a count strip over visible content, an About section
in settings, or helper copy that repeats a label unless the user asks for it.
A card, panel, tab, or settings group gets a title or a description, not both.
Use tooltips or progressive disclosure for explanations that are not needed to
make the current decision. User-authored descriptions are content: render them
when present and render nothing when empty.

For sequential setup, show one decision at a time with clear progress and
sensible defaults. Use the smallest surface that fits the task: an inline row
or dialog for a small edit, a focused flow for multi-step work.

## Use the app's design system

This starter ships **no brand system** — the neutral, 0%-saturation tokens in
\`app/global.css\` are a placeholder, not a design to preserve. Every app must
look impressive on first load even when the build prompt gives no design
direction: commit to one deliberate visual world, set a product-fitting accent
family in the light and dark tokens, and establish a clear type hierarchy,
spacing rhythm, and one signature detail. Do not ship the gray placeholder and
do not average toward generic SaaS. If an app already has a real brand, preserve
it. Keep shared behavior and semantic token names consistent; palette, density,
composition, type contrast, and shape language are yours to define. Prefer
semantic color tokens over raw palette colors, and avoid generic gradients,
glass effects, decorative blobs, and hero sections without a product purpose.

Use the app's local UI adapter for standard controls. In an Agent-Native app,
check the configured design system and toolkit provider before changing how
shared controls look. Read \`shadcn-ui\` when implementing or composing a
standard control; keep product-specific layout and visual decisions here.

Use real or generated imagery when it helps the user understand the subject.
Do not add decorative assets solely to fill empty space.

## Coordinate the UI with the agent

Keep repeatable, direct manipulation in the domain UI and use the agent for
work that benefits from judgment, exploration, or conversation. If the app has
a contextual agent sidebar, reuse it for in-context help and keep the user on
the current work surface. Do not add a second freeform prompt box. A control
that promises agent help should hand off the relevant context; label local,
deterministic behavior plainly.

## Interaction Responsiveness

Show feedback as soon as the user acts, aiming for 100 ms. When work cannot
finish immediately, acknowledge it before a network round-trip and show a
focused pending state within 400 ms. Use optimistic updates when safe, then
confirm or roll back on failure. Keep long work visibly progressing and offer
a way to stop when the operation supports cancellation.

## Make interactions clear and accessible

Support keyboard use, visible focus, accessible names, readable contrast, and
clear validation and recovery. Dialog and menu controls should use the app's
existing accessible primitives rather than hand-built click-outside behavior.
Never use browser \`alert\`, \`confirm\`, or \`prompt\` dialogs.

Use motion to clarify a state change. Prefer short transitions on opacity or
transform, respect reduced-motion preferences, and avoid delaying content with
decorative entrances or long animations.

Fit the content to narrow screens as well as desktop. Text and controls should
not overflow their containers; fixed-format editors, boards, and toolbars
should keep stable dimensions.

## Review the result

Check that the main job and next action are obvious. Look at the default,
loading, empty, error, and success states that apply, and check a narrow
viewport. Remove anything that competes with the task without helping the user
act or understand state.
`,dir:`.agents/skills/frontend-design`,extraFiles:[`references/visual-direction.md`],files:{"references/visual-direction.md":`# Visual Direction Reference

Use this reference when a new app or workspace needs a visual point of view and
does not already have an established brand system. It adapts the useful parts
of Impeccable's workflow: understand the product, name the surface mode, deal
several coherent directions, commit to one, and audit the result for defaults
that became the design by accident.

## The direction contract

Before writing UI, capture these decisions in the app's \`DESIGN.md\`:

| Decision             | What to record                                                    |
| -------------------- | ----------------------------------------------------------------- |
| Product mode         | \`operate\`, \`read\`, \`persuade\`, or \`experience\`                    |
| Audience and cadence | Who uses it, how often, and under what conditions                 |
| Visual world         | A short name and the feeling it creates                           |
| Palette family       | The semantic accent family and neutral undertone                  |
| Type treatment       | Sans-first, editorial contrast, or display-led emphasis           |
| Composition          | Focused workbench, list/detail, document, canvas, or guided steps |
| Shape language       | Quiet corners, crisp geometry, or soft utility surfaces           |
| Anti-references      | Defaults this app must not drift toward                           |

\`DESIGN.md\` is a portable design contract, not a license to bypass the app's
tokens or component system. If the app already has a brand system, document it
and preserve it. If it does not, choose a direction before styling.

## Palette families

Use one family as an accent and keep the rest of the system semantic and quiet.
These are starting points, not a fixed theme library:

| Family           | Good fit                                    | Typical character                 |
| ---------------- | ------------------------------------------- | --------------------------------- |
| Ink / graphite   | Admin, security, sensitive review           | Serious, low-noise, high contrast |
| Cobalt / sky     | Planning, collaboration, scheduling         | Clear, trustworthy, alert         |
| Pine / teal      | Automation, systems, finance, data          | Calm, capable, grounded           |
| Indigo / violet  | Slides, creative tools, research            | Exploratory, focused, expressive  |
| Plum / berry     | Publishing, knowledge, editorial work       | Distinctive, thoughtful, human    |
| Coral / rose     | Communication, people, customer workflows   | Warm, direct, social              |
| Ochre / citron   | Lightweight planning or energetic utilities | Optimistic, sparing, directional  |
| Paper / charcoal | Long-form reading, exports, approvals       | Tactile, restrained, legible      |

Do not make warm beige plus terracotta the universal fallback. Do not rotate
through saturated colors mechanically. Choose the family that supports the
workflow, then verify contrast, dark mode, focus states, destructive states,
and the sidebar boundary.

## Variation without chaos

Vary at least two independent axes when sibling apps share a workspace:

- accent family or neutral undertone;
- information density and page composition;
- type contrast and display treatment;
- radius and border language;
- navigation emphasis and use of whitespace.

Keep shared behavior, semantic token names, accessibility, and AgentSidebar
placement consistent. The goal is a family of products, not five unrelated
themes and not five copies of the same starter.

For a batch of apps, keep a small direction ledger in the workspace
\`DESIGN.md\` or the handoff. Record each app's mode, direction, and palette
family, then choose a new family or a clearly different composition for the
next app unless an existing brand requires reuse. Never copy a sibling's
\`global.css\` palette block or treat the last app's accent as the generator
default.

## Review vocabulary

Make one named intervention at a time so the agent can reason about the
change:

- \`distill\` - remove copy, controls, cards, and chrome that do not serve the
  next decision;
- \`typeset\` - repair hierarchy, measure, line length, and emphasis;
- \`colorize\` - establish a restrained semantic palette and contrast states;
- \`layout\` - repair grouping, density, alignment, and responsive composition;
- \`polish\` - resolve the small visual inconsistencies after the structure is
  right;
- \`audit\` - check slop, accessibility, responsive behavior, and visual drift.

Do not average several directions into a generic compromise. Deal two or three
coherent options only when a new or explicitly redesigned surface has a real
visual decision to make; for routine operate work, select one fitting direction
and encode only the useful decision in tokens and \`DESIGN.md\`.

## Anti-slop audit

Before handoff, inspect the first viewport and ask:

- Did the app inherit the neighboring app's palette or hero layout without a
  product reason?
- Does the first viewport show one job and one next action, rather than a
  capability catalog?
- Are there equal-weight cards, status chips, helper paragraphs, or controls
  that should be removed or disclosed?
- Does the typography fit the product mode instead of decorating the shell?
- Is the AgentSidebar distinct but quiet, with the domain page still primary?
- Are focus, loading, empty, error, dark, and narrow-width states part of the
  same design direction?
`}},"inline-embeds":{meta:{name:`inline-embeds`,description:"How to render interactive previews of app screens inline in agent chat via sandboxed iframes. Covers the `embed` fence syntax, the `postNavigate` pop-out helper, and when to prefer an embed over prose / a static image.",scope:`both`},content:`---
name: inline-embeds
description: >-
  How to render interactive previews of app screens inline in agent chat via
  sandboxed iframes. Covers the \`embed\` fence syntax, the \`postNavigate\` pop-out
  helper, and when to prefer an embed over prose / a static image.
---

# Inline Embeds

The chat renderer lets you embed a sandboxed iframe pointing at any same-origin
route of this app, rendered inline with your reply. Use this when a live,
interactive preview communicates more than prose or a static screenshot — a
chart, an email thread, a slide, a form, a ticket.

## The \`embed\` fence

Emit a fenced code block with the language \`embed\`:

\`\`\`\`
\`\`\`embed
src: /email?id=msg_123
aspect: 4/3
title: Re: Q4 planning
\`\`\`
\`\`\`\`

Keys:

| Key      | Required | Notes                                                              |
| -------- | -------- | ------------------------------------------------------------------ |
| \`src\`    | yes      | Same-origin path beginning with \`/\`. Cross-origin URLs are blocked |
| \`aspect\` | no       | \`16/9\` (default), \`4/3\`, \`3/2\`, \`2/1\`, \`21/9\`, \`1/1\`               |
| \`title\`  | no       | Accessible label + hover tooltip                                   |
| \`height\` | no       | Fixed pixel height when aspect ratio doesn't fit                   |

The rendered iframe is sandboxed (\`allow-scripts allow-same-origin allow-forms
allow-popups\`) and \`referrerpolicy="same-origin"\`. The browser enforces that
the iframe can't navigate the parent window.

## When to reach for an embed

- A chart or visualization that benefits from tooltips / hover.
- A detail view the user might want to scan (email, ticket, event, slide).
- Anything where "here's a link to it" would force an extra click.

**Don't** embed when plain prose, a bulleted list, or a small table is enough.
**Don't** embed external sites — the renderer blocks cross-origin URLs.

## "Open in main window" button — \`postNavigate\`

Every embed route should include a small "Open" button so the user can pop the
view out of the chat and into the full app. Import the helper from
\`@agent-native/core/client\`:

\`\`\`tsx
import { postNavigate, isInAgentEmbed } from "@agent-native/core/client";

export function OpenButton({ path }: { path: string }) {
  if (!isInAgentEmbed()) return null;
  return (
    <button onClick={() => postNavigate(path)}>Open</button>
  );
}
\`\`\`

\`postNavigate\` sends a \`postMessage\` to the parent chat window. The chat
renderer validates the message is same-origin, same-iframe, and the path is
relative, then updates the parent URL via \`history.pushState\` so react-router
navigates without a page reload.

When the page is loaded directly (not in an iframe), \`postNavigate\` falls back
to a same-window navigation, so the button works both ways.

## Adding an embed route to a template

1. Create a chromeless route (e.g. \`app/routes/email.tsx\`) that renders the
   detail view without the app shell.
2. Mark the route path as bare in \`app/components/layout/Layout.tsx\` so the
   sidebar / header don't render inside the iframe.
3. Render the existing detail component with a transparent background so it
   blends into the chat theme.
4. Include an \`<OpenButton>\` that calls \`postNavigate("/path/to/detail")\`.
5. Document the embed URL in this template's \`AGENTS.md\` so the agent knows
   what's embeddable.

The framework-level fence renderer and security enforcement apply
automatically — no per-template wiring beyond the route and layout bypass.
`,dir:`.agents/skills/inline-embeds`,extraFiles:[],files:{}},"integration-webhooks":{meta:{name:`integration-webhooks`,description:`Cross-platform pattern for handling messaging integration webhooks (Slack, Telegram, WhatsApp, email, etc.) on serverless hosts. Use when adding a new integration adapter, debugging dropped messages, or wiring long-running agent work into a webhook handler.`,scope:`dev`},content:`---
name: integration-webhooks
description: >-
  Cross-platform pattern for handling messaging integration webhooks (Slack,
  Telegram, WhatsApp, email, etc.) on serverless hosts. Use when adding a new
  integration adapter, debugging dropped messages, or wiring long-running agent
  work into a webhook handler.
scope: dev
metadata:
  internal: true
---

# Integration Webhooks

## Rule

Integration webhooks (Slack, Telegram, WhatsApp, email, Google Docs, etc.) must
**enqueue work to SQL and return 200 immediately**, then process the work in a
**separate fresh function execution** kicked off by a self-fired HTTP POST. SQL
is always the source of truth. Long-lived hosts use an in-process retry loop as
a best-effort safety net; serverless deployments must use an external durable
sweep when recovery cannot depend on a process staying alive.

Do not run agent loops inside the webhook handler itself. Do not rely on
fire-and-forget \`Promise\`s after \`return\`ing from a serverless handler — they get
killed when the function freezes.

## Why

Messaging platforms expect a 200 response within a tight window — Slack will
retry after 3 seconds, and a retried event triggers duplicate agent runs. At the
same time, an agent loop replying to the message can take 30–60+ seconds because
it may make multiple LLM calls and tool calls.

Past attempts that don't work cross-host:

- **Fire-and-forget \`Promise.then(...)\` after returning** — Lambda/Vercel/CF
  freeze the execution context the moment the response goes out. The promise
  is silently killed, the user gets no reply, and there's no error in the
  logs.
- **A platform background function as the queue** — host-specific execution is
  useful as a delivery mechanism, but it cannot replace the SQL row or atomic
  claim shared by every host.
- **Cloudflare \`event.waitUntil()\`** — CF Workers only, not portable.
- **Vercel Fluid / \`after()\`** — Vercel-only, gated behind specific runtimes.
- **A long-lived in-process queue** — fine on a single Node box, but on
  serverless every cold start gets a fresh queue and any pending work is
  lost.

The only universal answer: **persist the work, then trigger a brand new
function execution to do it.** SQL is the queue, a self-webhook is the trigger,
and a recurring job is the safety net.

## The Flow

\`\`\`
┌──────────┐    1. POST /integrations/:platform/webhook
│ Platform │────────────────────────────────────────────►┌──────────────────┐
└──────────┘                                             │ Webhook handler  │
                                                         │ (function exec 1)│
                                                         └──────────────────┘
                                                                  │
                            2. INSERT INTO integration_pending_tasks
                                 (status='pending', payload=...)
                                                                  │
                            3. dispatch POST /integrations/process-task
                                 — portable self-fire by default
                                 — acknowledged background handoff when enabled
                                                                  │
                            4. return 200 to platform ◄───────────┘

                                                         ┌──────────────────┐
                          5. POST arrives at processor   │ Processor        │
                             (separate fresh function)   │ (function exec 2)│
                                                         └──────────────────┘
                                                                  │
                            6. claimPendingTask(id) → status='processing'
                            7. runAgentLoop(...) — full timeout budget here
                            8. adapter.sendResponse(...) back to platform
                            9. markTaskCompleted(id)


                          ┌──────────────────────────────────────────────┐
                          │  Recovery sweep (every 60s) — safety net    │
                          │  Re-fires processor for tasks stuck in       │
                          │  'pending' or 'processing' beyond timeout.   │
                          │  Caps retries at 3 then marks 'failed'.      │
                          └──────────────────────────────────────────────┘
\`\`\`

The webhook handler does as little as possible. The fresh function execution
that handles \`_process-task\` gets its own full timeout budget for the agent
loop.

## Key Files

| File                                                                    | Purpose                                                                |
| ----------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| \`packages/core/src/integrations/plugin.ts\`                              | Mounts \`/_agent-native/integrations/*\` routes                          |
| \`packages/core/src/integrations/webhook-handler.ts\`                     | Verifies signature, parses, enqueues task, fires processor             |
| \`packages/core/src/integrations/pending-tasks-store.ts\`                 | SQL queue: \`insertPendingTask\`, \`claimPendingTask\`, \`markTaskCompleted\`, \`markTaskFailed\` |
| \`packages/core/src/integrations/pending-tasks-retry-job.ts\`             | Recurring retry sweep (\`startPendingTasksRetryJob\`, \`retryStuckPendingTasks\`) |
| \`packages/core/src/integrations/integration-durable-dispatch.ts\`        | Default-off acknowledged dispatch, scoped rollout, and outcome recording |
| \`packages/core/src/integrations/types.ts\`                               | \`PlatformAdapter\`, \`IncomingMessage\`, \`OutgoingMessage\`                |
| \`packages/core/src/integrations/adapters/{slack,telegram,whatsapp,email,google-docs}.ts\` | One adapter per platform                                               |

## Routes

All under \`/_agent-native/integrations/\`:

| Method | Path                       | Purpose                                                       |
| ------ | -------------------------- | ------------------------------------------------------------- |
| POST   | \`/:platform/webhook\`       | Platform pings this. Verifies, enqueues, returns 200 quickly. |
| POST   | \`/process-task\`            | Processor target. Claims a task and runs the agent loop.      |
| POST   | \`/retry-stuck-tasks\`       | Signed, bounded recovery sweep for durable schedulers.        |
| GET    | \`/status\`                  | All integrations status (settings UI).                        |
| GET    | \`/:platform/status\`        | One platform's status.                                        |
| POST   | \`/:platform/enable\`        | Enable an integration.                                        |
| POST   | \`/:platform/disable\`       | Disable an integration.                                       |
| POST   | \`/:platform/setup\`         | Platform-specific setup (e.g. Telegram webhook registration). |

## SQL Schema

The pending-task queue lives in \`integration_pending_tasks\`:

\`\`\`sql
CREATE TABLE IF NOT EXISTS integration_pending_tasks (
  id                 TEXT    PRIMARY KEY,
  platform           TEXT    NOT NULL,
  external_thread_id TEXT    NOT NULL,
  payload            TEXT    NOT NULL,   -- JSON-serialized IncomingMessage
  owner_email        TEXT    NOT NULL,
  org_id             TEXT,
  status             TEXT    NOT NULL,   -- pending | processing | completed | failed
  attempts           INTEGER NOT NULL DEFAULT 0,
  dispatch_attempts  INTEGER NOT NULL DEFAULT 0,
  last_dispatch_at   INTEGER,
  last_dispatch_outcome TEXT,
  dispatch_scope     TEXT,             -- persisted channel scope for recovery
  error_message      TEXT,
  created_at         INTEGER NOT NULL,
  updated_at         INTEGER NOT NULL,
  completed_at       INTEGER
);
CREATE INDEX IF NOT EXISTS idx_pending_tasks_status_created
  ON integration_pending_tasks(status, created_at);
CREATE INDEX IF NOT EXISTS idx_pending_tasks_dispatch_scope
  ON integration_pending_tasks(platform, dispatch_scope);
\`\`\`

The store layer creates this lazily on first use via \`ensureTable()\` and uses
\`intType()\` from \`db/client.ts\` so it works on both SQLite and Postgres.

\`claimPendingTask\` is the critical concurrency primitive: it atomically flips
\`pending\` → \`processing\` and increments \`attempts\`, returning \`null\` if another
worker beat us to it. Both the initial dispatch and every recovery sweep
funnel through the same processor endpoint, and \`claimPendingTask\` is what
prevents the same task from being processed twice.

### Netlify durable recovery

The portable self-dispatch remains the default. To emit and use Netlify's
acknowledged background worker plus a one-minute scheduled recovery function,
set \`AGENT_INTEGRATION_DURABLE_DISPATCH=true\` at build and runtime. A production
rollout can be narrowed with the comma-separated
\`AGENT_INTEGRATION_DURABLE_DISPATCH_SCOPES\` allowlist. Supported values are
\`<platform>:*\`, \`<platform>:<external-thread-id>\`, and, for adapters that expose
one, \`<platform>:<channel-id>\` (for example \`slack:C123\`).
Channel-scoped handoffs persist that scope separately from the provider thread
identity so a later bounded recovery sweep applies the same allowlist decision.

Workspace deploys emit this pair only for the Dispatch control-plane app, which
owns workspace messaging integrations. Standalone templates emit their own
pair when the same flag is enabled.

The background handoff waits only for Netlify's enqueue acknowledgement, not
for the agent loop. A failed or non-2xx acknowledgement falls back to the
portable processor. The scheduled function calls the HMAC-authenticated,
bounded \`/retry-stuck-tasks\` route; its atomic compare-and-set update prevents
overlapping sweeps from dispatching the same stale row twice.
Rows acknowledged by the 15-minute background worker use a 16-minute stale
cutoff, while portable synchronous dispatches retain the shorter serverless
cutoff. Apply that lease predicate before \`LIMIT\` so healthy long runs cannot
hide recoverable work. The background processor writes its lease marker in the
same atomic update that claims the row; best-effort dispatch telemetry is not
trusted for replay safety.

## Adding a New Platform Adapter

1. **Implement \`PlatformAdapter\`** in \`packages/core/src/integrations/adapters/<platform>.ts\`:

   \`\`\`ts
   export function myPlatformAdapter(): PlatformAdapter {
     return {
       platform: "myplatform",
       label: "MyPlatform",
       getRequiredEnvKeys: () => [
         { name: "MYPLATFORM_TOKEN", label: "MyPlatform Bot Token", scope: "global" },
         { name: "MYPLATFORM_SIGNING_SECRET", label: "MyPlatform Signing Secret", scope: "global" },
       ],
       async handleVerification(event) {
         // Platform-specific challenge response, if any
         return { handled: false };
       },
       async verifyWebhook(event) {
         // Verify HMAC/signature with a server-side secret and constant-time comparison.
         // Never leave this as a permissive stub in production.
         return verifyMyPlatformSignature(event);
       },
       async parseIncomingMessage(event) {
         // Map raw payload → IncomingMessage, or null to ignore
         return null;
       },
       async sendResponse(message, context) {
         // POST back to the platform's API
       },
       formatAgentResponse(text) {
         return { text, platformContext: {} };
       },
       async getStatus(baseUrl) {
         return { platform: "myplatform", label: "MyPlatform", enabled: false, configured: false };
       },
     };
   }
   \`\`\`

2. **Register it** in \`getDefaultAdapters()\` inside \`plugin.ts\`. The webhook,
   queue, processor, and retry job are shared infrastructure — you do not
   write any of that per-adapter.

3. **Declare required env keys** so the secrets/onboarding UI surfaces them.
   See \`secrets\` and \`onboarding\` skills.

4. **Update the platform's webhook URL** to point at
   \`\${baseUrl}/_agent-native/integrations/<platform>/webhook\`. For platforms
   with a registration API (Telegram), implement \`POST /:platform/setup\`.

Never hardcode bot tokens, signing secrets, verification tokens, webhook URLs,
channel/customer identifiers, or copied platform payloads with real private data
inside the adapter, tests, docs, prompts, or fixtures. \`getRequiredEnvKeys()\`
declares credential names only. Values come from deployment configuration,
registered secrets, OAuth, or scoped credential stores, and tests should use
obvious fake placeholders.

The adapter is **only** responsible for:

- platform-specific verification (signatures, challenges)
- payload → \`IncomingMessage\` mapping
- agent text → platform format
- delivering the response back to the platform

It does **not** know about the queue, the processor, retries, or the agent
loop. Those are handled by the shared webhook handler.

### Slack non-message events

Slack's Events API also sends events that are not agent messages, such as
\`link_shared\` for app unfurls. Do not map those into \`IncomingMessage\` unless
they should actually run the agent. Handle them as short, provider-specific
webhook work: verify the Slack signature, return \`200 OK\` quickly, and call the
provider API needed for the event (\`chat.unfurl\` for link previews). If a single
Slack app must handle both agent chat and app unfurls, put a dispatcher in front
of the one Slack Events Request URL and route message events to the integration
webhook flow while routing \`link_shared\` to the app-specific unfurl handler.

## Long-Running Agent Work

The processor endpoint runs in a fresh function execution with its own full
timeout (typically 30–60s on Netlify/Vercel, longer on background-friendly
hosts). That budget is dedicated entirely to the agent loop — there is no
platform-side timer racing it.

If a single agent run might exceed the function timeout (large multi-step
plans, deep delegation chains), the agent should:

1. Send an interim acknowledgement back to the platform so the user knows the
   request landed (\`adapter.sendResponse({ text: "Working on it..." })\`).
2. Persist intermediate state in chat-thread data, application state, or a
   recurring job so the next invocation can pick up where this one left off.

The retry job will only re-fire tasks stuck in \`processing\` for over 5 minutes,
so a normal long-running reply is safe.

## Cross-Platform Considerations

- **Portable correctness, optional host acceleration.** Every host uses SQL,
  HMAC-authenticated processor routes, and atomic claims. A host-specific
  background function or scheduler may provide a more reliable wake-up, but
  disabling it must preserve the portable path.
- **No assumed runtime.** The processor endpoint is a normal H3 handler under
  \`/_agent-native/\`. It runs wherever the rest of the framework runs.
- **No persistent in-memory state.** The dedup map in the webhook handler is
  best-effort only; the SQL queue is the source of truth. Any cold start
  loses the dedup map but the queue stays consistent.
- **Postgres + SQLite both supported.** \`claimPendingTask\` uses \`RETURNING\` on
  Postgres and a re-read on SQLite. No platform-specific SQL.
- **Self-webhook URL resolution.** The processor URL is built from
  \`WEBHOOK_BASE_URL\`, \`APP_URL\`, or \`URL\` env vars (with \`localhost:3000\` as
  the dev fallback). Templates that change their public URL must keep one of
  these set.

## Why Fire-and-Forget on Serverless Is Unreliable

The portable webhook path gives the outbound processor request a short head
start but does not wait for the response body, so that initial dispatch is
**not** guaranteed to complete before the function freezes. On a long-lived
host, the in-process retry loop is a best-effort safety net. On Netlify with
durable dispatch enabled, the initial handoff is acknowledged and the external
scheduled function supplies the recovery wake-up for cases where:

- The serverless platform froze the handler before the outbound \`fetch\`
  flushed its bytes.
- The processor function 502'd or cold-started slow enough to time out.
- The processor itself was killed mid-agent-loop (function timeout, container
  shutdown, deploy mid-run).

Tasks stuck in \`pending\` for >90s or \`processing\` for >5min get re-fired up to
3 times. After 3 attempts they're marked \`failed\` permanently so we stop
spamming the processor.

**Never assume the initial dispatch succeeded.** Rely on the SQL queue, atomic
claim, and a recovery mechanism whose lifetime is independent of the original
request. An in-process timer alone is not that mechanism on serverless.

## Debugging Checklist

1. **Platform sent the webhook?** Check the platform's delivery logs (Slack
   admin, Telegram \`getWebhookInfo\`).
2. **Webhook handler returned 200?** If not, the platform retries — look for
   duplicate task rows. Signature failures return 401.
3. **Task in the queue?** \`SELECT * FROM integration_pending_tasks WHERE
   external_thread_id = '...' ORDER BY created_at DESC LIMIT 5\`.
4. **Status?** \`pending\` means the processor never picked it up — check that
   \`_process-task\` is reachable from the box itself (the self-fetch must work
   over the public URL). \`processing\` for over 5 minutes means the processor
   died mid-run — a live recovery sweep will pick it up.
5. **Failed?** Check \`error_message\` and \`attempts\`. After 3 attempts the row
   is parked at \`failed\` and won't be retried.
6. **Reply not delivered?** The processor likely succeeded but
   \`adapter.sendResponse\` failed — check the adapter's outbound logs.

## Automation connectors

Workflow systems such as n8n and Zapier are not messaging channels. Do not add
them as \`PlatformAdapter\`s or route them through \`provider-api\`.

For n8n-style workflow invocation and callbacks, use
\`@agent-native/core/automation\` with static workflow IDs and allow-listed
origins. Agents provide structured input, never a target URL or credential.
Callbacks must verify a configured secret/signature, claim a durable event ID,
enqueue work through the established queue, and acknowledge quickly.

Zapier is blueprint-only unless the app implements Zapier's explicit REST Hook
subscribe/unsubscribe contract or configures a separate Zapier MCP connection.
Do not imply a generic Zapier workflow-execution API exists.

## Related Skills

- \`server-plugins\` — How \`/_agent-native/\` routes get mounted
- \`recurring-jobs\` — Pattern the retry job follows
- \`actions\` — When to use an action vs a webhook
- \`secrets\` — Registering platform tokens
- \`onboarding\` — Surfacing setup steps for each platform
- \`delegate-to-agent\` — How the processor invokes the agent loop
`,dir:`.agents/skills/integration-webhooks`,extraFiles:[],files:{}},internationalization:{meta:{name:`internationalization`,description:`How to add localized UI copy when the user explicitly requests i18n. Do not load or apply this skill for ordinary English UI edits in this starter — it ships inline English strings with no catalogs.`,scope:`dev`},content:`---
name: internationalization
description: >-
  How to add localized UI copy when the user explicitly requests i18n.
  Do not load or apply this skill for ordinary English UI edits in this
  starter — it ships inline English strings with no catalogs.
scope: dev
metadata:
  internal: true
---

# Internationalization

## Rule

**Opt-in only.** Do not add i18n catalogs, \`LanguagePicker\`, locale init scripts,
or \`AppProviders i18n={{...}}\` unless the user explicitly asks for
internationalization / localization / multiple languages.

This starter ships **English-only inline copy**. For normal UI text edits,
change the string in the component and stop — do not create \`app/i18n/\`.

When the user does request i18n, then: visible UI copy belongs in the app's i18n
catalog, not inline in components. Update the English source catalog first,
update existing locale catalogs, and run the i18n guard.

## Catalogs

When enabling i18n, use \`app/i18n/\`:

- \`en-US.ts\` is the canonical source tree and fallback.
- Other locale files keep the same non-plural keys and the same placeholders.
- \`index.ts\` exports an \`AgentNativeI18nCatalog\` with English bundled and
  non-English catalogs loaded by dynamic import.

Use BCP-47 filenames from the supported set: \`en-US\`, \`zh-CN\`, \`zh-TW\`, \`es-ES\`,
\`fr-FR\`, \`de-DE\`, \`ja-JP\`, \`ko-KR\`, \`pt-BR\`, \`hi-IN\`, \`ar-SA\`.

## Verification

Run:

\`\`\`bash
pnpm guard:i18n-catalogs
\`\`\`

For broader changes, also run the affected tests and a single \`pnpm typecheck\`
at the end of the batch.
`,dir:`.agents/skills/internationalization`,extraFiles:[],files:{}},"multi-app-workspace":{meta:{name:`multi-app-workspace`,description:`How to build or extend a multi-app Agent-Native workspace — the monorepo shape, the Dispatch control plane, the shell app that fronts every other app, and the shared package. Use when the user asks for a workspace, a platform, a suite of apps, an app launcher or shell, a second app, Dispatch, a shared vault, or cross-app agents. This repo is a standalone app, so read this before restructuring it.`,scope:`dev`},content:`---
name: multi-app-workspace
description: >-
  How to build or extend a multi-app Agent-Native workspace — the monorepo
  shape, the Dispatch control plane, the shell app that fronts every other app,
  and the shared package. Use when the user asks for a workspace, a platform, a
  suite of apps, an app launcher or shell, a second app, Dispatch, a shared
  vault, or cross-app agents. This repo is a standalone app, so read this
  before restructuring it.
scope: dev
metadata:
  internal: true
---

# Multi-App Workspaces

## Rule

Scaffold a workspace with the CLI. Never hand-build the monorepo wiring, and
never hand-build Dispatch — it is a published template and runtime package, not
something to recreate from parts.

## This repo's starting point

\`package.json\` records \`agent-native.scaffold.shape: "standalone"\`, there is no
\`agent-native.workspaceCore\` field, and \`pnpm-workspace.yaml\` has no \`packages:\`
key. This is a single app, not a workspace root. \`add-app\` will not work here
until a workspace root exists.

Converting is mechanical, but **this folder must stay the root**. It is the git
root and the container expects it as the project root, so never scaffold a new
folder in the parent and move the repo into it. \`create .\` is also out — it
aborts unless the directory is empty apart from \`.git\` / \`README.md\` /
\`.gitignore\`.

Instead, scaffold into a staging subdirectory *inside* this repo, hoist its root
files up, and delete it. Nothing leaves the git root.

\`\`\`bash
# 1. Staging scaffold. The name becomes the shared package scope
#    (@app-workspace/shared), so use the real workspace name.
npx @agent-native/core@latest create app-workspace

# 2. Move this app's source under apps/<app-id>/, preserving history.
#    Include app-level AGENTS.md, CLAUDE.md, DESIGN.md, and .agents/skills.
mkdir -p apps/<app-id>
git mv <app files> apps/<app-id>/

# 3. Hoist the scaffold's root files, then drop the staging dir.
mv app-workspace/package.json app-workspace/pnpm-workspace.yaml \\
   app-workspace/agent-native.config.ts app-workspace/agent-native.json \\
   app-workspace/tsconfig.base.json app-workspace/AGENTS.md \\
   app-workspace/DESIGN.md app-workspace/scripts app-workspace/packages .
mv app-workspace/apps/dispatch apps/dispatch
rm -rf app-workspace
\`\`\`

That gives the root \`package.json\` with \`workspaceCore\`, \`pnpm-workspace.yaml\`
with its dependency catalog, \`packages/shared/\`, the workspace \`AGENTS.md\` and
\`DESIGN.md\`, and \`apps/dispatch\`. Point the root \`.agents/skills\` at the shared
package (\`ln -s ../packages/shared/.agents/skills .agents/skills\`) and keep
\`.claude/skills\` pointing at \`.agents/skills\`.

Leave container- and CI-required files (\`netlify.toml\`, workflow configs,
\`.env\`) at the git root. Move framework skills into
\`packages/shared/.agents/skills/\` so every app inherits them; only genuinely
app-specific skills go under \`apps/<app-id>/.agents/skills/\`.

Step 2 skips the **workspacify** transform that \`create\` and \`add-app\` run on a
template, so apply it by hand to the moved app. It is a short, closed list:

- add \`"@app-workspace/shared": "workspace:*"\` to \`dependencies\`
- add \`postgres\` (core lazy-loads it when \`DATABASE_URL\` is Postgres)
- resolve any \`workspace:*\` refs for \`@agent-native/core|toolkit|dispatch\` to
  real version ranges
- delete \`pnpm.onlyBuiltDependencies\` — build approvals belong at the root
- delete \`learnings.defaults.md\` (standalone-only)
- replace copied framework skills under \`.agents/skills/\` with symlinks to the
  root \`.agents/skills\`; keep app-specific skills local
- rewrite \`AGENTS.md\` action commands to \`cd apps/<app-id> && pnpm action\`
- in \`netlify.toml\`, set the build to
  \`APP_BASE_PATH=/<app-id> VITE_APP_BASE_PATH=/<app-id> NITRO_PRESET=netlify pnpm --filter <app-id> build\`
  and point \`functions\` at \`apps/<app-id>/.netlify/functions-internal\`

App source itself is left untouched — the three-layer model auto-discovers the
shared package from the root \`workspaceCore\` field. Then consolidate \`.env\` to
the workspace root so every app shares \`BETTER_AUTH_SECRET\`, \`DATABASE_URL\`,
and \`A2A_SECRET\`, and run \`pnpm install\` at the root.

If porting screens into a freshly scaffolded app is easier than moving this one,
do that instead — it skips the transform entirely.

## Scaffold

Workspace is the **default** shape of \`create\`; \`--standalone\` is the opt-out.
**Dispatch is always scaffolded** — the template picker hides it and the CLI
unions it in, so \`--template\` only names the *additional* apps:

\`\`\`bash
npx @agent-native/core@latest create app-workspace --template tasks,content
\`\`\`

Inside an existing workspace root, \`create <name>\` delegates to \`add-app\`:

\`\`\`bash
npx @agent-native/core@latest add-app crm --template content
pnpm install    # at the workspace root
pnpm dev
\`\`\`

Both run **workspacify** on the template. There is no separate "workspace-app"
scaffold to maintain.

## Anatomy

\`\`\`
package.json            "agent-native": { "workspaceCore": "@app-workspace/shared" }
pnpm-workspace.yaml     packages: ["packages/*", "apps/*"]
agent-native.config.ts  defineAgentNativeConfig({ translations, changelog, ... })
.env                    shared ANTHROPIC_API_KEY, BETTER_AUTH_SECRET, DATABASE_URL, A2A_SECRET
packages/shared/        the private @app-workspace/shared package
DESIGN.md               workspace brand contract + sibling direction ledger
apps/dispatch/          control plane + shell (see below)
apps/<domain-app>/      one directory per app
\`\`\`

App discovery is by directory: the **app id is the directory name** under
\`apps/\`, and the display name comes from that app's \`package.json\`
\`displayName\`. Nothing registers apps in a central list.

Per-app gateway config lives under \`agent-native\` in the app's \`package.json\`:
\`workspaceApp.audience\` (\`"internal"\` default, or \`"public"\`),
\`workspaceApp.publicPaths\`, \`workspaceApp.protectedPaths\`.

## The shell / default app

\`agent-native dev\` at the workspace root starts the gateway, not an app. The
gateway mounts each app at \`/<appId>\` on one origin and lazily boots an app on
first visit (\`--eager\` starts all, \`--prewarm\` warms in background).

Default app resolution, in order:

1. \`WORKSPACE_DEFAULT_APP\` env var, if it names a real app
2. an app with id \`dispatch\`
3. otherwise \`apps[0]\` — and \`/\` does **not** redirect

So the container experience is: name the shell app \`dispatch\`, and \`/\` redirects
to it automatically. That is the whole mechanism — no manifest, no registry
file.

Because every app shares one origin and the session cookie is scoped to \`/\`, a
mounted pane inherits the ambient session. Only trusted, workspace-owner
authored apps belong there. Read \`security\` before making any app publicly
reachable or installable from outside the workspace.

## Dispatch

Dispatch is the workspace control plane: secrets vault, workspace connections,
messaging inbox (Slack / email / Telegram / WhatsApp), cross-app A2A delegation,
MCP gateway, approvals, agent profiles, shared resources, and the Apps rail that
fronts the other apps.

Two things share the name:

- the **\`dispatch\` template** — scaffold it as \`apps/dispatch\`
- **\`@agent-native/dispatch\`** — the published runtime package holding its
  server logic, routes, and components

Do not reimplement any of it. In a real workspace, the Dispatch app's route
files are one-line re-exports:

\`\`\`tsx
// apps/dispatch/app/routes/$appId.tsx
export {
  clientLoader,
  default,
  loader,
  meta,
} from "@agent-native/dispatch/routes/pages/$appId";
\`\`\`

\`app/routes.ts\` stays on \`flatRoutes()\` — React Router resolves route \`file\`
paths relative to the consumer's \`app/\`, so package-internal paths cannot be
splatted in directly. The one-line shell file per route is the supported
pattern.

To add a workspace-owned tab: write a normal local route file under
\`app/routes/\`, then register the tab in \`app/dispatch-extensions.tsx\`. The shell
chrome comes from \`Layout\` in \`@agent-native/dispatch/components\`.

If the user wants Dispatch-like behavior without Dispatch, say so plainly and
scope it — a single app cannot get the vault, inbox, and cross-app routing for
free.

### Dispatch must carry the product's brand

A scaffolded Dispatch ships the neutral 0%-saturation starter palette, so out of
the box it reads as "a default Agent-Native app" rather than as the product's
front door. That is not acceptable for the shell — it is the first screen every
user sees and the frame around every other app.

Dispatch's theming is app-owned even though its routes come from the package:

- \`apps/dispatch/app/global.css\` — the token block. Replace the placeholder
  \`:root\` / dark values with the workspace brand for **both** modes.
- \`apps/dispatch/app/design-system.ts\` — \`defineDesignSystem({ name, theme,
  components })\` to override component adapters.
- \`apps/dispatch/app/dispatch-extensions.tsx\` — workspace-owned tabs.
- \`Layout\` from \`@agent-native/dispatch/components\` consumes semantic tokens, so
  retheming the tokens retheme the chrome. Do not fork the Layout to restyle it.

Treat the shell like a designed surface: read \`frontend-design\` and apply the
workspace brand to the Overview, Apps rail, and empty states before calling the
workspace done.

## Shared design system and brand

**This does not happen automatically — assume it is broken until you wire it.**
Every scaffolded app gets its own copy of \`app/global.css\` with the same
placeholder tokens, and the shared package ships no CSS export. Left alone, apps
drift and the workspace looks like unrelated demos.

The framework's default stance is deliberately anti-uniform: the scaffolded
\`DESIGN.md\` tells each app to pick its own accent and warns against copying a
sibling's palette. It carves out one exception — *"unless the workspace has an
explicit brand system"*. When the user wants one shared look, take that
exception explicitly and record it, rather than silently copying token blocks
between apps.

Wire it once:

1. Put the tokens in the shared package, e.g.
   \`packages/shared/src/client/brand.css\`, and add an export entry to its
   \`package.json\`: \`"./brand.css": "./src/client/brand.css"\`.
2. In every app's \`app/global.css\`, delete the copied \`:root\` token block and
   import the shared one after the framework styles:

   \`\`\`css
   @import "tailwindcss";
   @import "@agent-native/core/styles/agent-native.css";
   @import "@agent-native/toolkit/styles.css";
   @import "@app-workspace/shared/brand.css";

   @source "./**/*.{ts,tsx}";
   @source "../../../packages/shared/src/**/*.{ts,tsx}";
   \`\`\`

   The second \`@source\` is required or Tailwind will not scan shared components
   and their classes get purged.

3. Share component-level decisions through \`defineDesignSystem\` exported from
   \`packages/shared/src/client\`, with each app's \`app/design-system.ts\`
   re-exporting it and layering only genuine app-local overrides.
4. Record the brand in the root \`DESIGN.md\` — its "Shared product context" and
   "Sibling direction ledger" are the workspace's source of truth. Each app's
   own \`DESIGN.md\` then records only what it varies.

Apps may still differentiate with an accent or composition, but they inherit the
shared base rather than re-deriving a direction. When adding an app to a
workspace that already has a brand, apply steps 2–4 as part of scaffolding it —
not as a later cleanup pass.

## Three layers, merged by file name

1. **App local** — \`apps/<name>/\` wins
2. **Workspace shared** — \`packages/shared/\`
3. **Framework default** — \`@agent-native/core\`

Applies to plugins, skills, actions, and \`AGENTS.md\`. Create the file and it
takes over; there is no wiring step.

| Override           | File in the app                                    |
| ------------------ | -------------------------------------------------- |
| Auth plugin        | \`apps/<name>/server/plugins/auth.ts\`               |
| Agent-chat plugin  | \`apps/<name>/server/plugins/agent-chat.ts\`         |
| One skill          | \`apps/<name>/.agents/skills/<skill>/SKILL.md\`      |
| One action         | \`apps/<name>/actions/<action>.ts\`                  |
| Extra instructions | \`apps/<name>/AGENTS.md\` (merges with workspace one) |

## packages/shared

Only for what genuinely spans apps: an auth/SSO override and agent-chat override
exported from \`src/server/index.ts\`, shared React exports from
\`src/client/index.ts\`, workspace \`AGENTS.md\`, skills under \`.agents/skills/\`,
shared \`actions/\`, and provider connector helpers. Apps depend on it as
\`"@app-workspace/shared": "workspace:*"\`.

Promote a component here only when more than one app uses it. Everything else
stays app-local — framework defaults already cover the common case.

## Don't

- Don't create a second app registry, launcher, or wrapper app. The gateway plus
  Dispatch's Apps rail is the registry.
- Don't build a new dashboard that re-implements mail, calendar, or analytics.
  Reach existing apps as A2A peers or link to them.
- Don't copy a credential into each app's \`.env\`. One vault, grants and
  credential refs out — read \`secrets\` and \`workspace-connections\`.
- Don't copy shared skill files into an app. Link or override them.
- Don't add i18n or changelog to a new app unless asked; keep apps English-only
  by default.
- Don't ship Dispatch on the placeholder palette. The shell is the product's
  front door.
- Don't duplicate token blocks between apps to make them match. Put them in the
  shared package and import.
- Don't relocate this repo to make it a workspace. The current folder is the git
  root and the container root; scaffold into a staging subdirectory and hoist.

## Verify

\`\`\`bash
pnpm install                # workspace root
pnpm dev                    # gateway; / should land on the default app
pnpm -r typecheck
pnpm agent-native:doctor    # per app
\`\`\`

Then open the shell and at least one domain app in a browser. Confirm the brand
is visibly applied in both light and dark mode, not just that the build passes.

Confirm the gateway lists every app, that \`/\` redirects to the shell, and that
logging into one app carries into another before calling it done.

## Deeper reading

Version-matched docs ship in the package. From an app directory:

\`\`\`bash
pnpm action docs-search --slug multi-app-workspace
pnpm action docs-search --slug dispatch
pnpm action docs-search --slug workspace-deployment
pnpm action docs-search --slug workspace-connections
pnpm action docs-search --slug workspace-management
\`\`\`

Template source for every first-party app, including Dispatch, is readable at
\`node_modules/@agent-native/core/corpus/templates/\`.
`,dir:`.agents/skills/multi-app-workspace`,extraFiles:[],files:{}},notifications:{meta:{name:`notifications`,description:`In-app notifications primitive with pluggable server-side channels. Use when the agent needs to surface progress, alerts, or completions to the user — both in-app (bell + toast) and out-of-band (webhook, Slack, custom).`,scope:`both`},content:`---
name: notifications
description: >-
  In-app notifications primitive with pluggable server-side channels. Use when
  the agent needs to surface progress, alerts, or completions to the user —
  both in-app (bell + toast) and out-of-band (webhook, Slack, custom).
---

# Notifications

\`notify()\` is the framework's "tell the user something" primitive. Every call persists a row to the inbox (drives the bell UI) and fans out to any registered server-side channels. Channels follow the same pluggable-provider pattern as \`tracking\` — register at startup, \`notify()\` fans out, errors are isolated.

Use for: *agent progress milestones, automation triggers firing, background job completions, critical errors*. Don't use for chat replies — those go through the conversation.

## Tools

| Tool | Purpose |
|---|---|
| \`notify\` | Send a notification (severity + title + optional body/metadata/channels) |
| \`list-notifications\` | Show recent notifications for the current user |

## Sending

\`\`\`
notify --severity info --title "Booking confirmed" --body "Jane at 3pm"
\`\`\`

| Severity | When |
|---|---|
| \`info\` | FYI / progress / confirmation |
| \`warning\` | Something to look at soon |
| \`critical\` | Needs immediate attention |

Optional: \`--metadataJson '{"threadId":"abc"}'\`, \`--channels inbox,webhook\` (omit to run all registered).

## Delivery

\`notify()\` always inserts into the \`notifications\` table (unless \`channels\` explicitly excludes \`inbox\`), then fans out to every registered channel in parallel (best-effort; a failing channel doesn't block others). Finally it emits \`notification.sent\` on the event bus so automations can chain — e.g. *"when a critical notification fires, also page on-call."*

## Built-in Channels

| Channel | How | Requires |
|---|---|---|
| \`inbox\` | INSERT → drives bell UI | (always on) |
| \`webhook\` | POST JSON to \`NOTIFICATIONS_WEBHOOK_URL\` (+ optional \`NOTIFICATIONS_WEBHOOK_AUTH\`); both support \`\${keys.NAME}\` + URL allowlists from the ad-hoc-keys system | env var set |

The webhook channel resolves \`\${keys.NAME}\` server-side — the raw value never enters the agent context.

## Registering a Custom Channel

\`\`\`ts
// server/plugins/notifications-slack.ts
import { registerNotificationChannel } from "@agent-native/core/notifications";

export default () => {
  registerNotificationChannel({
    name: "slack-ops",
    async deliver(input, meta) {
      await fetch(process.env.OPS_SLACK_WEBHOOK!, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: \`*\${input.severity}* — \${input.title}\`, owner: meta.owner }),
      });
    },
  });
};
\`\`\`

Names are unique — re-registering replaces. \`deliver()\` must be best-effort; a thrown error is logged and ignored. Do NOT call \`notify()\` from inside a channel (recursion).

## HTTP API

Mounted at \`/_agent-native/notifications/*\` by \`core-routes-plugin\`, all session-scoped:

- \`GET    /notifications?unread=true&limit=50&before=<iso>\`
- \`GET    /notifications/count\`
- \`POST   /notifications/:id/read\`
- \`POST   /notifications/read-all\`
- \`DELETE /notifications/:id\`

## UI

\`\`\`tsx
import { NotificationsBell } from "@agent-native/core/client/notifications";

<NotificationsBell browserNotifications />
\`\`\`

Bell icon + unread badge + lazy-loaded dropdown. Pass \`browserNotifications\` to also fire system \`new Notification(...)\` popups for items that arrive after mount (dedups by id, renders an "Enable" prompt until permission is granted, silently no-ops on denied / unsupported). Styled with shadcn tokens — adapts to the host theme.

## Related

- \`automations\` — event-triggered bodies can call \`notify\`.
- \`secrets\` — \`\${keys.NAME}\` substitution + URL allowlists powering the webhook channel.
- \`tracking\` — analytics; separate concern, don't route through notifications.
`,dir:`.agents/skills/notifications`,extraFiles:[],files:{}},onboarding:{meta:{name:`onboarding`,description:`How to register user-facing setup steps (API keys, OAuth, connecting third-party services) for the sidebar setup checklist. Use when adding a feature that needs initial user configuration.`,scope:`dev`},content:`---
name: onboarding
description: >-
  How to register user-facing setup steps (API keys, OAuth, connecting
  third-party services) for the sidebar setup checklist. Use when adding a
  feature that needs initial user configuration.
scope: dev
metadata:
  internal: true
---

# Onboarding Steps

## Rule

If a feature requires user-facing setup (API keys, OAuth, connecting a third-party service), register an onboarding step so it appears in the agent sidebar's setup checklist.

Onboarding must point users to a secure credential path; it must never encode
the credential value in source, docs, fixtures, prompts, or generated content.
For API keys and service tokens, prefer \`registerRequiredSecret()\` from the
\`secrets\` skill so the settings UI, encrypted storage, validation, and
onboarding checklist stay in one place. For OAuth, check the scoped OAuth token
store. Use deployment env vars only for deploy-level configuration, not
per-user credentials.

## Registering a Step

\`\`\`ts
import { registerOnboardingStep } from "@agent-native/core/onboarding";
import { hasOAuthTokens } from "@agent-native/core/oauth-tokens";

registerOnboardingStep({
  id: "gmail",
  order: 100,
  title: "Connect Gmail",
  description: "Grant read/send access.",
  methods: [
    {
      id: "oauth",
      kind: "link",
      primary: true,
      label: "Sign in with Google",
      payload: { url: "/_agent-native/google/auth-url" },
    },
  ],
  isComplete: async (ctx) =>
    ctx?.userEmail ? hasOAuthTokens("google", ctx.userEmail) : false,
});
\`\`\`

See \`packages/core/docs/content/onboarding.md\` for method kinds and built-in steps.

## Related Skills

- \`adding-a-feature\` — The four-area checklist; onboarding is often part of a new integration
- \`authentication\` — Most onboarding steps involve OAuth or credentials
`,dir:`.agents/skills/onboarding`,extraFiles:[],files:{}},performance:{meta:{name:`performance`,description:`Keep app loads and interactions responsive as data grows. Use when a page feels slow, jumps, or lags, or when changing a data read, list, polling path, startup path, or performance-sensitive UI.`,scope:`dev`},content:`---
name: performance
description: >-
  Keep app loads and interactions responsive as data grows. Use when a page
  feels slow, jumps, or lags, or when changing a data read, list, polling path,
  startup path, or performance-sensitive UI.
scope: dev
---

# Performance

Find the cost that users actually wait on, then reduce it without weakening
the result. A slow screen may be waiting on the server, moving too much data,
serial reads, repeated computation, or browser rendering; measure before adding
caches or extra complexity.

## Load only what the current view needs

- Shape list reads around the fields the list displays. Keep large document
  bodies, histories, rendered output, and other rarely viewed data on a detail
  or on-demand path. Return a small preview when the list needs one.
- Paginate or window unbounded histories and activity feeds. Start with the
  recent or visible range and load more as the user asks for it.
- Batch related reads instead of issuing one query per row. Compute counts and
  other aggregates in the database when the result can be much smaller than
  the source rows.
- Start independent reads together. Do not make the first useful content wait
  for unrelated settings, below-the-fold panels, or secondary details.
- Index fields used by frequent filters, joins, and sorts when the data and
  observed query cost justify it. Keep indexes aligned with real query shapes.

For action-backed screens, shape the action response for the screen's current
need and keep the UI on the app's existing action and query hooks. Do not add a
second fetch path that duplicates the same read.

## Keep repeated work cheap

- Keep list and frequently refreshed reads inexpensive. Avoid parsing,
  reformatting, or rebuilding large values on every read when the result can be
  prepared once or computed only for the view that needs it.
- Use the app's existing live-update path when fresh data must reach an open
  screen. Poll only when needed, and keep polled reads bounded and cheap.
- Keep large file contents and long records out of list responses. Load them
  when the user opens the relevant item rather than sending them on every list
  refresh.
- Defer nonessential data and expensive child views until after the main
  content is usable. Window a rendered list when rendering all rows makes
  scrolling or updates slow.

## Protect startup and the first paint

- Keep migrations, backfills, data scans, aggregations, provider handshakes,
  and cache warming out of module evaluation and application startup. Hosted
  serverless instances can restart, so startup work can repeat on user
  requests. Use the app's deliberate migration, job, or on-demand path.
- Keep optional heavy runtimes out of modules loaded by ordinary page requests.
  Load a browser, media processor, or other large dependency only in the
  feature or job that needs it, and inspect the deployed bundle when adding
  one.
- Keep the server-rendered shell public and independent of a visitor's session.
  Resolve user-specific state after the shell loads through the app's
  authenticated client data path. Reads that must reflect a recent mutation
  should not depend on cached server-rendered loader data.
- Give loading placeholders the final content's basic geometry. Reserve space
  for content whose size is known; avoid showing a temporary layout that shifts
  the user's reading position when data arrives.

## Keep interactions responsive

Show that an interaction registered as soon as it happens, aiming for 100 ms.
If the work needs the network or takes longer, acknowledge it before waiting
and show a focused pending state within 400 ms. Use an optimistic update when
it is safe, then confirm or roll back on failure.

When investigating a slow experience, separate server response time, data
transfer, serial waits, rendering, layout movement, and long interaction work.
Use representative data and the production build when development tooling
changes the cost. Verify that the user-visible action completed before
comparing timings or memory.
`,dir:`.agents/skills/performance`,extraFiles:[],files:{}},progress:{meta:{name:`progress`,description:`Report live progress from long-running agent tasks. Use when a task takes more than a few seconds, so the user can watch status in the runs tray instead of staring at a spinner.`,scope:`both`},content:`---
name: progress
description: >-
  Report live progress from long-running agent tasks. Use when a task takes
  more than a few seconds, so the user can watch status in the runs tray
  instead of staring at a spinner.
---

# Progress

## Overview

\`progress_runs\` is the framework's "what is the agent doing right now" primitive. The agent starts a run at the top of a long task, updates it as work proceeds, and completes it with a terminal status. The UI renders active runs in a header-bar widget with a percent bar, current step, and spinner/check/X — live visibility into work that would otherwise be opaque.

Separate concern from \`notifications\`:

| | Notifications | Progress |
|---|---|---|
| Shape | One-shot event — "X happened" | Continuous state — "X is 45% done" |
| UI surface | Bell + toast | Runs tray with percent bar |
| Lifecycle | Dismissable (read/unread) | Running → terminal (succeeded/failed/cancelled) |

Common pattern: on completion, emit a \`notify()\` so the user sees the outcome when they're not actively watching the tray.

## Tool

All progress operations go through a single \`manage-progress\` tool with an \`action\` parameter:

| Action | Purpose |
|---|---|
| \`start\` | Mark the start of a long task. Returns a runId. |
| \`update\` | Update percent and/or current step. Call frequently. |
| \`complete\` | Mark terminal status: \`succeeded\`, \`failed\`, \`cancelled\`. |
| \`list\` | List recent runs (all or \`--active=true\`). |

## Canonical Flow

\`\`\`
manage-progress --action=start --title "Triage 128 unread emails" --step "Fetching inbox"
  → runId=abc

manage-progress --action=update --runId=abc --percent=25 --step="Classifying 32/128"
manage-progress --action=update --runId=abc --percent=75 --step="Drafting replies 97/128"

manage-progress --action=complete --runId=abc --status=succeeded
notify --severity=info --title="Triage done" --body="12 archived, 6 drafts ready to review"
\`\`\`

## Best Practices

- **Start a run for anything > ~5 seconds.** Users want feedback; a spinner with no context feels frozen.
- **Update at natural checkpoints**, not every iteration. Every 5–10% is enough for most UIs.
- **Always call \`manage-progress --action=complete\`** at the end — including the error path. An orphaned \`running\` row is worse than no row.
- **Pair with \`notify\`** on completion. The tray tells users what's *running*; notifications tell them what *finished*.
- **Use \`metadataJson\`** on \`manage-progress --action=start\` to pass a link back to the produced artifact (thread id, document path), so the UI can deep-link from the runs tray.

## Runs API

Mounted at \`/_agent-native/runs/*\` by \`core-routes-plugin\`. **Read-only** over HTTP — writes flow through the agent tools:

| Method | Route |
|---|---|
| \`GET\`    | \`/_agent-native/runs?active=true&limit=50\` |
| \`GET\`    | \`/_agent-native/runs/:id\` |
| \`DELETE\` | \`/_agent-native/runs/:id\` |

## UI Surface

Ships as \`<RunsTray />\` at \`@agent-native/core/client/progress\`:

\`\`\`tsx
import { RunsTray } from "@agent-native/core/client/progress";

export function HeaderBar() {
  return (
    <header className="flex items-center gap-2">
      {/* … */}
      <RunsTray />
    </header>
  );
}
\`\`\`

Inline header widget — mount next to the notifications bell. Shows a spinner icon + count badge when runs are active; click opens a dropdown with a live percent bar per run. Hides the trigger entirely when no active runs. Polls \`active=true\` every \`pollMs\` (default 3s).

## Event Bus Integration

Two events emit on the bus so automations can react:

- \`run.progress.started\` — \`{ runId, title, step? }\`
- \`run.progress.updated\` — \`{ runId, percent, step, status }\`

Example automation: *"when a run takes longer than 5 minutes, notify me."*

## Related Skills

- \`notifications\` — fire one when a run finishes so the user sees the outcome.
- \`automations\` — subscribe to \`run.progress.updated\` to build watchdogs on slow runs.
- \`delegate-to-agent\` — if you're delegating a long task, start a run on the delegator side so the caller has visibility.
`,dir:`.agents/skills/progress`,extraFiles:[],files:{}},"real-time-collab":{meta:{name:`real-time-collab`,description:`Multi-user collaborative editing with Yjs CRDT, SSE fast-path transport, and granular server-side merge. Use when adding real-time collaborative editing to a template, debugging sync issues, or understanding how the agent and humans edit documents simultaneously.`,scope:`dev`},content:`---
name: real-time-collab
description: >-
  Multi-user collaborative editing with Yjs CRDT, SSE fast-path transport, and
  granular server-side merge. Use when adding real-time collaborative editing to
  a template, debugging sync issues, or understanding how the agent and humans
  edit documents simultaneously.
scope: dev
metadata:
  internal: true
---

# Real-Time Collaboration

## Rule

Collaborative editing uses Yjs CRDT via TipTap. The agent and human users are
equal participants — both edit the same Y.Doc and changes merge cleanly without
conflicts. Always choose an explicit \`access\` mode on \`createCollabPlugin\`.

## How It Works

- **\`Y.Doc\`** stores the document as a \`Y.XmlFragment\` (ProseMirror node tree)
- **TipTap's Collaboration extension** binds the editor to the Y.XmlFragment
  via \`ySyncPlugin\`
- **CollaborationCaret extension** renders remote users' cursors with names and
  colors
- **SSE fast-path** — \`/_agent-native/poll-events\` \`EventSource\` delivers collab
  events push-style; while SSE is healthy the collab poll interval relaxes to
  ~12 s
- **Polling fallback** — \`/_agent-native/poll\` is polled every 2 s when SSE is
  unavailable; this is the universal serverless fallback
- **Update batching** — local Yjs updates are debounced ~80 ms and coalesced
  with \`Y.mergeUpdates\` before sending; flushed immediately on
  \`visibilitychange\` / \`pagehide\`
- **SQL \`_collab_docs\` table** persists Yjs state as base64 (SQLite/Postgres
  compatible). Tombstone compaction fires automatically when the stored blob
  exceeds 4× the fresh encoded size.

## Agent + Human Editing

1. **Human edits** → TipTap → ySyncPlugin → Y.XmlFragment → \`POST /_agent-native/collab/:docId/update\`
2. **Agent edits** → action edits canonical SQL content + bumps \`updatedAt\` → change-sync refetch → the open editor reconciles the new content into the live Y.Doc (see below) → poll update → all clients

Both produce Yjs operations that merge cleanly. Agent edits appear without
destroying cursor position, selection, or undo history.

The agent does **not** push edits into Yjs in-process and does **not** call any
localhost probe — those approaches silently no-op on serverless (the action runs
in a different process). The peer-editor model below replaced them.

## Agent Edits As A Real-Time Peer Editor

**SQL is the durable source of truth for document body content.** The agent
action edits the canonical content column and bumps \`updatedAt\`. No localhost
calls, no in-process Yjs mutation.

**The open editor reconciles authoritative external content into the live
Y.Doc.** The \`updatedAt\` bump flows through change-sync, which refetches the
record. The lead client applies the new content via \`setContent\`, producing Yjs
operations that merge with concurrent human edits. Every connected client
receives the result through normal Yjs sync.

### The \`updatedAt\` gate

\`\`\`ts
// In the editor's reconcile effect
if (loaded.updatedAt > lastAppliedUpdatedAt.current) {
  applyAuthoritativeContent(loaded.content); // adopt
  lastAppliedUpdatedAt.current = loaded.updatedAt;
}
// else: lagging poll / stale snapshot → ignore
\`\`\`

Without the gate, a slightly-behind poll response re-applies old content and
the edit "reverts on next poll". A fresh mount always adopts whatever content
it loaded.

### Lead-client election

Exactly ONE connected client applies the authoritative snapshot; the rest
receive it through Yjs sync:

\`\`\`ts
import { isReconcileLeadClient } from "@agent-native/core/client/collab";

if (
  loaded.updatedAt > lastAppliedUpdatedAt.current &&
  isReconcileLeadClient(awareness, ydoc.clientID)
) {
  applyAuthoritativeContent(loaded.content);
}
\`\`\`

The agent's awareness entry (\`AGENT_CLIENT_ID\`, max int) can never be the
lead. A sole client is always the lead. The election is deterministic with no
coordination round-trip.

### v1 limitation

Full-content reconcile is **last-writer-wins** for the rare case where a human
has unsaved edits in the exact region the agent simultaneously rewrites. Edits
in **different** regions merge fine through the CRDT.

## Security

### Always choose an explicit access mode

Inspect the schema and sharing registration before configuring collaboration:

- For owned or shareable records, use \`mode: "resource"\` and the resource type
  registered through \`registerShareableResource\`.
- For records deliberately visible to every authenticated user on the
  deployment, use \`mode: "all-authenticated"\`.
- Never invent a \`resourceType\` merely to silence a warning. Resource mode is
  correct only when the matching ownership and sharing model exists.

\`\`\`ts
// server/plugins/collab.ts
import { createCollabPlugin } from "@agent-native/core/server";

export default createCollabPlugin({
  table: "documents",
  contentColumn: "content",
  idColumn: "id",
  access: { mode: "resource", resourceType: "document" },
});
\`\`\`

For intentionally deployment-wide authenticated collaboration:

\`\`\`ts
createCollabPlugin({
  table: "todos",
  contentColumn: "content",
  access: { mode: "all-authenticated" },
});
\`\`\`

Omitting \`access\` is supported only for legacy compatibility and is deprecated.
It behaves like \`all-authenticated\`, logs a warning, and is flagged by Doctor.
Choose the mode explicitly so access intent is reviewable.

Non-owner sharees who have explicit access fall back to state-vector catch-up
(safe, slightly higher latency). Awareness routes require the same viewer
access as read routes.

### Payload limits

Write routes reject payloads exceeding \`maxPayloadBytes\` (default 2 MB) with
HTTP 413. Override:

\`\`\`ts
createCollabPlugin({
  access: { mode: "resource", resourceType: "document" },
  maxPayloadBytes: 512 * 1024,
});
\`\`\`

## Enabling Collaboration

### 1. Install packages

\`\`\`bash
pnpm add @tiptap/extension-collaboration @tiptap/extension-collaboration-caret @tiptap/y-tiptap @tiptap/core
\`\`\`

### 2. Add collab server plugin (with explicit access)

\`\`\`ts
// server/plugins/collab.ts
import { createCollabPlugin } from "@agent-native/core/server";

export default createCollabPlugin({
  table: "documents",
  contentColumn: "content",
  idColumn: "id",
  access: { mode: "resource", resourceType: "document" },
});
\`\`\`

### 3. Use the client hook

\`\`\`ts
import { useCollaborativeDoc, emailToColor, emailToName } from "@agent-native/core/client/collab";

const { ydoc, awareness, activeUsers, agentActive, agentPresent } =
  useCollaborativeDoc({
    docId: documentId,
    requestSource: TAB_ID,
    user: {
      name: emailToName(session.email),
      email: session.email,
      color: emailToColor(session.email),
    },
  });
\`\`\`

### 4. Add TipTap extensions

\`\`\`ts
import { Collaboration } from "@tiptap/extension-collaboration";
import { CollaborationCaret } from "@tiptap/extension-collaboration-caret";

const editor = useEditor({
  extensions: [
    StarterKit.configure({ history: false }), // Yjs handles undo
    Collaboration.configure({ document: ydoc }),
    CollaborationCaret.configure({
      provider: { awareness },
      user: { name: session.email, color: "#6366f1" },
    }),
  ],
  // Do NOT pass content — Yjs owns it
});
\`\`\`

### 5. Add to vite.config.ts optimizeDeps

\`\`\`ts
optimizeDeps: {
  include: [
    "yjs",
    "y-protocols/awareness",
    "@tiptap/core",
    "@tiptap/extension-collaboration",
    "@tiptap/extension-collaboration-caret",
    "@tiptap/y-tiptap",
  ],
}
\`\`\`

## Collab Routes (auto-mounted)

| Route | Purpose |
| ----- | ------- |
| \`GET /_agent-native/collab/:docId/state\` | Fetch full Y.Doc state (accepts \`?stateVector=\` for diff) |
| \`POST /_agent-native/collab/:docId/update\` | Apply client Yjs update |
| \`POST /_agent-native/collab/:docId/text\` | Apply full text (diff-based) |
| \`POST /_agent-native/collab/:docId/search-replace\` | Surgical find/replace in Y.XmlFragment |
| \`POST /_agent-native/collab/:docId/json\` | Apply full JSON diff to Y.Map/Y.Array |
| \`GET /_agent-native/collab/:docId/json\` | Read current JSON state |
| \`POST /_agent-native/collab/:docId/patch\` | Surgical JSON patch ops |
| \`POST /_agent-native/collab/:docId/awareness\` | Sync cursor/presence state |
| \`GET /_agent-native/collab/:docId/users\` | List active users |

## Granular Server-Side Merge Pattern

For structured documents (slides, forms, design files) where body collab would
cause LWW conflicts at the container level, use **granular server-side merge**:
define an action with targeted per-item operations.

**When to use granular merge vs body collab:**

| Scenario | Recommended approach |
| -------- | -------------------- |
| Free-form rich text, cursor-level CRDT matters | Body collab (Y.XmlFragment + TipTap) |
| Structured items (slides, fields) where different users edit different items | Granular server-side merge (action with patch ops) |

Example operation shape for slides:

\`\`\`ts
type PatchDeckOp =
  | { type: "patch"; slideId: string; fields: Partial<SlideFields> }
  | { type: "add"; position: number; slide: SlideData }
  | { type: "delete"; slideId: string }
  | { type: "reorder"; slideId: string; newIndex: number };
\`\`\`

Concurrent edits to different slides both succeed at the action level; there
is no whole-deck LWW. Forms use the same shape with field-level ops.

## Agent Presence & Lingering Edit Highlights

The agent is a *visible* collaborator, not a silent content-swapper. Core
handles most of this automatically:

- **Auto-presence on agent writes** — any \`applyText\` / \`searchAndReplace\` /
  \`applyJson\` / \`applyPatchOps\` call with \`requestSource: "agent"\` publishes
  an agent awareness entry plus a \`recentEdits\` attribution describing what
  changed. Actions that route writes through the collab layer get full
  presence UX with zero extra wiring.
- **Linger** — \`agentLeaveDocument\` (and the auto-presence path) keeps the
  agent's awareness entry alive for ~6s (\`AGENT_PRESENCE_LINGER_MS\`) after the
  last edit so viewers see who just changed what. Pass \`{ lingerMs: 0 }\` to
  clear immediately. On serverless the linger degrades to the 30s awareness
  expiry.
- **\`agentTouchDocument(docId, { edit, metadata })\`** — refcount-neutral
  presence + attribution for actions that write SQL directly (no collab doc).
  \`edit.descriptor\` is one of \`{kind:"text",quote}\`, \`{kind:"selector",selector}\`,
  \`{kind:"paths",paths}\`, \`{kind:"doc"}\`.
- **Durable across instances** — awareness is mirrored to the additive
  \`_collab_awareness\` table, so presence written by an action in one
  serverless invocation is visible to clients polling any other instance.

Client rendering:

\`\`\`tsx
import {
  usePresence, useRecentEdits, RecentEditHighlights,
  PresenceBar, LiveCursorOverlay, RemoteSelectionRings,
} from "@agent-native/core/client/collab";

const { others, setPresence } = usePresence(awareness, ydoc?.clientID);
const recentEdits = useRecentEdits(others); // non-expired, ~6s TTL

<RecentEditHighlights
  edits={recentEdits}
  containerRef={containerRef}
  resolveRect={(edit) => /* map descriptor → DOMRect, or null */ null}
/>
\`\`\`

Humans get the same treatment: call \`publishRecentEdit(awareness, { descriptor })\`
from local mutation paths so peers see lingering highlights for human edits
too. \`CollabUser.avatarUrl\` puts faces on avatars, cursors, and edit tags.

## Per-User Undo (never revert someone else's work)

Undo must only reverse the local user's edits — and must never restore a
whole-document snapshot (that clobbers concurrent edits by peers/the agent).
Core ships two primitives:

**Yjs surfaces — \`useCollabUndo\`** (wraps \`Y.UndoManager\` lifecycle):

\`\`\`ts
import { useCollabUndo } from "@agent-native/core/client/collab";

const { undo, redo, canUndo, canRedo, transactLocal, localOrigin } =
  useCollabUndo({
    ydoc,
    scope: (doc) => doc.getText("content"),
    captureTimeout: 500,
    enableKeyboardShortcuts: true, // Mod+Z / Shift+Mod+Z / Mod+Y
  });

// Tag every local mutation so it is captured:
transactLocal(() => { /* mutate shared types */ });
\`\`\`

Remote (\`"remote"\`) and agent (\`"agent"\`/\`"server"\`) origins are never
captured. The manager is recreated/destroyed automatically when \`ydoc\`
changes. (TipTap's Collaboration extension already provides this behavior
for its own editor content.)

**Op-based surfaces (slides/forms) — \`useLocalOpUndo\`**: record inverse
granular ops for each local mutation; undo replays the inverse ops through
your normal granular mutation path:

\`\`\`ts
const { push, undo, redo, canUndo, canRedo } = useLocalOpUndo({
  apply: (ops) => applyGranularOps(ops), // your patch path
});

push({
  undo: [{ type: "patch", slideId, fields: prevFields }],
  redo: [{ type: "patch", slideId, fields: nextFields }],
  coalesceKey: \`\${slideId}:content\`, // merge rapid bursts into one step
});
\`\`\`

Entries whose target no longer exists should fail soft (skip), never reset
the whole history — external/agent edits must not wipe the user's undo stack.

## Common Pitfalls

- **Missing \`access\`** — Legacy omission behaves like \`all-authenticated\`, logs
  a startup warning, and is flagged by Doctor. Choose \`resource\` for records
  backed by ownership/sharing, or explicit \`all-authenticated\` for intentionally
  deployment-wide records. Never invent a resource type to silence the warning.
- **Don't pass \`content\` as a TipTap prop** when Collaboration is enabled —
  Yjs owns the content. Seed via \`editor.commands.setContent()\` only when the
  Y.XmlFragment is empty.
- **Don't call \`editor.setContent()\` ad hoc for agent edits** — the only
  sanctioned \`setContent\` is gated by \`updatedAt\` and guarded by
  \`isReconcileLeadClient\`. Calling it from elsewhere duplicates content across
  the CRDT or re-applies stale snapshots.
- **Add packages to \`optimizeDeps\`** — Vite won't pre-bundle Yjs correctly
  otherwise, causing runtime errors in dev.
- **One \`Y.Doc\` per document** — Don't create multiple Y.Doc instances for the
  same document ID. \`useCollaborativeDoc\` caches by ID.
- **Destroy Y.UndoManager on doc change** — Stale managers hold Y.Doc
  references and grow unboundedly. Recreate on \`docId\` change.

## Related Skills

- \`real-time-sync\` — The change-sync system that delivers the \`updatedAt\` bump
  driving editor reconciliation; also \`useReconciledState\` for non-Yjs surfaces
- \`storing-data\` — The \`_collab_docs\` table and SQL canonical content
- \`security\` — \`registerShareableResource\`, \`resolveAccess\`, \`assertAccess\`
- \`self-modifying-code\` — Agent edits to collaborative documents edit canonical
  SQL content, not raw Yjs
`,dir:`.agents/skills/real-time-collab`,extraFiles:[],files:{}},"real-time-sync":{meta:{name:`real-time-sync`,description:`Decide whether a page needs external changes before refresh, then use the opt-in shared SSE and polling transport safely.`,scope:`dev`},content:`---
name: real-time-sync
description: >-
  Decide whether a page needs external changes before refresh, then use the
  opt-in shared SSE and polling transport safely.
scope: dev
metadata:
  internal: true
---

# Real-Time Sync

## Decision rule

Opt in only when both are true:

1. The data can change without the current user acting.
2. The user needs to see that change before refreshing or navigating.

A local agent edit does not meet this rule. The chat run stream already
invalidates action queries and source counters after each side-effecting tool
and again at run end, without opening a background poll.

### Opt in

- **Slides deck editor:** another collaborator can edit the open deck.
- **Mail inbox:** new mail can arrive while the inbox is open.
- **A watched job:** a background job changes progress while the user watches it.
- **Cross-tab state:** state must converge across this user's open tabs without a
  new action.

### Keep it off

- Public, anonymous, marketing, docs, and SSR pages.
- Settings, forms, and read-mostly lists or dashboards. Refresh them on focus or
  navigation instead.
- Single-user agent edits. The chat run stream handles those.
- Pages where an update is useful eventually but not before the next refresh.

## Cost and behavior

\`useDbSync()\` has no background transport unless the page opts in with a
non-empty reason. One transport is shared per tab. A visible opted-in tab polls
at 1 minute, then 2, then 5 minutes while idle; user activity or a local
mutation resets that sequence. Hidden tabs pause by default. During an active
agent run, opted-in sync can poll at its configured \`interval\`; local tool
completion and run-end invalidation do not depend on that poll.

On a long-lived host, same-process changes stream over
\`/_agent-native/events\`; polling is the cross-process fallback. On a production
serverless host, the local events endpoint refuses the long-lived stream and
\`/_agent-native/poll\` carries remote changes. The paid Hosted Realtime Sync
Gateway is not required for this pattern.

While a collab doc shows another person present, the transport polls every
2.5 s instead (\`acquireCollabPollBoost()\`, held by the collab client, not by
pages). It is a no-op whenever a stream is connected, lapses after 3 minutes
without input or remote events, and never applies to lone tabs.

## Use the hook

Declare the reason beside the route gate so reviewers can see why the page pays
for remote sync:

\`\`\`tsx
useDbSync({
  queryClient,
  realtime: isPrivateDeckEditorPath(location.pathname)
    ? { reason: "other collaborators can edit this deck while it is open" }
    : undefined,
  pauseWhenHidden: true,
});
\`\`\`

The reason is required by the TypeScript API. Opt in only for a named private
or authenticated route; public, documentation, and SSR pages should not start a
background transport.

An opted-in page only hears about an action when its change event reaches the
current user. By default an \`action\` event reaches the actor alone, so a
collaborator's comment, save, or agent edit never arrives. Declare
\`changeResource: (input, result) => ({ resourceType, resourceId })\` on the
mutating action and the event also reaches everyone who can read that resource.
Name it from \`input\` when the call carries the resource id (Content's
\`documentChangeResource\`, Slides' comment actions) and from \`result\` when the
call is keyed by a child id (Design's \`designChangeResource\` for
\`delete-file\`); return \`null\` for a call that changed nothing. Do not publish a
parallel per-template event for the same purpose.

Do not start \`subscribeSyncEvents()\` or an \`EventSource\` in a feature to bypass
the decision. \`subscribeSyncEvents()\` is a lower-level transport subscription
used by the existing Yjs collaboration client and narrow framework plumbing.
Keep Yjs collaborative editing on its existing channel.

## Query freshness

Prefer \`useActionQuery()\` for action-backed data. Mutating actions refresh local
action observers; the chat run stream also invalidates them for agent tool
side effects. Raw queries should include the relevant source counters:

\`\`\`tsx
const versions = useChangeVersions(["dashboards", "action"]);
useQuery({
  queryKey: ["dashboard", id, versions],
  queryFn: () => fetchDashboard(id),
  placeholderData: (previous) => previous,
});
\`\`\`

That covers local chat-run edits. Remote edits reach the counter through
\`useDbSync()\` only on an opted-in page. Use \`useReconciledState\` when a form or
inline editor copies a query value into local state so incoming data does not
replace active typing.

URL commands (\`__set_url__\`, \`set-url\`, and \`set-search-params\`) and
\`refresh-screen\` also flow through local chat events. The sidebar listens for
screen refresh only while its panel is open or a chat run is active; public docs
can disable that boundary with \`screenRefreshEnabled={false}\`.

## Source counters

On local tool completion, \`useDbSync()\` advances the action counter and any
other raw-query source counters currently observed by the page. Generic tool
completion events do not identify their data domain, so keep raw-query source
lists narrow. Remote sync events advance their specific source counters.

| Source | Changed by |
| --- | --- |
| \`action\` | A successful mutating action or local chat-run side-effect completion |
| \`app-state\` | Writes to \`application_state\`, including URL commands |
| \`settings\` | Writes to \`settings\` |
| \`dashboards\`, \`analyses\`, \`extensions\` | Domain-specific mutations that emit those sources |
| \`collab\` | Yjs collaborative document updates |
| \`screen-refresh\` | The explicit \`refresh-screen\` agent tool |

Use \`useChangeVersions()\` when one query depends on more than one source.

## Avoid

- Do not create manual polling loops or a second \`EventSource\`.
- Do not enable background sync for a whole app root when only one private
  route needs remote updates.
- Do not assume a successful local action is a reason for a background
  subscriber; use local mutation invalidation and the chat run stream.
- Do not blanket-invalidate template queries when a source-versioned query or
  action-backed query can target the refreshed data.
`,dir:`.agents/skills/real-time-sync`,extraFiles:[],files:{}},"reliable-mutations":{meta:{name:`reliable-mutations`,description:`How the agent must perform writes so they actually persist under the hosted foreground run budget and long-running background handoffs. Use whenever you create, update, delete, or batch-write app data — especially "do this for many items" loops, or any task where the user expects N things to end up saved.`,scope:`dev`},content:`---
name: reliable-mutations
description: >-
  How the agent must perform writes so they actually persist under the hosted
  foreground run budget and long-running background handoffs. Use whenever you
  create, update, delete, or batch-write app data — especially "do this for many
  items" loops, or any task where the user expects N things to end up saved.
scope: dev
---

# Reliable Mutations

## Rule

Make a change in **one atomic call** when the action supports it, then **verify
the persisted end state and report concrete proof** (counts/ids). Never drive a
multi-step change by looping many small writes, and never report success from a
tool ✓ alone.

## Why

Hosted foreground agent runs have a short soft budget so they can hand off
cleanly under synchronous serverless walls. Durable background runs get a much
longer budget, but they still should not rely on loops of many small writes:
continuations can retry the same intent and leave partial state if each item is
committed separately. One atomic call commits or fails as a unit; verification
turns a hopeful ✓ into a fact.

## How

1. **Prefer a single atomic call.** If an action accepts the whole set (add
   many, set all, bulk update), pass the full batch in one call so it commits
   atomically. Check the action surface for a batch/plural form before reaching
   for a loop.
2. **Do not loop many small writes under any run budget.** A sequence of N
   per-item writes can still leave partial or no state when a foreground run
   hands off, a background run continues, or an upstream provider fails. If no
   batch action exists, that is a gap in the action layer — add or extend an
   action that accepts the batch (see the \`actions\` skill) rather than papering
   over it with a loop.
3. **Verify the end state after writing.** Re-read the data (a list/read action,
   a count query) and confirm the result matches intent — the right number of
   rows, the expected ids/fields. Do this before you tell the user it worked,
   and include the relevant verification expectation in the app's \`AGENTS.md\`.
4. **Report proof-of-done, not vibes.** State concrete evidence: "saved 12 of 12
   panels (ids …)" or "updated 5 rows". Do not infer success from the presence
   of a tool ✓ on an individual call.
5. **On a time-budget cutoff, fail loud.** If the turn is cut before the change
   is fully committed and verified, say so explicitly and report what *did*
   persist (M of N) and what remains. Never round a partial or unverified write
   up to "done".

## Don't

- Don't loop \`for each item: write(item)\` for a large set in a single hosted
  turn.
- Don't claim completion because every tool call returned ✓ — a ✓ on an aborted
  chunk does not mean the row was committed.
- Don't silently shrink the scope ("I added a few of them") and present it as the
  finished task.
- Don't try to "fix" this by asking for a longer run timeout — the budget is
  correct; restructure the write instead.

## Related

- \`actions\` — define or extend a batch/atomic action when only per-item writes
  exist.
- \`storing-data\` — where app data lives and how reads/writes are scoped.
- \`performance\` — avoid query waterfalls when verifying end state.
- Design doc: \`packages/core/docs/design/durable-agent-runs.md\` — the real
  ceiling fix (checkpointed and durable runs); this skill is the agent-facing
  mitigation that reduces how often the ceiling is hit.
`,dir:`.agents/skills/reliable-mutations`,extraFiles:[],files:{}},secrets:{meta:{name:`secrets`,description:`Connect external services and keep app credentials scoped. Use before adding an API key, OAuth connection, provider setup, or server-side request that needs a user's or workspace's credential.`,scope:`dev`},content:`---
name: secrets
description: >-
  Connect external services and keep app credentials scoped. Use before adding
  an API key, OAuth connection, provider setup, or server-side request that
  needs a user's or workspace's credential.
scope: dev
---

# Secrets

## Rule

Credentials belong to the user, organization, workspace, or deployment that
owns them. Reuse the strongest shared connection or credential flow available;
never copy a value into app code or client-visible state.

## Choose the credential source

1. Check the workspace connection catalog first. If the provider is already
   connected, request the app grant and resolve its vault-backed credential
   reference through the workspace-connection API.
2. For OAuth, use the shared authorization and token flow. Do not store access
   or refresh tokens as ordinary settings or API-key values.
3. If the app truly needs its own API key, register it with the shared secrets
   surface. Do not build a parallel key form or storage table.
4. Use deployment configuration only for a secret owned by the deployed app,
   such as a webhook verification secret. LLM inference keys are an app-owned
   exception: self-hosted apps may use provider keys from deployment env as a
   shared fallback, while scoped user or organization keys take precedence.
   Hosted-workspace deployments backed by a shared database must not share
   those env keys across apps or tenants. This exception does not authorize
   using env credentials to access user-owned provider data.

## Register an app-local API key

Register the key once so Settings can manage it and the app can describe why it
is needed. Supported scopes are \`user\`, \`org\`, and \`workspace\`; choose the
narrowest scope that matches who owns the credential and how the app resolves
it. Put the registration in a server module imported by a loaded server plugin.

\`\`\`ts
import { registerRequiredSecret } from "@agent-native/core/secrets";

registerRequiredSecret({
  key: "EXAMPLE_SERVICE_API_KEY",
  label: "Example service API key",
  description: "Connects this app to the example service.",
  docsUrl: "https://example.com/api-keys",
  scope: "user",
  kind: "api-key",
  required: true,
});
\`\`\`

Use \`kind: "oauth"\` for an OAuth-backed connection and set \`oauthProvider\` and
\`oauthConnectUrl\` for the shared Connect flow. Set \`required\` only when the app
cannot perform its primary workflow without that connection. A validator may
check a key before save; never log or include the value in a validation error.

## Resolve credentials on the server

Resolve credentials only inside server-side actions or server helpers, using
the request's user and organization context. Keep a missing key separate from
a failed credential-store lookup: ask the user to connect the provider only
when the credential is absent; make a store failure retryable.

For an app-local key, use \`resolveSecretDetailed()\` from
\`@agent-native/core/server\` in the request context. Check \`lookupFailed\` before
checking \`value\`; do not turn a failed lookup into a setup prompt.

Never read a user's or workspace's API key from \`process.env\`, or add a raw
environment fallback to a scoped lookup. Do not put credentials in action
arguments or results, agent messages or hidden context, application state,
browser storage, client bundles, logs, or error text. Send them only in the
provider request that needs them, and redact provider responses before
returning an error.

## Related skills

- \`security\` — protect access to app data and external requests.
- \`actions\` — expose server-side operations to both the agent and UI.
`,dir:`.agents/skills/secrets`,extraFiles:[],files:{}},security:{meta:{name:`security`,description:`Secure app data, actions, routes, and external input. Use when changing authentication, authorization, database access, uploads, untrusted content, or server-side requests to user-provided URLs.`,scope:`dev`},content:`---
name: security
description: >-
  Secure app data, actions, routes, and external input. Use when changing
  authentication, authorization, database access, uploads, untrusted content,
  or server-side requests to user-provided URLs.
scope: dev
---

# Security

## Rule

Treat each action, route, query, and external request as a trust boundary.
Validate inputs, check the caller's authority for every row, and fail closed
when access cannot be established.

## Validate input and queries

- Define action inputs with a Zod \`schema\`; validate data from forms, URLs,
  providers, and files before using it.
- Build database queries with Drizzle. For raw SQL, bind values as parameters;
  never concatenate user input into SQL text.
- Keep large uploads and file contents in file storage. Store only their
  returned ids or URLs in SQL.

## Authorize rows and actions

Choose a table's access model when designing its data:

| Data | Access model |
| --- | --- |
| Private user rows | Store \`owner_email\` and filter every read and write by the current caller. |
| Organization-wide catalog | Store \`org_id\` and scope action queries to the active org; gate restricted mutations by org or app role. |
| Team-shared or individually shareable resources | Use \`ownableColumns()\`, register the resource type, and check access with the sharing helpers. |
| Child rows | Check access to the parent before reading or changing children; add any child-specific rules in the action. |

Do not make a team-wide catalog private by adding a per-user owner filter. For
an organization-owned catalog, \`org_id\` without \`owner_email\` is valid: scoped
database tools expose only the active organization's rows, while app actions
still need their own org filter and authorization. For resources users can
share, use these helpers:

- Add \`accessFilter(table, sharesTable)\` to list and read-many queries.
- Use \`resolveAccess(type, id)\` for an optional read by id, or
  \`assertAccess(type, id, role)\` before a read or write that requires access.
- Use an action's \`authorize\` gate for role-wide restrictions. It decides who
  may call the operation; it does not replace row-level access checks.

Prefer actions for normal app data. A custom HTTP route is appropriate for
protocols such as uploads, streaming, webhooks, OAuth callbacks, or public
unauthenticated resources. An authenticated custom route must establish the
session/request context and apply the same row-level access checks as an action.

## Handle untrusted content and URLs

- React escapes rendered text. Do not pass untrusted content to
  \`dangerouslySetInnerHTML\`, \`innerHTML\`, \`eval\`, or \`document.write\`.
- Use \`ssrfSafeFetch\` from \`@agent-native/core/extensions/url-safety\` for
  server-side requests to user- or agent-controlled URLs. It checks private
  network destinations and redirects.
- Treat provider error bodies and uploaded files as untrusted input. Return a
  useful, bounded error to the user without exposing internal details.

## Protect credentials and consequential actions

Never put credential values in source, prompts, action arguments or results,
application state, client bundles, logs, or error messages. Use the shared
credential flow in the \`secrets\` skill.

For a genuinely high-consequence outward action, such as sending a message,
charging a payment method, or publishing publicly, use \`needsApproval\` to ask
the user to approve that call. Approval does not grant access: keep the normal
\`authorize\` and row-level checks as well.

## Related skills

- \`actions\` — define validated operations shared by the agent and UI.
- \`secrets\` — connect external services and resolve credentials safely.
- \`sharing\` — configure access to shareable resources.
`,dir:`.agents/skills/security`,extraFiles:[],files:{}},"shadcn-ui":{meta:{name:`shadcn-ui`,description:`Using the app's local UI adapter and Toolkit or shadcn primitives. Use when choosing or composing standard controls, implementing dialogs, menus, or forms, or changing component variants and theme tokens.`,scope:`dev`},content:`---
name: shadcn-ui
description: >-
  Using the app's local UI adapter and Toolkit or shadcn primitives. Use when
  choosing or composing standard controls, implementing dialogs, menus, or
  forms, or changing component variants and theme tokens.
scope: dev
---

# shadcn/ui and Local UI Adapters

Use the components already provided by the app. Read the app's design-system
configuration, Toolkit provider, and local UI components before adding or
changing a control. Their exports, variants, and props are the contract; do
not guess from upstream examples.

## Keep imports behind the local adapter

Product pages and domain components should import standard controls through the
app's configured local UI alias. In the Chat starter, that is
\`@/components/ui/*\`; its \`app/components/ui/button.tsx\` is a one-line
re-export of \`@agent-native/toolkit/ui/button\`. Follow an adjacent local shim
when the app needs another Toolkit primitive that is already exported there.

Use the app's configured design system and provider mapping for controls passed
to shared Toolkit surfaces. For shared Toolkit feature presentation, use the
semantic components exposed by \`@agent-native/toolkit/design-system\`; keep the
feature behavior in its existing controller and customize only its supported
presentation seam.

## Compose existing controls

- Prefer a primitive's built-in variant and size. Put page layout on a parent
  instead of overriding shared component appearance for one screen.
- Use the app's semantic theme tokens for reusable UI, such as
  \`bg-background\`, \`text-muted-foreground\`, \`border-border\`, and \`bg-primary\`.
  Keep theme values in the app's existing CSS theme file.
- Use the control that matches the choice: \`Switch\` for a binary setting,
  \`Checkbox\` for independent multi-select, \`RadioGroup\` for one choice from a
  short set, and \`Select\` or the app's combobox for a longer predefined list.
- Compose cards and form fields from the primitives already available. Avoid
  adding explanatory copy that repeats a visible title or label; see
  \`frontend-design\` for the app's surface-density rules.
- Put selectable items inside their menu or list group primitives. Keep tab
  triggers inside the tab list. Supply an accessible title to dialog, sheet,
  drawer, and alert-dialog content.
- Match the trigger API to the actual local component. Toolkit wrappers may
  expose a different API from the upstream primitive; inspect its props before
  using options such as \`asChild\` or \`render\`.

## Keep controls operable

Use the app's existing field components and validation pattern. Associate
errors with their inputs and expose invalid state to assistive technology.
Icon-only actions need an accessible name and a usable focus target. Use the
icon package already installed by the app.

Do not recreate menus, popovers, dialogs, or confirmations with absolute
positioning and custom click-outside handlers. Never use browser \`alert\`,
\`confirm\`, or \`prompt\`; use the app's dialog primitives. Keep overlay focus,
keyboard, dismissal, and stacking behavior from the existing primitive.

For small visual refinements, use layout classes and semantic tokens. Avoid raw
palette overrides, arbitrary one-off values, and manual overlay \`z-index\` unless
you are fixing a reproduced bug. Use \`gap-*\` for layout spacing and the app's
class-merging helper when it has one.

## Related skill

- **frontend-design** — Product UX, density, visual direction, and responsive
  behavior.
`,dir:`.agents/skills/shadcn-ui`,extraFiles:[],files:{}},sharing:{meta:{name:`sharing`,description:`Framework-level sharing and privacy for user-authored resources (dashboards, documents, forms, decks, etc.). Use when making a resource table ownable, wiring list/read/update access checks, or dropping the standard share dialog into a template.`,scope:`dev`},content:`---
name: sharing
description: >-
  Framework-level sharing and privacy for user-authored resources
  (dashboards, documents, forms, decks, etc.). Use when making a resource
  table ownable, wiring list/read/update access checks, or dropping the
  standard share dialog into a template.
scope: dev
metadata:
  internal: true
---

# Sharing — Private by Default, Explicit Share

## Rule

Any resource a user **creates** (dashboards, documents, forms, decks, compositions, booking links, issues, analyses) is **private to the creator** by default and visible to others only when they have been **explicitly shared** with or when the creator changes visibility to \`org\` or \`public\`.

This is the framework-level primitive. Every ownable resource gets it for free — same API, same UI, same skill.

Workspace apps are the intentional organization-scoped exception: their default
visibility is \`org\`, configurable by an organization owner/admin. The creator is
stored as the app owner, and the creator or an organization owner/admin can
change the app's visibility or manage its share grants.

## Concepts

### Three visibility levels

- **\`private\`** — owner + explicit share grants only. Default.
- **\`org\`** — owner + explicit grants + anyone in the same org (read-only).
- **\`public\`** — owner + explicit grants + **anyone with the link** (read-only). Public docs do NOT appear in other users' list/sidebar/search results — \`accessFilter\` omits them by default. They're reachable by id (\`resolveAccess\` admits them) so direct links and SSR routes like \`/p/:id\` keep working. If a list endpoint legitimately needs cross-user public discovery (a template gallery, etc.), pass \`accessFilter(table, shares, ctx, minRole, { includePublic: true })\`.

Visibility is coarse. Explicit share grants are fine-grained (per user, reusable
organization group, or per org).

### Roles on a share grant

- **\`viewer\`** — read only.
- **\`commenter\`** — read + add comments, but cannot edit the resource or manage shares.
- **\`editor\`** — read + write.
- **\`admin\`** — read + write + manage shares. Does NOT replace the single \`owner_email\` on the resource.

Share roles apply to one resource; organization roles apply to a team; app
roles apply within one app. These are separate permissions. For role setup,
use \`agent-native-docs\` to find the current organization and app-role guide.

Before adding an admin gate, identify which role system protects that operation
and use its existing role descriptor and permission checks. Do not replace role
checks with an email comparison or a custom \`isAdmin\` column.

### Anonymous public URLs stay separate

Form "publish" slugs, booking-link slugs, any feature that exposes a URL to unauthenticated users — these are a different axis and are NOT controlled by the sharing system. Keep them alongside it.

## Make a resource ownable

In your template's \`server/db/schema.ts\`:

\`\`\`ts
import { sql } from "drizzle-orm";
import { pgTable, text } from "drizzle-orm/pg-core";
import {
  createSharesTable,
  ownableColumns,
} from "@agent-native/core/db/schema";

export const decks = pgTable("decks", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  data: text("data").notNull(),
  createdAt: text("created_at").notNull().default(sql\`now()\`),
  updatedAt: text("updated_at").notNull().default(sql\`now()\`),
  ...ownableColumns(), // adds owner_email, org_id, visibility
});

export const deckShares = createSharesTable("deck_shares");
\`\`\`

Then register it **in \`server/db/index.ts\`** (not the schema file — keeps the schema file free of the \`getDb\` closure and avoids circular imports):

\`\`\`ts
// server/db/index.ts
import * as schema from "./schema.js";
import { createGetDb } from "@agent-native/core/db";
import { registerShareableResource } from "@agent-native/core/sharing";

export const getDb = createGetDb(schema);
export { schema };

registerShareableResource({
  type: "deck",
  resourceTable: schema.decks,
  sharesTable: schema.deckShares,
  displayName: "Deck",
  titleColumn: "title",
  getResourcePath: (deck) => \`/deck/\${deck.id}\`,
  getDb,
});
\`\`\`

The \`type\` string is the stable id the UI and actions use. \`getDb\` is required — the framework-level share actions use it to reach your template's DB.

### Restricting public visibility and cross-org user shares

Some resources should NOT be reachable by an arbitrary authenticated user even with the link, and should NOT be shareable to an email outside the org. Two optional registration flags lock these axes down:

\`\`\`ts
registerShareableResource({
  type: "extension",
  // ...
  allowPublic: false, // hides "Public" in the share dialog and rejects it server-side
  requireOrgMemberForUserShares: true, // user shares must target an org member or pending invitee
  supportsGroupShares: true, // enable reusable organization groups for this resource
});
\`\`\`

- **\`allowPublic: false\`** — \`set-resource-visibility('public')\` throws \`ForbiddenError\`, \`accessFilter\` / \`resolveAccess\` treat any stored \`'public'\` row as private (defense in depth against bad data), and the share popover hides the "Public" option. \`list-resource-shares\` returns \`policy.allowPublic: false\` so the UI follows the server.
- **\`requireOrgMemberForUserShares: true\`** — \`share-resource\` looks up \`principalId\` in \`org_members\` and \`org_invitations\` (pending) for the resource's \`orgId\` and rejects user shares to anyone else. The same flag also pins \`principalType: "org"\` shares to the resource's own org — sharing to a *different* org would let that org's members run code in the viewer's auth context (same threat model as a public extension). (The flag name is kept for backward compatibility; treat it as "lock both user and org shares to the resource's org".)

Use both for resources that execute code or expose privileged data with the *viewer's* credentials. A public or cross-org-shared resource with that access could let an unrelated user act with the viewer's credentials.

Defaults match historical behaviour: \`allowPublic: true\`, \`requireOrgMemberForUserShares: false\`. Resources that don't set the flags work as before.

### Reusable organization groups

The workspace organization model stores reusable groups in
\`workspace_user_groups\`. Organization owners/admins manage the groups and their
members through the existing group actions. Set \`supportsGroupShares: true\` on a
resource registration to enable \`principalType: "group"\` in the generic share
actions and the shared popover's autocomplete. Group ids are always checked
against the resource's organization, and membership is evaluated at access time
so group changes apply to existing shares.

Workspace apps opt into this flag and use the organization default visibility
setting. The app creator is the durable \`owner_email\`, while organization
owners/admins receive admin access through the registration's
\`canManageAccess\` callback.

## Filter list/read queries

\`\`\`ts
import { accessFilter } from "@agent-native/core/sharing";

const rows = await db
  .select()
  .from(schema.decks)
  .where(accessFilter(schema.decks, schema.deckShares));
\`\`\`

\`accessFilter\` admits rows the current user owns, has been shared on, or that the user can reach via \`org\` visibility. \`public\` rows are NOT admitted by default — see the visibility section above for why and how to opt in.

## Guard write actions

\`\`\`ts
import { assertAccess } from "@agent-native/core/sharing";

export default defineAction({
  schema: z.object({ id: z.string(), title: z.string() }),
  run: async (args) => {
    await assertAccess("deck", args.id, "editor");
    // ...proceed
  },
});
\`\`\`

For delete actions use \`"admin"\` (or fold in \`"owner"\` to require the real owner).

\`authorize\` is a different axis, not an alternative: it gates whether the caller may run the operation at all, while \`assertAccess\` scopes which row they may touch. A write action restricted to some teammates needs both — \`authorize: appAccess.requireAny(...)\` on the action, \`assertAccess\` inside \`run\`.

## Create actions must set owner

When inserting a new row, fill \`ownerEmail\` and \`orgId\` from the request context:

\`\`\`ts
import { fail } from "@agent-native/core/action";
import {
  getRequestUserEmail,
  getRequestOrgId,
} from "@agent-native/core/server/request-context";

const ownerEmail = getRequestUserEmail();
// Never fall back to a shared sentinel owner; require an authenticated session.
if (!ownerEmail) fail("Not authenticated", { statusCode: 401 });

await db.insert(schema.decks).values({
  id: crypto.randomUUID(),
  title,
  data,
  ownerEmail,
  orgId: getRequestOrgId(),
  // visibility defaults to 'private'
  // ...
});
\`\`\`

## Drop in the share UI

\`\`\`tsx
import { ShareButton } from "@agent-native/toolkit/app/sharing";

// In the resource's header/toolbar:
<ShareButton
  resourceType="deck"
  resourceId={deck.id}
  resourceTitle={deck.title}
/>;
\`\`\`

For list views, show \`<VisibilityBadge visibility={row.visibility} />\` next to each resource.

## Standard share surface

All app share popovers should use the same compact surface contract:

- Use the text-only \`ShareTrigger\` from \`@agent-native/toolkit/sharing\`.
- Render ordinary links with \`ShareCopyRow\`, which exposes a Copy action without
  printing the raw URL.
- Keep general access and individual people access in the standard Core sharing
  flow. The people flow supports email invites, roles, notifications, and
  removal through the shared share actions.
- Add \`ShareAgentsSection\` only when the resource has a real agent-readable
  link or prompt. Keep it collapsed by default and supply domain-specific
  content through the shared section shell.
- When \`supportsGroupShares\` is enabled, keep the existing people input as the
  only entry point and include organization groups in its autocomplete. Do not
  add a separate group-management surface to each resource.
- App-specific tabs or controls may remain when they represent a real domain
  action (for example, an embed-code editor), but they should retain the same
  trigger, copy-row, access, and spacing language.

\`ShareDisclosureSection\` is the toolkit-owned shell for optional expandable
share details; use its \`ShareAgentsSection\` or \`SharePeopleSection\` wrappers
instead of creating another collapsible share panel in a template.

## Actions available everywhere

The framework auto-mounts these actions in every template — no per-template boilerplate:

| Action                     | Args                                                                           | Purpose                                   |
| -------------------------- | ------------------------------------------------------------------------------ | ----------------------------------------- |
| \`share-resource\`           | \`resourceType, resourceId, principalType, principalId, role, notify?, resourceUrl?, message?\` | Grant a user, group, or org access. \`notify\` defaults to true for individual user shares; \`resourceUrl\` can provide the direct app link and \`message\` an optional short note for the notification email. |
| \`unshare-resource\`         | \`resourceType, resourceId, principalType, principalId\`                         | Revoke access.                            |
| \`list-resource-shares\`     | \`resourceType, resourceId\`                                                     | Current visibility + all share grants.    |
| \`set-resource-visibility\`  | \`resourceType, resourceId, visibility\`                                         | Change to \`private\` / \`org\` / \`public\`.  |

Both the agent and the UI use these same actions. The agent calls them as tools;
UI code should use \`ShareButton\` / \`ShareDialog\` or the action client hooks
instead of hand-writing route calls.

To re-skin the share notification email for the whole app, register
\`overrideTransactionalEmail("core.resource-shared", render)\` from a server
plugin. Do not fork \`share-resource\` or add another per-resource hook: the
registration's \`getBrandName\` / \`getLogoUrl\` / \`getSender\` / \`getHeroHtml\` /
\`getShareEmailExtras\` hooks still feed the default template and the override's
props. See
\`/docs/deployment#email-templates\`.

## Migration pattern for existing tables

When retrofitting an existing resource table:

1. Add \`owner_email\`, \`org_id\`, \`visibility\` columns (defaults \`'local@localhost'\`, \`NULL\`, \`'private'\`).
2. Backfill \`owner_email\` from any prior creator trail; otherwise leave the default.
3. Add the companion \`{type}_shares\` table.
4. Register via \`registerShareableResource\`.
5. Update list/read actions to use \`accessFilter\`.
6. Update update/delete actions to \`assertAccess\` with the correct role.
7. Add \`<ShareButton>\` to the resource header.
8. Add \`getResourcePath\` in the registration so agent-triggered shares can email a direct link even when no UI supplied \`resourceUrl\`.

## Templates that opt out

Sharing doesn't apply to:

- **Personal-data apps** (mail) — user-scoped by design.
- **External source-of-truth data** — apply the access policy enforced by the upstream system.
- **Demo/boilerplate** (starter) — no resources.

For these, add a short note to the template's \`AGENTS.md\` explaining why.

## Debugging

- \`ForbiddenError\` from an action means the current user isn't owner / hasn't been shared / can't meet the role bar.
- If the agent can't see a resource it just created, check that the insert actually set \`owner_email\` from the request context.
- If a share doesn't take effect in the UI, confirm the template's \`list-*\` action uses \`accessFilter\` — the share rows are there but nothing is reading them yet.
`,dir:`.agents/skills/sharing`,extraFiles:[],files:{}},"storing-data":{meta:{name:`storing-data`,description:`How to store application data in agent-native apps. All data lives in SQL. Use when adding data models, deciding where to store data, or reading/writing application data.`,scope:`dev`},content:'---\nname: storing-data\ndescription: >-\n  How to store application data in agent-native apps. All data lives in SQL.\n  Use when adding data models, deciding where to store data, or reading/writing\n  application data.\nscope: dev\nmetadata:\n  internal: true\n---\n\n# Storing Data — SQL is the Source of Truth\n\n## Rule\n\nAll application data lives in **SQL** (local PGlite, hosted Postgres in production). The agent and UI share the same database. SQL stores structured records, metadata, references, and searchable text — not large raw file payloads. Do not store durable app data in the filesystem unless the app is explicitly running a Local File Mode artifact flow described below.\n\nLarge binary or file-like payloads (images, video/audio, PDFs, ZIPs, screenshots, session replay chunks, thumbnails, generated assets, `data:` URLs, and base64 file bodies) must go through configured file/blob storage such as `uploadFile()` or `putPrivateBlob()`. Persist only the returned URL, asset id, or opaque blob handle in SQL. If storage is unavailable in hosted or persistent-database mode, fail closed with setup guidance instead of falling back to base64 in `application_state`, `settings`, `resources`, or app tables.\n\n**Uploaded files an action opens later** (chat attachments, import controls, chunked commits) are one core `AttachmentRef`: mint with `mintAttachmentRef`, open with `resolveAttachment` and `unwrapAttachment` from `@agent-native/core/private-blob`. Never write a template descriptor, never branch on error text, and never truncate a ref (`ATTACHMENT_REF_MAX_CHARS` is the floor for any prompt or field that carries one). Each failure is typed: `notFound`, `forbiddenScope`, `expired` and `malformed` are definitive and stop the turn; only `storageUnavailable` is retryable, and the same ref works once storage is back, so never ask the user to attach the file again for it.\n\n**Local File Mode exception:** some artifact apps (Content, Plans, Slides, Dashboards, Designs, etc.) can intentionally use repo files as the source of truth for the artifact itself. This must be explicit via `agent-native.json`, `AGENT_NATIVE_MODE=local-files`, or an app-owned local-file action helper. In that mode, the UI and agent still go through app actions, but those actions read/write scoped files through `@agent-native/core/local-artifacts` instead of SQL rows. App state, auth, settings, credentials, collaboration metadata, and hosted database mode remain SQL. File-to-database or file-to-provider synchronization is an explicit sync step, not an implicit side effect of editing.\n\nWhen you add a data model, a list, or a read path, also follow the `performance` skill: project only the columns a list renders, index the columns hot queries filter/sort on, and avoid query waterfalls — so apps stay fast as data grows.\n\n## How It Works\n\nAgent-Native apps use Drizzle ORM over PostgreSQL. Local development uses PGlite at `data/pglite`; production and shared preview deploys need a persistent hosted PostgreSQL `DATABASE_URL`.\n\nFor app code, use Drizzle\'s schema/query DSL by default. Raw SQL is an escape hatch for additive migrations, health checks, or one-off maintenance, not the normal way to build features.\n\n### Schema and migration ownership\n\nDefine PostgreSQL tables with Drizzle\'s `drizzle-orm/pg-core` exports and use\n`drizzle-orm` for query operators. Import only framework-owned sharing helpers,\nsuch as `ownableColumns()` and `createSharesTable()`, from\n`@agent-native/core/db/schema`. Do not import table builders through the core\nhelper module.\n\nWhen the project contains `drizzle.config.ts` and `drizzle/START_HERE.md`, that managed Drizzle scaffold is the only app migration path. Define app tables in `drizzle/schema.ts`, run `pnpm db:generate`, and apply them with `pnpm db:migrate`. `scripts/migrate-production.ts` applies the framework tables and leaves app tables to `db:migrate` (it skips `server/plugins/db.ts` when `drizzle.config.ts` exists): do not create a parallel `runMigrations([...])` list in `server/plugins/db.ts` or import an app migration runner into the release script.\n\nIn projects without that managed scaffold, every entry added to a framework `runMigrations([...])` list (`@agent-native/core/db`) needs a unique, stable `name` alongside its `version`; append changes instead of renumbering, reusing, or editing an applied entry.\n\nWhy: version numbers alone are not a safe identity. Two branches that each independently extend the same migration list can ship different DDL under the same version numbers — whichever branch deploys first "claims" those version numbers in the bookkeeping table, and the other branch\'s DDL is silently treated as already applied even though it never ran. A `name:` slug is tracked independently of version numbers, so it applies exactly once per database regardless of what any other branch already recorded.\n\nExisting unnamed migrations don\'t need to be renamed retroactively (the two gating strategies coexist), but any new entry should always carry a name.\n\nEvery migration must be additive and backward compatible with code that may\nstill be running. A new `ADD COLUMN ... NOT NULL` with no `DEFAULT` breaks on\nexisting rows and inserts from older code. Make it nullable, give it a safe\n`DEFAULT`, or use a self-filling type (`SERIAL`, `GENERATED ... AS IDENTITY`);\nbackfill separately when it needs a real value.\n\n### Core SQL Stores (created by the framework, available in all templates)\n\n| Store               | Purpose                                              | Access                                     |\n| ------------------- | ---------------------------------------------------- | ------------------------------------------ |\n| `application_state` | Ephemeral UI state (compose windows, navigation)     | `readAppState()` / `writeAppState()`       |\n| `settings`          | Persistent KV config (preferences, app settings)     | `getSetting()` / `putSetting()`            |\n| `oauth_tokens`      | OAuth credentials                                    | `@agent-native/core/oauth-tokens`          |\n| `sessions`          | Auth sessions                                        | `@agent-native/core/server`               |\n\n### Domain Data (per-template)\n\nIn a managed Drizzle scaffold, define the PostgreSQL schema in\n`drizzle/schema.ts` and get `getDb()` and `schema` from `server/db.ts` (see\n`drizzle/START_HERE.md`). Otherwise, define it in `server/db/schema.ts`;\n`getDb()` comes from the local `server/db/index.ts`. All queries are async.\n\n```ts\nimport { eq, sql } from "drizzle-orm";\nimport { boolean, pgTable, text } from "drizzle-orm/pg-core";\n\nexport const tasks = pgTable("tasks", {\n  id: text("id").primaryKey(),\n  title: text("title").notNull(),\n  completed: boolean("completed").notNull().default(false),\n  createdAt: text("created_at").notNull().default(sql`now()`),\n});\n\nconst rows = await db.select().from(tasks).where(eq(tasks.id, taskId));\n```\n\nUse `drizzle-orm/pg-core` so app schemas state their PostgreSQL types directly.\n\n#### Identity-shaped columns need a policy\n\nMember offboarding and email changes refuse to run while any column named\n`email`, `*_email`, `*scope_id`, `created_by`, `updated_by`, `invited_by`,\n`owner`, `principal_id`, `session_id`, or `user_id` has no policy.\n`createSharesTable()` tables are handled for you, and undeclared `owner_email`\ncolumns transfer to the successor, which is right only for owned content.\nDeclare every other one, including columns that are not member identities, from\nthe app\'s database plugin graph (Clips does it in `server/db/index.ts`):\n\n```ts\nimport { registerIdentityColumns } from "@agent-native/core/org";\n\nregisterIdentityColumns([\n  // Access grant: follows an email change, ends with the membership.\n  { table: "space_members", column: "email", emailChange: "rekey", offboard: "delete", orgScope: { column: "space_id", references: { table: "spaces", column: "id", orgColumn: "org_id" } }, reason: "Space membership grants access." },\n  // Someone else\'s address: never rewritten.\n  { table: "meeting_participants", column: "email", emailChange: "retain", offboard: "retain", reason: "Attendee address from the calendar provider." },\n  // A credential in an owner_email table: never handed to the successor.\n  { table: "api_keys", column: "owner_email", emailChange: "rekey", offboard: "revoke", reason: "Bearer keys act as their owner." },\n]);\n```\n\nChoose `delete` for grants, credentials, and pending tokens, or `revoke` (sets\n`revoked_at`) when a reader treats a missing row as "not revoked"; `retain` for\nattribution, history, and third-party addresses; `transfer` only for owned\ndata. Declare `owner_email` tables that hold credentials or grants, or\noffboarding hands them to the successor. A table without `org_id` needs\n`orgScope` or an organization-scoped removal leaves its rows alone.\n\n| Template     | Tables                                        |\n| ------------ | --------------------------------------------- |\n| **Mail**     | emails, labels                                 |\n| **Calendar** | booking links and bookings; events stay in Google Calendar |\n| **Forms**    | forms, responses                              |\n| **Content**  | documents in SQL; connected local-folder sources sync separately |\n| **Slides**   | decks (JSON stored in SQL)                    |\n| **Clips**    | recording metadata in SQL; video and image files use blob storage |\n\n### Agent Access\n\nThe agent uses app-specific actions to read/write the database. Core DB scripts are for inspection and maintenance, not for implementing normal product behavior:\n\n- `pnpm action db-schema` — Show all tables, columns, types\n- `pnpm action db-query --sql "SELECT * FROM forms"` — Run SELECT queries\n- `pnpm action db-exec --sql "UPDATE ..."` — Last-resort ad-hoc maintenance for short columns, multi-column writes, or computed updates when no domain action exists. For several related writes, prefer `--statements \'[{"sql":"...","args":[...]}]\'` so they run sequentially in one transaction. Schema changes are blocked; use a reviewed additive migration instead.\n- `pnpm action db-patch --table <t> --column <c> --where "<clause>" --find "<old>" --replace "<new>"` — **Surgical search/replace on a large text column.** Sends the diff instead of re-transmitting the whole value, so it\'s dramatically more token-efficient than `db-exec UPDATE` when editing multi-kilobyte documents, slide HTML, dashboard/form JSON, etc. Targets exactly one row per call — narrow `--where` by primary key. Supports `--edits \'[{find,replace},...]\'` for batch edits and `--all` to replace every occurrence.\n- App-specific actions for domain operations — **always prefer these over raw SQL when one exists.** They encode business rules, power the client action hooks, and for editor-backed tables (documents, slides) also push live Yjs updates to open collaborative editors. `db-patch` is the generic fallback for tables without a dedicated edit action.\n\n**For one-off maintenance, how to choose between `db-exec UPDATE` and `db-patch`:**\n\n| Scenario                                                       | Use          |\n| -------------------------------------------------------------- | ------------ |\n| `SET status = \'published\'` on one row                          | `db-exec`    |\n| `SET calories = calories + 50`                                 | `db-exec`    |\n| Updating several columns at once                               | `db-exec`    |\n| Inserting/updating several rows as one logical operation        | `db-exec --statements` |\n| Fixing a typo in a 50KB markdown document\'s `content` column   | `db-patch`   |\n| Changing a single key in a dashboard\'s JSON blob               | `db-patch`   |\n| Tweaking one paragraph of slide HTML stored in `decks.data`    | `db-patch`   |\n| Any edit where you\'d otherwise re-send thousands of characters | `db-patch`   |\n\nAll of these honor the per-user / per-org data scoping — you can\'t read or write rows outside the current user\'s data, regardless of which tool you choose.\n\n### Frontend Access\n\nThe frontend calls actions using React Query hooks from the client API. The framework owns the HTTP transport behind these hooks, so components should not call action routes with raw `fetch`.\n\n```ts\nimport { useActionQuery, useActionMutation } from "@agent-native/core/client/hooks";\n\n// Read data\nconst { data } = useActionQuery("list-meals", { date: "2025-01-01" });\n\n// Write data\nconst { mutate } = useActionMutation("log-meal");\n```\n\nActions are the **preferred way** for the frontend to access data. You rarely need custom `/api/` routes — only for file uploads, streaming, webhooks, or OAuth callbacks.\n\n### Production / Cloud Deployment\n\nLocal PGlite works out of the box for development. To deploy to production or any environment where data must survive restarts:\n\n1. Set `DATABASE_URL` to a persistent hosted PostgreSQL database.\n2. Keep schema and queries PostgreSQL-compatible.\n\n\n\n### Real-time Sync\n\nPolling streams database changes to the UI. When the agent writes to the database via scripts, the UI updates automatically via `useDbSync()` which invalidates React Query caches.\n\n## Do\n\n- Use Drizzle ORM for structured domain data (forms, bookings, documents)\n- Use Drizzle query builder methods (`select`, `insert`, `update`, `delete`) and standard operators from `drizzle-orm` (`eq`, `and`, `or`, `inArray`, `desc`, etc.) for app reads/writes\n- Use `drizzle-orm/pg-core` for PostgreSQL table and column builders; use `@agent-native/core/db/schema` for framework-owned sharing helpers only\n- Use the `settings` store for app configuration and user preferences\n- Use `application-state` for ephemeral UI state that the agent and UI share\n- Use `oauth-tokens` for OAuth credentials\n- Use `uploadFile()` or `putPrivateBlob()` for large files/blob data and store only URLs, ids, or handles in SQL\n- Use core DB scripts (`db-schema`, `db-query`, `db-exec`, `db-patch`) for ad-hoc database operations\n- Use `db-exec --statements` instead of several separate `db-exec` calls for related writes; it is faster and rolls back the whole batch if one statement fails\n- Reach for `db-patch` instead of `db-exec UPDATE` whenever you\'re making a small change to a large text/JSON column — it\'s much cheaper on tokens\n\n## Don\'t\n\n- Don\'t store structured app data as JSON files\n- Don\'t store app state in localStorage, sessionStorage, or cookies (except for UI-only preferences like sidebar width)\n- Don\'t keep state only in memory (server variables, global stores)\n- Don\'t use Redis or any external state store for app data\n- Don\'t store large files, base64 blobs, `data:` URLs, screenshots, videos, audio, PDFs, ZIPs, or session replay chunks directly in SQL rows, `application_state`, `settings`, or `resources`\n- Don\'t implement product features with raw SQL or `getDbExec()` when Drizzle can express the query\n- Write advanced SQL for PostgreSQL\n- Don\'t interpolate user input directly into SQL queries — use Drizzle ORM\'s query builder\n\n## Security\n\n- **SQL injection** — Use Drizzle ORM\'s query builder, never raw string interpolation for SQL queries\n- **Validate before writing** — Check data shape before writing, especially for user-submitted data\n\n## Application State and Context Awareness\n\nWhen storing app-state, include **navigation state** — the agent needs to know what the user is looking at. The `application_state` table holds ephemeral UI state that both the agent and UI share. Key patterns:\n\n- **`navigation` key** — the UI writes current view and selection on route changes; state may be scoped to the current browser tab.\n- **`navigate` command** — write it with `writeAppStateForCurrentTab("navigate", value)` so the command reaches the current tab; the UI processes and deletes it.\n- **Domain-specific keys** (e.g., `compose-{id}`) — bidirectional state for features like email drafts.\n\nWhen adding a new data model or feature, also consider what navigation and selection state needs to be exposed via application-state. See the **context-awareness** skill for the full pattern.\n\n## Related Skills\n\n- **context-awareness** — How to expose navigation and selection state via application-state\n- **real-time-sync** — Set up polling so the UI updates when the database changes\n- **actions** — Create actions with `defineAction` to query the database\n- **build-an-app** — Apply the data model to a complete app feature\n',dir:`.agents/skills/storing-data`,extraFiles:[],files:{}}}};export{e as default};